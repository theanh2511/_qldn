@include('custom_controls.selectbox',
array('id'=>'xa_phuong',
    'select_data'=>$list_data,
    'value_member'=>'ma_xa',
    'display_member'=>'ten_xa',
    'selected_value'=>""
))