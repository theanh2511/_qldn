<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số doanh nghiệp</th>
        <th>Tên doanh nghiệp</th>
        <th>Số ĐT</th>
        <th>Người đại diện</th>
        <th>Trạng thái</th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as $key => $value)
        <tr data-object_value="{{$value->toJson()}}">
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="maso_dn">{{$value->maso_dn}}</td>
            <td class="ten_dn">{{$value->ten_dn}}</td>
            <td class="tel">{{$value->tel}}</td>
            <td class="nguoi_dai_dien">{{$value->nguoi_daidien}}</td>
            <td class="ten_trang_thai">{{$value->ten_trang_thai}}</td>
            @include('layouts.baohiem_grid_buttons')
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>