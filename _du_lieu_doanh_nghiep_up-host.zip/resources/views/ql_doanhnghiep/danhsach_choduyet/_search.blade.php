<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số doanh nghiệp</th>
        <th>Tên doanh nghiệp</th>
        <th>Người đại diện</th>
        <th>Trạng thái</th>
        <th style="width: 220px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as $key => $value)
        <tr data-object_value="{{$value->toJson()}}">
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="maso_dn">{{$value->maso_dn}}</td>
            <td class="ten_dn">{{$value->ten_dn}}</td>
            <td class="nguoi_dai_dien">{{$value->nguoi_daidien}}</td>
            <td class="ten_trang_thai">{{$value->ten_trang_thai}}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-success btn-addon btn-xs m-b-10" type="button" data-toggle="dropdown"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Chức năng
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <li><a href="" data-toggle="modal" data-target="#myModal">Xem</a></li>
                        <li><a href="#">Sửa</a></li>
                        <li><a href="#">Xóa</a></li>
                    </ul>
                    <button type="button" class="btn btn-info btn-addon btn-xs m-b-10" data-toggle="modal" data-target="#myModal1"><i class="fa fa-check" aria-hidden="true" ></i>Duyệt hồ sơ</button>
                </div>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>