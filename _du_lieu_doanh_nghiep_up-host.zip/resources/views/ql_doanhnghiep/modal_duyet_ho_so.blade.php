@extends('layouts.popup')

@section('css')

@stop


@section('content')
    <div class="clearfix-10"></div>
    <section class="report_data dieu_hanh">
        <div class="container-fluid container-fluid-fix">
            <div class="row_pc">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="system" id="sytem-div">
                            <form id="editor-form-modal"
                                  action="{{ url('/quanly_doanhnghiep/hoso_doanhnghiep/duyet_hoso/'.($item_hsdn->id??"")) }}"
                                  method="POST"
                                  enctype="multipart/form-data"
                                  class="form-horizontal">@csrf
                                <div class="form_search">
                                    <input type="hidden" id="primary_key" value="{{$item_hsdn->id}}">
                                    <div class="container-fluid">
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Mã số doanh nghiệp </label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="maso_dn" name="maso_dn"
                                                           value="{{$item_hsdn->maso_dn}}">
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <label class="col-md-12" for="">Tên doanh nghiệp</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="ten_dn" name="ten_dn"
                                                           value="{{$item_hsdn->ten_dn}}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <label class="col-md-12" for="">Địa chỉ trụ sở</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="diachi" name="diachi"
                                                           value="{{$item_hsdn->diachi}}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-6">
                                                <label class="col-md-12" for="">Quận huyện</label>
                                                <div class="col-md-12">
                                                    {{--<select id="quan_huyen" name="quan_huyen" class="form-control input-sm input-default">--}}
                                                    {{--<option value="">=== Lựa chọn ===</option>--}}
                                                    {{--@foreach($list_quan_huyen as $quan_huyen)--}}
                                                    {{--<option value="{{$quan_huyen->ma_huyen}}" {{$item_hsdn->diachi==$quan_huyen->ma_huyen}}>{{$quan_huyen->ten_huyen}}</option>--}}
                                                    {{--@endforeach--}}
                                                    {{--</select>--}}
                                                    @include('custom_controls.selectbox',
                                                    array('id'=>'quan_huyen',
                                                        'select_data'=>$list_quan_huyen,
                                                        'value_member'=>'ma_huyen',
                                                        'display_member'=>'ten_huyen',
                                                        'selected_value'=>$item_hsdn->quan_huyen
                                                    ))
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="col-md-12" for="">Xã phường</label>
                                                <div class="col-md-12" id="ht_xa">
                                                    @include('custom_controls.selectbox',
                                                    array('id'=>'xa_phuong',
                                                        'select_data'=>$list_xa_phuong,
                                                        'value_member'=>'ma_xa',
                                                        'display_member'=>'ten_xa',
                                                        'selected_value'=>$item_hsdn->xa_phuong
                                                    ))
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Vốn điều lệ</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control text-right" id="von_dl"
                                                           name="von_dl" value="{{number_format($item_hsdn->von_dl)}}">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Trạng thái</label>
                                                <div class="col-md-12">
                                                    @include('custom_controls.selectbox',
                                                    array('id'=>'trang_thai',
                                                        'select_data'=>$item_hsdn->list_of_status,
                                                        'array_source'=>'1',
                                                        'selected_value'=>$item_hsdn->trang_thai
                                                    ))
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Người đại diện theo pháp luật</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control " id="nguoi_daidien"
                                                           name="nguoi_daidien" value="{{$item_hsdn->nguoi_daidien}}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Số chứng minh thư/hộ chiếu</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="cmt_hochieu"
                                                           name="cmt_hochieu" value="{{$item_hsdn->cmt_hochieu}}">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Ngày cấp</label>
                                                <div class="col-md-12">
                                                    <div id="dategiaoviec" class="input-group date">
                                                        <input type="text" name="ngaycap_cmt"
                                                               value="{{$item_hsdn->ngaycap_cmt}}" id="ngaycap_cmt"
                                                               class="form-control date_time">
                                                        <span class="input-group-addon"> <span
                                                                    class="glyphicon glyphicon-calendar"></span> </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Nơi cấp</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="noi_cap" name="noi_cap"
                                                           value="{{$item_hsdn->noi_cap}}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Chủ sở hữu</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="so_huu" name="so_huu"
                                                           value="{{$item_hsdn->so_huu}}">
                                                </div>
                                            </div>

                                            <div class="col-md-8">
                                                <label class="col-md-12" for="">Ngành nghề kinh doanh chính</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="kinhdoanh_chinh"
                                                           name="kinhdoanh_chinh"
                                                           value="{{$item_hsdn->kinhdoanh_chinh}}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <label class="col-md-12" for="">Ngành nghề kinh doanh</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="nganh_nghe"
                                                           name="nganh_nghe" value="{{$item_hsdn->nganh_nghe}}">
                                                </div>
                                            </div>
                                        </div>

                                        <div id="hienthi_nganh"></div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Ngày cấp</label>
                                                <div class="col-md-12">
                                                    <div id="dategiaoviec" class="input-group date">
                                                        <input type="text" name="ngay_cap"
                                                               value="{{$item_hsdn->ngay_cap}}" id="ngay_cap"
                                                               class="form-control date_time">
                                                        <span class="input-group-addon">
                                                            <span class="glyphicon glyphicon-calendar"></span>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Ngày đăng ký thay đổi</label>
                                                <div class="col-md-12">
                                                    <div id="dategiaoviec" class="input-group date">
                                                        <input type="text" name="ngay_thay_doi"
                                                               value="{{$item_hsdn->ngay_thay_doi}}" id="ngay_cap"
                                                               class="form-control date_time">
                                                        <span class="input-group-addon"> <span
                                                                    class="glyphicon glyphicon-calendar"></span> </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Loại hình doanh nghiệp</label>
                                                <div class="col-md-12">
                                                    @include('custom_controls.selectbox',
                                                    array('id'=>'loai_hinh',
                                                        'select_data'=>$list_loai_hinh_dn,
                                                        'value_member'=>'ma_lh',
                                                        'display_member'=>'ten_lh',
                                                        'selected_value'=>$item_hsdn->loai_hinh
                                                    ))
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Số lượng lao động</label>
                                                <div class="col-md-12">
                                                    <input type="number" class="form-control text-right" id="so_laodong"
                                                           name="so_laodong" min="1" value="{{$item_hsdn->so_laodong}}">
                                                </div>
                                            </div>

                                            <div class="col-md-8">
                                                <label class="col-md-12" for="">Danh sách thành viên góp vốn</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="ds_thanhvien"
                                                           name="ds_thanhvien" value="{{$item_hsdn->ds_thanhvien}}">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-8">
                                                <label class="col-md-12" for="">Danh sách cổ đông <span
                                                            style="color:red">(mỗi cổ đông ngăn cách nhau bởi dấu ",")</span>
                                                </label>
                                                <div class="col-md-12">
                                                    <textarea id="ds_codong" name="ds_codong"
                                                              style="width:100%; height:60px !important">{{$item_hsdn->ds_codong}}</textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="col-md-12" for="">Loại doanh nghiệp</label>
                                                <div class="col-md-12">
                                                    @include('custom_controls.selectbox',
                                                    array('id'=>'loai_dn',
                                                        'select_data'=>$item_hsdn->list_of_types,
                                                        'array_source'=>'1',
                                                        'selected_value'=>$item_hsdn->loai_dn
                                                    ))
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                        <div class="form-group">
                                            <div class="col-md-4">
                                                <span>
                                                  <input type="radio" id="duyet" name="duyet" value="1"
                                                         class="css-checkbox" checked="checked">
                                                  <label for="duyet" class="css-label radGroup1">Duyệt</label>
                                              </span>
                                            </div>
                                            <div class="col-md-4">
                                                <span>
                                                  <input type="radio" id="khong_duyet" name="duyet" value="2"
                                                         class="css-checkbox">
                                                  <label for="khong_duyet" class="css-label radGroup1">Không
                                                      duyệt</label>
                                              </span>
                                            </div>
                                            <div class="col-md-4" id="hien_lydo" style="display: none;">
                                                <label class="col-md-12" for="">Lý do
                                                    không duyệt</label>
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control input-sm input-default" id="ly_do" name="ly_do">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row_pc">
                                            <div class="text-center">
                                                <button type="button" form="editor-form-modal"
                                                        class="btn btn-primary btn-xs"
                                                        id="btn-save-modal">
                                                    <i class="fa fa-save"></i>&nbsp;Hoàn thành
                                                </button>
                                                {{--<button type="button" class="btn btn-danger btn-xs" id="btn-cancel-modal">--}}
                                                <button type="button" class="btn btn-danger btn-xs" data-dismiss="modal"
                                                        aria-label="Close" id="btn-cancel-modal">
                                                    <i class="fa fa-times"></i>&nbsp;Bỏ qua
                                                </button>
                                            </div>
                                        </div>
                                        <div class="clearfix-10"></div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class="clearfix-10"></div>
@stop

@section('javascript')
        {!! public_url('js/quanly_doanhnghiep/modal_edit.js')!!}
@stop



