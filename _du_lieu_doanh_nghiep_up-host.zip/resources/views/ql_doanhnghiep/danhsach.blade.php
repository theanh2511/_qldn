@extends('layouts.main')

@section('css')

@stop


@section('content')

    <ul class="duong_dan">
        <li><a href="../trungtamdieuhanh.htm"><i class="fa fa-home"></i></a></li>
        &gt;
        <li><a>Quản trị doanh nghiệp</a></li>
        &gt;
        <li class="tai_trang">{{$title ?? "Form name"}}</li>
    </ul>
    <div class="clearfix-10"></div>
    <section class="report_data dieu_hanh">
        <div class="container-fluid container-fluid-fix">
            <div class="row_pc">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="system">
                            <h2 class="title_message_news">{{$title ?? "Form name"}}</h2>
                            <form id="list-form" action="" method="POST" role="form">
                                <input type="hidden" id="trang_thai_duyet" name="trang_thai_duyet"
                                       value="{{$trang_thai}}">

                                <input type="file" id="select_excel_file" style="display: none;"
                                       name="select_excel_file"
                                       accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                                <div class="form_search">
                                    <div class="form_search">
                                        <div class="container-fluid">
                                            <div class="clearfix-10"></div>
                                            <div class="form-group">
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Mã số doanh nghiệp </label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="maso_dn"
                                                               name="maso_dn">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Tên doanh nghiệp</label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="ten_dn"
                                                               name="ten_dn">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Họ tên chủ doanh nghiệp</label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="so_huu"
                                                               name="so_huu">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix-10"></div>
                                            <div class="form-group">
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Quận huyện</label>
                                                    <div class="col-md-12">
                                                        @include('custom_controls.selectbox',
                                                        array('id'=>'quan_huyen',
                                                            'select_data'=>$list_quan_huyen,
                                                            'value_member'=>'ma_huyen',
                                                            'display_member'=>'ten_huyen',
                                                            'selected_value'=>''
                                                        ))
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Xã phường</label>
                                                    <div class="col-md-12" id="ht_xa">
                                                        @include('custom_controls.selectbox',
                                                        array('id'=>'xa_phuong',
                                                            'select_data'=>$list_xa_phuong,
                                                            'value_member'=>'ma_xa',
                                                            'display_member'=>'ten_xa',
                                                            'selected_value'=>''
                                                        ))
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Ngành nghề kinh doanh</label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="nganh_nghe"
                                                               name="nganh_nghe">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix-10"></div>
                                            <div class="row_pc">
                                                <div class="text-center">
                                                    <button type="button" class="btn btn-info btn-xs" id="btn-search">
                                                        <i class="fa fa-search"></i>&nbsp;Tìm kiếm
                                                    </button>
                                                    <a class="btn btn-primary btn-xs"
                                                       href="/quanly_doanhnghiep/hoso_doanhnghiep">
                                                        <i class="fa fa-plus"></i>&nbsp;Thêm mới</a>
                                                    <button type="button" id="btn-import-excel"
                                                            class="btn btn-primary btn-xs">
                                                        <i class="fa fa-plus"></i>&nbsp;Import excel hồ sơ doanh
                                                        nghiệp
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="clearfix-10"></div>
                                        </div>
                                    </div>
                                    <div class="table_out" id="responsive">
                                        <table id="table_data" class="table table-striped table-hover"
                                               style="border: 1px solid #ccc;">
                                            <thead class="text-center">
                                            <tr>
                                                <th style="width: 30px;">STT</th>
                                                <th width="6%">Mã số DN</th>
                                                <th>Tên doanh nghiệp</th>
                                                <th width="15%">Địa chỉ</th>
                                                <th width="8%">Số ĐT</th>
                                                <th width="15%"> Kinh doanh</th>
                                                <th width="8%">Người đại diện</th>
                                                <th width="8%">Trạng thái</th>
                                                <th width="20%">Chức năng</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($list_data as $key => $item)
                                                <tr>
                                                    <td>{{$key + 1}}</td>
                                                    <td>{{$item->maso_dn}}</td>
                                                    <td>{{$item->ten_dn}}</td>
                                                    <td>{{$item->diachi}}</td>
                                                    <td>{{$item->tel}}</td>
                                                    <td>{{$item->kinhdoanh_chinh}}</td>
                                                    <td>{{$item->nguoi_daidien}}</td>
                                                    <td>{{$item->ten_trang_thai}}</td>
                                                    <td class="text-center">
                                                        {{--0	Doanh nghiệp mới tạo -> Gửi trình--}}
                                                        {{--1	Doanh nghiệp chờ duyệt -> Duyệt hồ sơ--}}
                                                        {{--2	Doanh nghiệp không được duyệt -> Duyệt hồ sơ--}}
                                                        {{--3	Doanh nghiệp đã duyệt--}}
                                                        @if($trang_thai==0)
                                                            <a class="btn btn-primary btn-xs"
                                                               href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                                                                <i class="fa fa-edit"></i>&nbsp;Sửa
                                                            </a>
                                                            <button type="button"
                                                                    class="btn btn-danger btn-xs btn-delete"
                                                                    data-primary_key="{{$item->id}}">
                                                                <i class="fa fa-times"></i>&nbsp;Xóa
                                                            </button>
                                                            <button type="button" data-primary_key="{{$item->id}}"
                                                                    class="btn btn-info btn-xs btn-send-file">
                                                                <i class="fa fa-user"></i>&nbsp;Gửi trình
                                                            </button>
                                                        @elseif($trang_thai==1)
                                                            <a class="btn btn-primary btn-xs"
                                                               href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                                                                <i class="fa fa-edit"></i>&nbsp;Đính chính
                                                            </a>
                                                            <button type="button" data-primary_key="{{$item->id}}"
                                                                    class="btn btn-success btn-xs btn-approve">
                                                                <i class="fa fa-edit"></i>&nbsp;Duyệt hồ sơ
                                                            </button>
                                                        @elseif($trang_thai==2)
                                                            <a class="btn btn-primary btn-xs"
                                                               href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                                                                <i class="fa fa-edit"></i>&nbsp;Sửa
                                                            </a>
                                                            <button type="button"
                                                                    class="btn btn-danger btn-xs btn-delete"
                                                                    data-primary_key="{{$item->id}}">
                                                                <i class="fa fa-times"></i>&nbsp;Xóa
                                                            </button>
                                                            <button type="button" data-primary_key="{{$item->id}}"
                                                                    class="btn btn-info btn-xs btn-send-file">
                                                                <i class="fa fa-user"></i>&nbsp;Gửi trình
                                                            </button>
                                                        @else
                                                            <a class="btn btn-primary btn-xs"
                                                               href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                                                                <i class="fa fa-edit"></i>&nbsp;Đính chinh
                                                            </a>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class="clearfix-10"></div>
    {{--=============Modal=============--}}
    <div class="modal fade" id="modal_duyet_ho_so" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true ">
        <div class="modal-dialog modal-lg" role="document " style="width:96% !important">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="exampleModalLabel">Duyệt thông tin hồ sơ doanh nghiệp</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true ">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                </div>
            </div>
        </div>
    </div>
@stop

@section('javascript')
    {!! public_url('js/quanly_doanhnghiep/list.js')!!}
@stop



