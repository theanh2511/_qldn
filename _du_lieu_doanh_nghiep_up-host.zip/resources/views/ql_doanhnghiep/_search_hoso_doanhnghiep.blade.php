@if($list_data->count()!=0)
    @foreach($list_data as $key => $item)
        <tr>
            <td>{{$key + 1}}</td>
            <td>{{$item->maso_dn}}</td>
            <td>{{$item->ten_dn}}</td>
            <td>{{$item->diachi}}</td>
            <td>{{$item->tel}}</td>
            <td>{{$item->kinhdoanh_chinh}}</td>
            <td>{{$item->nguoi_daidien}}</td>
            <td>{{$item->ten_trang_thai}}</td>
            <td class="text-center">
                {{--0	Doanh nghiệp mới tạo -> Gửi trình--}}
                {{--1	Doanh nghiệp chờ duyệt -> Duyệt hồ sơ--}}
                {{--2	Doanh nghiệp không được duyệt -> Duyệt hồ sơ--}}
                {{--3	Doanh nghiệp đã duyệt--}}
                @if($trang_thai==0)
                    <a class="btn btn-primary btn-xs"
                       href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                        <i class="fa fa-edit"></i>&nbsp;Sửa
                    </a>
                    <button type="button"
                            class="btn btn-danger btn-xs btn-delete"
                            data-primary_key="{{$item->id}}">
                        <i class="fa fa-times"></i>&nbsp;Xóa
                    </button>
                    <button type="button" data-primary_key="{{$item->id}}"
                            class="btn btn-info btn-xs btn-send-file">
                        <i class="fa fa-user"></i>&nbsp;Gửi trình
                    </button>
                @elseif($trang_thai==1)
                    <a class="btn btn-primary btn-xs"
                       href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                        <i class="fa fa-edit"></i>&nbsp;Đính chính
                    </a>
                    <button type="button" data-primary_key="{{$item->id}}"
                            class="btn btn-success btn-xs btn-approve">
                        <i class="fa fa-edit"></i>&nbsp;Duyệt hồ sơ
                    </button>
                @elseif($trang_thai==2)
                    <a class="btn btn-primary btn-xs"
                       href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                        <i class="fa fa-edit"></i>&nbsp;Sửa
                    </a>
                    <button type="button"
                            class="btn btn-danger btn-xs btn-delete"
                            data-primary_key="{{$item->id}}">
                        <i class="fa fa-times"></i>&nbsp;Xóa
                    </button>
                    <button type="button" data-primary_key="{{$item->id}}"
                            class="btn btn-info btn-xs btn-send-file">
                        <i class="fa fa-user"></i>&nbsp;Gửi trình
                    </button>
                @else
                    <a class="btn btn-primary btn-xs"
                       href="/quanly_doanhnghiep/hoso_doanhnghiep/{{$item->id}}">
                        <i class="fa fa-edit"></i>&nbsp;Đính chinh
                    </a>
                @endif
            </td>
        </tr>
    @endforeach
@else
    <tr>
        <td colspan="9">{{__('system.no_records')}}</td>
    </tr>
@endif