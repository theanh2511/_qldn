@php
    $select_data;
    $selected_value;

    $value_member = isset($value_member)?$value_member:'id';
    $display_member = isset($display_member)?$display_member:'code';
    $show_code_name= isset($show_code_name)?$show_code_name:'0';
@endphp

<select class="_select select2 form-control custom-select {{isset($class)?$class:''}}"
        {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
        name="{{isset($name)?$name:(isset($id)?$id:null)}}"
        {{isset($multiple)&&$multiple=='1'?"multiple":'id'}} style="width: 100%; height:36px;border: none;">
    <optgroup class='def-cursor' label='Mã' data-name='Tên'>
        <option data-name="" value="">---</option>
        @foreach($select_data as $item)
            <option
                    @php
                        if(isset($arr_attributes)){
                        foreach($arr_attributes as $arr_attribute){
                                echo  ("data-".$arr_attribute.'="'. $item->$arr_attribute .'"');
                            }
                        }else{
                        echo  ('data-name="'. ($item->name??"") .'"');
                        }
                    @endphp
                    value="{{$item->$value_member}}" {{$item->$value_member==$selected_value?'selected':''}}>
                @php
                    if($show_code_name=='1'){
                        echo  ($item->code.": ".$item->name);
                    }else{
                        echo  ($item->$display_member);
                    }
                @endphp
            </option>
        @endforeach

    </optgroup>
    {{--<optgroup label="Alaskan/Hawaiian Time Zone">
        <option value="AK">Alaska</option>
        <option value="HI">Hawaii</option>
    </optgroup>--}}

</select>