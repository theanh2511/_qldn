<div class="input-group">
    <div class="input-group-addon div-calendar" style="display: inline-flex;">
        <input type="text" id="{{isset($id)?$id:''}}"
               autocomplete="off"
               class="form-control datepicker {{isset($class)?$class:''}}"
               name="{{isset($name)?$name:(isset($id)?$id:null)}}"
               value="{{isset($value)?$value:''}}"
               {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
               placeholder="dd/mm/yyyy">
        <div class="input-group-append div-calendar">
        <span class="input-group-text">
            <i class="far fa-calendar-alt"></i>
        </span>
        </div>

        <span style="width: 30px; text-align: center; padding-top: 5px;font-size: 16px;font-weight: 600;"> ~ </span>
    </div>
    <div class="input-group-addon div-calendar" style="display: inline-flex;">
        <input type="text" id="{{isset($id2)?$id2:''}}"
               autocomplete="off"
               class="form-control datepicker {{isset($class)?$class:''}}"
               name="{{isset($name2)?$name2:(isset($id2)?$id2:null)}}"
               value="{{isset($value2)?$value2:''}}"
               {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
               placeholder="dd/mm/yyyy">
        <div class="input-group-append div-calendar">
        <span class="input-group-text">
            <i class="far fa-calendar-alt"></i>
        </span>
        </div>
    </div>

</div>