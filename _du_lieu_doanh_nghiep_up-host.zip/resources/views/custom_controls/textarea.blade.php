<textarea id="{{isset($id)?$id:''}}" placeholder="{{isset($placeholder)?$placeholder:''}}"
          {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
          class="form-control input-sm input-default {{isset($class)?$class:''}} {{isset($is_required) && $is_required ?'required':''}}"
          rows="{{isset($number_of_row)?$number_of_row:3}}" cols="100" wrap="hard"
          name="{{isset($name)?$name:(isset($id)?$id:null)}}">{{isset($value)?$value:''}}</textarea>