{{--<div class="input-group div-calendar">--}}
    {{--<input type="text" id="{{isset($id)?$id:''}}"--}}
           {{--autocomplete="off"--}}
           {{--class="form-control datepicker {{isset($class)?$class:''}}"--}}
           {{--name="{{isset($name)?$name:(isset($id)?$id:null)}}"--}}
           {{--value="{{isset($value)?$value:''}}"--}}
           {{--{{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}--}}
           {{--placeholder="dd/mm/yyyy">--}}
    {{--<div class="input-group-append">--}}
        {{--<span class="input-group-text">--}}
            {{--<i class="far fa-calendar-alt"></i>--}}
        {{--</span>--}}
    {{--</div>--}}
{{--</div>--}}

<input type="date" id="{{isset($id)?$id:''}}" name="{{isset($id)?$id:''}}"
       value="{{isset($value)?$value:''}}"
       placeholder="dd/mm/yyyy" autocomplete="off"
       {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
       class="form-control input-sm input-default {{isset($class)?$class:''}}">