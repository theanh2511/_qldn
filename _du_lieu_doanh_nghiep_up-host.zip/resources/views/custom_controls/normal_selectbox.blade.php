@php
    $select_data;
    $selected_value;
@endphp

<select class="form-control {{isset($class)?$class:''}}"
        name="{{isset($name)?$name:(isset($id)?$id:null)}}"
        style="width: 100%; height:36px;">
    @foreach($select_data as $key=>$value)
        <option value="{{$key}}" {{$key==$selected_value?'selected':''}}>{{$value}}</option>
    @endforeach
</select>