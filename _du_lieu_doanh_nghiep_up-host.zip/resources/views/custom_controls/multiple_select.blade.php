@php
    $select_data;
    $selected_value;

    $value_member = isset($value_member)?$value_member:'id';
@endphp

<select class="form-control selectpicker {{isset($class)?$class:""}}" data-live-search="true"
        name="{{isset($name)?$name:(isset($id)?$id:null)}}" multiple style="width: 100%; height:36px;">
    {{--<option value="">---</option>--}}
    @foreach($select_data as $item)
        <option value="{{$item->$value_member}}" {{in_array($item->$value_member,explode(",",$selected_value)) ?'selected':''}}>{{$item->code}}</option>
    @endforeach

    {{--<optgroup label="Alaskan/Hawaiian Time Zone">
        <option value="AK">Alaska</option>
        <option value="HI">Hawaii</option>
    </optgroup>--}}

</select>