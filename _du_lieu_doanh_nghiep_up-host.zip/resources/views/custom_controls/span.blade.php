@php
    $col    = isset($col) ? $col : 'col-md-3 col-sm-3 col-xs-6 m-t-15';
@endphp
<span id="{{isset($id)?$id:''}}" class="{{isset($col)?$col:''}} {{isset($class)?$class:''}}"
       style="text-align: left;white-space:normal;">{{ $text?:''}}
    <span class="lbl-required">{{isset($is_required)&&$is_required=='1'?' * ':''}}</span>
</span>