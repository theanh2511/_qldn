<input type="file"
       id="{{isset($id)?$id:''}}" placeholder="{{isset($placeholder)?$placeholder:''}}"
       {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
       name="{{isset($name)?$name:(isset($id)?$id:null)}}"
       class="form-control  input-sm input-default input-sm {{isset($class)?$class:''}}"/>