<input type="text" id="{{isset($id)?$id:''}}" placeholder="{{isset($placeholder)?$placeholder:''}}"
       {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
       class="form-control input-sm input-default input-sm {{isset($class)?$class:''}} {{isset($is_required) && $is_required ?'required':''}}"
       name="{{isset($name)?$name:(isset($id)?$id:null)}}"
       value="{{isset($value)?$value:''}}"
       title="{{isset($value)?$value:''}}">