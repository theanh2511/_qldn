@php
    $select_data;
    $selected_value;

    $value_member = isset($value_member)?$value_member:'id';
    $display_member = isset($display_member)?$display_member:'';
    $array_source = isset($array_source)?$array_source:'0';
@endphp

<select class="form-control input-sm input-default input-sm {{isset($class)?$class:''}}"
        {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
        name="{{isset($name)?$name:(isset($id)?$id:null)}}"
        {{isset($multiple)&&$multiple=='1'?"multiple":'id'}} style="font-weight: {{isset($is_bold)&&$is_bold=='1'?"700":'500'}};font-style: {{isset($is_italic)&&$is_italic=='1'?"italic":'normal'}};">
    <option value="">=== Lựa chọn ===</option>
    @foreach($select_data as $key => $item)
        @if($array_source!='1')
            <option
                    @php
                        if(isset($arr_attributes)){
                        foreach($arr_attributes as $arr_attribute){
                                echo  ("data-".$arr_attribute.'="'. $item->$arr_attribute .'"');
                            }
                        }else{
                        echo  ('data-name="'. ($item->name??"") .'"');
                        }
                    @endphp
                    value="{{$item->$value_member}}" {{$item->$value_member==$selected_value?'selected':''}}
                    title="{{$item->$display_member}}">{{$item->$display_member}}
            </option>
        @else
            <option value="{{$key}}" {{$key==$selected_value?'selected':''}}
                    title="{{$item}}">{{$item}}
            </option>
        @endif
    @endforeach
</select>