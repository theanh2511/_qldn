<input type="text" id="{{isset($id)?$id:''}}" placeholder="{{isset($placeholder)?$placeholder:''}}"
       {{(isset($disabled)?$disabled:'')=="1"?"disabled":""}}
       class="form-control input-sm input-default input-sm money {{isset($class)?$class:''}} {{isset($is_required) && $is_required ?'required':''}}"
       real_len="{{(isset($real_len)?$real_len:'12')}}"
       decimal_len="{{(isset($decimal_len)?$decimal_len:'0')}}"
       name="{{isset($name)?$name:(isset($id)?$id:null)}}"
       value="{{isset($value)?$value:''}}"
       style="text-align: right;">