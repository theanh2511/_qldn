<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead class="text-center">
    <tr>
        <th>STT</th>
        <th>Mã xã</th>
        <th>Tên xã</th>
        <th></th>
        <th>Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as  $key => $value)
        <tr>
            <td width="5%" class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td width="15%" class="ma_xa">{{$value->ma_xa}}</td>
            <td class="ten_xa">{{$value->ten_xa}}</td>
            <td class="ma_tinh hidden">{{$value->ma_tinh}}</td>
            <td class="ma_huyen hidden">{{$value->ma_huyen}}</td>
            <td class="ghichu hidden">{{$value->ghichu}}</td>
            @include('layouts.grid_buttons')
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>