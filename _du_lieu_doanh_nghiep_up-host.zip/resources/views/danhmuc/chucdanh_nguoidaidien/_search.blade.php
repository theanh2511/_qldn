<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead class="text-center">
    <tr>
        <th>STT</th>
        <th>Mã chức danh</th>
        <th>Tên chức danh</th>
        <th></th>
        <th>Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as  $key => $value)
        <tr>
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="ma_chuc_danh">{{$value->ma_chuc_danh}}</td>
            <td class="ten_chuc_danh">{{$value->ten_chuc_danh}}</td>
            <td class="ghichu hidden">{{$value->ghichu}}</td>
            @include('layouts.grid_buttons')
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>