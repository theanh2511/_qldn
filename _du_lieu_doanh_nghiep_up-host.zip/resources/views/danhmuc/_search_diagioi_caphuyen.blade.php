@foreach($list_data as  $key => $value)
    <tr>
        <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
        <td class="ma_huyen">{{$value->ma_huyen}}</td>
        <td class="ten_huyen">{{$value->ten_huyen}}</td>
        <td class="text-center">
            <a class="btn btn-primary btn-xs btn-edit"
               data-primary_key="{{$value->id}}"><i class="fa fa-edit"></i>&nbsp;Đính chính</a>
        </td>
    </tr>
@endforeach