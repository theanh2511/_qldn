@extends('layouts.main')

@section('css')

@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>{{$title ?? "Form name"}}</h1>
                    </div>
                </div>
            </div><!-- /# column -->
            <div class="col-lg-7 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Quản trị doanh nghiệp</a></li>
                            <li class="active">{{$title ?? "Form name"}}</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /# column -->
        </div><!-- /# row -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="search-form"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      class="form-horizontal">@csrf
                                    <div class="form_search">
                                        <div class="form_search">
                                            <div class="container-fluid">
                                                <div class="clearfix-10"></div>
                                                <div class="form-group">
                                                    <div class="col-md-4">
                                                        <label class="col-md-12" for="">Mã quốc tịch </label>
                                                        <div class="col-md-12">
                                                            <input type="text" class="form-control input-sm input-default" id="ma_qt" name="ma_qt">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="col-md-12" for="">Tên quốc tịch</label>
                                                        <div class="col-md-12">
                                                            <input type="text" class="form-control input-sm input-default" id="ten_qt" name="ten_qt">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="">&nbsp;</label>
                                                        @include('layouts.buttons_danhmuc')
                                                    </div>
                                                </div>
                                                <div class="clearfix-10"></div>
                                                <div class="clearfix-10"></div>
                                            </div>
                                        </div>
                                        <div class="table_out" id="responsive">
                                            <table id="table_data" class="table table-striped table-hover"
                                                   style="border: 1px solid #ccc;">
                                                <thead class="text-center">
                                                <tr>
                                                    <th>STT</th>
                                                    <th>Mã quốc tịch</th>
                                                    <th>Tên quốc tịch</th>
                                                    <th></th>
                                                    <th>Chức năng</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                @foreach($list_data as  $key => $value)
                                                    <tr>
                                                        <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
                                                        <td class="ma_qt">{{$value->ma_qt}}</td>
                                                        <td class="ten_qt">{{$value->ten_qt}}</td>
                                                        <td class="ghichu hidden">{{$value->ghichu}}</td>
                                                        @include('layouts.grid_buttons')
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                            <center>
                                                {{ $list_data->links() }}
                                            </center>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div><!-- /# column -->
            </div>
        </div><!-- /# column -->
    </div>

    <div id="modal_editor" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Thêm mới loại hình doanh nghiệp</h4>
                </div>
                <div class="modal-body">
                    <form id="editor-form"
                          action="{{ url('/danhmuc/'.$command_key.'/update') }}"
                          method="POST"
                          enctype="multipart/form-data"
                          class="form-horizontal">@csrf
                        <input type="hidden" id="primary_key" name="id" value="">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Mã quốc tịch</label>
                                    <input name="ma_qt" type="text" class="form-control input-sm input-default">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Tên quốc tịch</label>
                                    <input name="ten_qt" type="text" class="form-control  input-sm input-default ">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label>Ghi chú</label>
                                    <textarea name="ghichu" class="form-control input-default input-sm"
                                              rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" form="editor-form" id="btn-save" class="btn btn-info btn-sm ">Cập nhật
                    </button>
                    <button type="button" class="btn btn-default btn-sm " data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
@stop

@section('javascript')
    <script>
        var _command_key = '<?php echo $command_key ?>';
        $(document).ready(function () {
            /**
             * @Description: Process display function button on screen
             */
            $(document).on('click', '.btn-edit', function (e) {
                var _row_detail = $(this).parents('tr');
                $('#primary_key').val($(this).data('primary_key'));
                $('#modal_editor').find('input[name="ma_qt"]').val(_row_detail.find('.ma_qt').text());
                $('#modal_editor').find('input[name="ten_qt"]').val(_row_detail.find('.ten_qt').text());
                $('#modal_editor').find('textarea[name="ghichu"]').val(_row_detail.find('.ghichu').text());

                $('#modal_editor').modal('show');
            });
            ///End: Process display function button on screen
        });
    </script>
    {!! public_url('js/danhmuc/func_danhmuc.js')!!}
@stop