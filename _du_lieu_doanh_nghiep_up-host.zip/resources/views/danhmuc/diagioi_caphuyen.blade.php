@extends('layouts.main')

@section('css')

@stop


@section('content')
    <ul class="duong_dan">
        <li><a href="../trungtamdieuhanh.htm"><i class="fa fa-home"></i></a></li>
        &gt;
        <li><a>Quản trị doanh nghiệp</a></li>
        &gt;
        <li class="tai_trang">{{$title ?? "Form name"}}</li>
    </ul>
    <div class="clearfix-10"></div>
    <section class="report_data dieu_hanh">
        <div class="container-fluid container-fluid-fix">
            <div class="row_pc">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="system">
                            <h2 class="title_message_news">{{$title ?? "Form name"}}</h2>
                            <form id="editor-form"
                                  action="{{ url('/danhmuc/diagioi_caphuyen/update') }}"
                                  method="POST"
                                  enctype="multipart/form-data"
                                  class="form-horizontal">@csrf
                                <input type="hidden" id="primary_key" name="id" value="">
                                <div class="form_search">
                                    <div class="form_search">
                                        <div class="container-fluid">
                                            <div class="clearfix-10"></div>
                                            <div class="form-group">
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Mã huyện </label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="ma_huyen"
                                                               name="ma_huyen">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Tên huyện</label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="ten_huyen"
                                                               name="ten_huyen">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="col-md-12" for="">Số thứ tự hiển thị</label>
                                                    <div class="col-md-12">
                                                        <input type="text" class="form-control input-sm input-default" id="stt_ht"
                                                               name="stt_ht">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix-10"></div>
                                            <div class="clearfix-10"></div>
                                            <div class="row_pc">
                                                <div class="text-center">
                                                    <a class="btn btn-info btn-xs" id="btn-search">
                                                        <i class="fa fa-search"></i>&nbsp;Tìm kiếm</a>
                                                    <button type="button" class="btn btn-success btn-xs" id="btn-add">
                                                        <i class="fa fa-plus"></i>&nbsp;Thêm mới</button>
                                                    <button type="submit" form="editor-form"
                                                            class="btn btn-success btn-xs" id="btn-save" style="display: none;">
                                                        <i class="fa fa-save"></i>&nbsp;Lưu</button>
                                                    <button type="button" class="btn btn-danger btn-xs" id="btn-delete" style="display: none;">
                                                        <i class="fa fa-remove"></i>&nbsp;Xóa</button>
                                                    <a class="btn btn-danger btn-xs" id="btn-cancel" style="display: none;">
                                                        <i class="fa fa-ban"></i>&nbsp;Hủy</a>
                                                </div>
                                            </div>
                                            <div class="clearfix-10"></div>
                                        </div>
                                    </div>
                                    <div class="table_out" id="responsive">
                                        <table id="table_data" class="table table-striped table-hover" style="border: 1px solid #ccc;">
                                            <thead class="text-center">
                                            <tr>
                                                <th>STT</th>
                                                <th>Mã huyện</th>
                                                <th>Tên huyện</th>
                                                <th>Chức năng</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($list_data as  $key => $value)
                                                <tr>
                                                    <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
                                                    <td class="ma_huyen">{{$value->ma_huyen}}</td>
                                                    <td class="ten_huyen">{{$value->ten_huyen}}</td>
                                                    <td class="text-center">
                                                        <a class="btn btn-primary btn-xs btn-edit"
                                                           data-primary_key="{{$value->id}}"><i class="fa fa-edit"></i>&nbsp;Đính
                                                            chính</a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
@stop

@section('javascript')
    {!! public_url('js/danhmuc/diagioi_caphuyen.js')!!}
@stop