@extends('layouts.main')

@section('css')

@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Người chưa được cấp mã số BHXH</h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Bảo hiểm</a></li>
                            <li class="active">Người chưa được cấp mã số BHXH</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="editor-form"
                                      action="{{ url('/quanly_baohiem/nguoichuacapbhxh/update/'.($item_hsbh->id??"")) }}"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      class="form-horizontal">@csrf
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số đơn vị</label>
                                                @include('custom_controls.textbox', array('id'=>'maso_dn', 'value'=>$item_hsbh->maso_dn))
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Tên đơn vị</label>
                                                @include('custom_controls.textbox', array('id'=>'ten_dn', 'value'=>$item_hsbh->ten_dn,'disabled'=>'1'))
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Họ và tên</label>
                                                @include('custom_controls.textbox', array('id'=>'ten_ca_nhan', 'value'=>$item_hsbh->ten_ca_nhan))
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Ngày/tháng/năm sinh</label>
                                                @include('custom_controls.datepicker', array('id'=>'ngay_sinh', 'value'=>$item_hsbh->ngay_sinh))
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Giới tính</label>
                                                @include('custom_controls.selectbox',
                                                array('id'=>'gioi_tinh',
                                                'select_data'=>$item_hsbh->list_of_gender,
                                                'array_source'=>'1',
                                                'selected_value'=>$item_hsbh->gioi_tinh
                                                ))
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Quốc tịch</label>
                                                @include('custom_controls.textbox', array('id'=>'quoc_tich', 'value'=>$item_hsbh->quoc_tich))
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Dân tộc</label>
                                                @include('custom_controls.textbox', array('id'=>'dan_toc', 'value'=>$item_hsbh->dan_toc))
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Nơi đăng ký giấy khai sinh</label>
                                                @include('custom_controls.textbox', array('id'=>'dangky_khaisinh', 'value'=>$item_hsbh->dangky_khaisinh))
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Địa chỉ nhận kết quả</label>
                                                @include('custom_controls.textbox', array('id'=>'diachi', 'value'=>$item_hsbh->diachi))
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Số CMND/Hộ chiếu/Thẻ căn cước</label>
                                                @include('custom_controls.textbox', array('id'=>'so_cmt', 'value'=>$item_hsbh->so_cmt))
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Số điện thoại liên hệ</label>
                                                @include('custom_controls.textbox', array('id'=>'tel', 'value'=>$item_hsbh->tel))
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Họ tên cha/mẹ/giám hộ (đối với trẻ em < 6 tuổi)</label>
                                                @include('custom_controls.textbox', array('id'=>'nguoi_giam_ho', 'value'=>$item_hsbh->nguoi_giam_ho))
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mức tiền đóng</label>
                                                @include('custom_controls.numeric', array('id'=>'muc_tien_dong', 'value'=>$item_hsbh->muc_tien_dong))
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Phương thức đóng</label>
                                                @include('custom_controls.textbox', array('id'=>'phuongthuc_dong', 'value'=>$item_hsbh->phuongthuc_dong))
                                            </div>
                                        </div>


                                        <div class="col-lg-12" style="text-align: center;">
                                            @if($item_hsbh->id)
                                                <button type="submit" class="btn btn-info  btn-addon m-b-10 m-l-5">
                                                    <i class="ti-save"></i>Lưu
                                                </button>
                                            @else
                                                <button type="submit" class="btn btn-info  btn-addon m-b-10 m-l-5">
                                                    <i class="ti-plus"></i>Thêm mới
                                                </button>
                                            @endif
                                            <button type="button" id="btn-back" class="btn btn-danger btn-addon m-b-10 m-l-5"><i
                                                        class="ti-close"></i>Hủy bỏ
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div><!-- /# card -->
            </div><!-- /# column -->
        </div><!-- /# row -->
    </div>
@stop

@section('javascript')
    {!! public_url('js/quanly_baohiem/edit_baohiem_cn.js')!!}
@stop



