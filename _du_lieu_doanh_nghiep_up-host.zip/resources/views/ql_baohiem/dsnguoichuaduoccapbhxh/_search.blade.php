<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Họ và tên</th>
        <th>Số CMND/Hộ chiếu</th>
        <th>Họ tên cha/mẹ/giám hộ (đối với trẻ em < 6 tuổi)</th>
        <th></th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as $key => $value)
        <tr data-object_value="{{$value->toJson()}}">
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="ten_ca_nhan">{{$value->ten_ca_nhan}}</td>
            <td class="so_cmt">{{$value->so_cmt}}</td>
            <td class="nguoi_giam_ho">{{$value->nguoi_giam_ho}}</td>
            <td>
                <button type="button"
                        class="btn btn-info btn-addon btn-xs m-b-10 btn-cap-bhxh"
                        data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                            class="fa fa-check" aria-hidden="true"></i>Cấp BHXH
                </button>
            </td>
            @include('layouts.baohiem_grid_buttons')
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>