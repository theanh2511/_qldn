@extends('layouts.main')

@section('css')
    <style>
        .tb-modal-bhxh th, .tb-modal-bhxh td {
            text-align: left;
            border: none !important;
        }

        tbody tr td:last-child {
            text-align: left;
        }
    </style>
@stop


@section('content')

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Danh sách người chưa được cấp BHXH</h1>
                    </div>
                </div>
            </div><!-- /# column -->
            <div class="col-lg-7 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Bảo hiểm</a></li>
                            <li class="active">Danh sách người chưa được cấp BHXH</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /# column -->
        </div><!-- /# row -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <!-- <div class="card-header">
                            <h4>Danh sách đơn vị mới tạo</h4>
                            <div class="card-header-right-icon">
                                <ul>
                                    <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                                    <li class="doc-link"><a href="#"><i class="ti-link"></i></a></li>
                                </ul>
                            </div>
                        </div> -->
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="search-form"
                                      method="POST"
                                      action="/quanly_baohiem/ds_bhxh/search"
                                      enctype="multipart/form-data"
                                      class="form-horizontal">@csrf
                                    <input type="hidden" name="trang_thai" value="1">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Họ và tên</label>
                                                @include('custom_controls.textbox', array('id'=>'ten_ca_nhan', 'value'=>""))
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Số CMND/Hộ chiếu/Thẻ căn cước</label>
                                                @include('custom_controls.textbox', array('id'=>'so_cmt', 'value'=>""))
                                            </div>
                                        </div>


                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label class="col-lg-12">&nbsp; </label>
                                                <button type="button" id="btn-search"
                                                        class="btn btn-success btn-addon btn-sm m-b-10 m-l-5">
                                                    <i class="ti-search"></i>Tìm kiếm
                                                </button>
                                            </div>
                                        </div>


                                    </div>
                                </form>
                            </div>
                            <div class="table_out" id="responsive">
                                <table id="table_data" class="table table-striped table-hover"
                                       style="border: 1px solid #ccc;">
                                    <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Họ và tên</th>
                                        <th>Số CMND/Hộ chiếu</th>
                                        <th>Họ tên cha/mẹ/giám hộ (đối với trẻ em < 6 tuổi)</th>
                                        <th></th>
                                        <th style="width: 200px;text-align: center;">Chức năng</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($list_data as $key => $value)
                                        <tr data-object_value="{{$value->toJson()}}">
                                            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
                                            <td class="ten_ca_nhan">{{$value->ten_ca_nhan}}</td>
                                            <td class="so_cmt">{{$value->so_cmt}}</td>
                                            <td class="nguoi_giam_ho">{{$value->nguoi_giam_ho}}</td>
                                            <td>
                                                <button type="button"
                                                        class="btn btn-info btn-addon btn-xs m-b-10 btn-cap-bhxh"
                                                        data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                                                            class="fa fa-check" aria-hidden="true"></i>Cấp BHXH
                                                </button>
                                            </td>
                                            @include('layouts.baohiem_grid_buttons')
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                                <center>
                                    {{ $list_data->links() }}
                                </center>
                            </div>
                        </div>
                    </div>
                </div><!-- /# column -->
            </div>
        </div><!-- /# card -->
    </div><!-- /# column -->


    {{--Modal view information--}}
    <div id="modal_view" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Xem thông tin chi tiết doanh nghiệp tham gia bảo hiểm mới</h4>
                </div>
                <div class="modal-body">
                    <table id="modal-table" class="table table-responsive tb-modal-bhxh table-hover"
                           style="font-size: 13px;">
                        <tbody>
                        <tr>
                            <td><strong>Họ và tên</strong></td>
                            <td class="ten_ca_nhan" field_name="ten_ca_nhan"></td>
                            <td><strong>Ngày tháng năm sinh</strong></td>
                            <td class="ngay_sinh" field_name="ngay_sinh"></td>

                        </tr>
                        <tr>
                            <td><strong>Giới tính</strong></td>
                            <td field_name="gender_name"></td>
                            <td><strong>Dân tộc</strong></td>
                            <td field_name="dan_toc"></td>

                        </tr>
                        <tr>
                            <td><strong>Nơi đăng ký giấy khai sinh</strong></td>
                            <td field_name="dangky_khaisinh"></td>
                            <td><strong>Địa chỉ nhận kết quả</strong></td>
                            <td field_name="diachi"></td>

                        </tr>
                        <tr>
                            <td><strong>Số CMND/Hộ chiếu/Thẻ căn cước</strong></td>
                            <td field_name="so_cmt"></td>
                            <td><strong>Số điện thoại liên hệ</strong></td>
                            <td field_name="tel"></td>

                        </tr>
                        <tr>
                            <td><strong>Họ tên cha/mẹ/giám hộ</strong></td>
                            <td class="field_name" field_name="nguoi_giam_ho"></td>
                            <td><strong>Mức tiền đóng</strong></td>
                            <td field_name="muc_tien_dong"></td>

                        </tr>
                        <tr>
                            <td><strong>Phương thức đóng</strong></td>
                            <td field_name="phuongthuc_dong"></td>
                        </tr>

                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                </div>
            </div>

        </div>
    </div>

    {{--Modal: Cấp BHXH--}}
    <div id="modal_duyet_bhxh" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Duyệt hồ sơ</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="primary_key">
                    <table class="table table-responsive tb-modal-bhxh">
                        <tbody>
                        <tr>
                            <td><strong>Ngày cấp</strong></td>
                            <td>
                                @include('custom_controls.datepicker', array('id'=>'ngaycap_bhxh', 'value'=>''))
                            </td>
                            <td><strong>Mã số BHXH</strong></td>
                            <td>
                                @include('custom_controls.textbox', array('id'=>'maso_bhxh', 'value'=>''))
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Ghi chú/Lý do</strong></td>
                            <td colspan="3">
                                @include('custom_controls.textarea', array('id'=>'ghichu', 'value'=>''))
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer" style="text-align: center;">
                    <button type="button" id="btn-cap-bhxh" class="btn btn-info btn-addon btn-sm m-b-10">
                        <i class="fa fa-check" aria-hidden="true"></i>Cấp BHXH
                    </button>

                    <button type="button" class="btn btn-default btn-sm m-b-10 pull-right" data-dismiss="modal">Đóng
                    </button>


                </div>
            </div>

        </div>
    </div>
@stop

@section('javascript')
    <script>
        $(document).ready(function () {
            /**
             * Process display function button on screen
             */
            $(document).on('click', '.btn-edit', function (e) {
                var _tr = $(this).parents('tr');
                var _obj_value = _tr.data('object_value');

                location.href = "/quanly_baohiem/nguoichuacapbhxh/" + _obj_value["id"];
            });
            ///End: Process display function button on screen
        });
    </script>
    {!! public_url('js/quanly_baohiem/list.js')!!}
@stop