<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số đơn vị</th>
        <th>Tên đơn vị</th>
        <th>Mã số thuế</th>
        <th>Số điện thoại</th>
        <th>Email</th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as $key => $value)
        <tr data-object_value="{{$value->toJson()}}"
            data-list_cnbhxh="{{$value->getDanhSachCaNhanBHXH()}}">
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="maso_dn">{{$value->maso_dn}}</td>
            <td class="ten_dn">{{$value->ten_dn}}</td>
            <td class="maso_thue">{{$value->maso_thue}}</td>
            <td class="tel">{{$value->tel}}</td>
            <td class="email">{{$value->email}}</td>
            @include('layouts.baohiem_grid_buttons')
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>