@extends('layouts.main')

@section('css')
    <style>
        .tb-modal-bhxh th, .tb-modal-bhxh td {
            text-align: left;
            border: none !important;
        }

        tbody tr td:last-child {
            text-align: left;
        }
    </style>
@stop


@section('content')

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>{{$title}}</h1>
                    </div>
                </div>
            </div><!-- /# column -->
            <div class="col-lg-7 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Bảo hiểm</a></li>
                            <li class="active">{{$title}}</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /# column -->
        </div><!-- /# row -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="search-form"
                                      method="POST"
                                      action="/quanly_baohiem/search"
                                      enctype="multipart/form-data"
                                      class="form-horizontal">@csrf
                                    <input type="hidden" name="trang_thai" id="trang_thai" value="1">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số đơn vị</label>
                                                @include('custom_controls.textbox', array('id'=>'maso_dn', 'value'=>""))
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Tên đơn vị</label>
                                                @include('custom_controls.textbox', array('id'=>'ten_dn', 'value'=>""))
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label class="col-lg-12">&nbsp; </label>
                                                <button type="button" id="btn-search"
                                                        class="btn btn-success btn-addon btn-sm m-b-10 m-l-5">
                                                    <i class="ti-search"></i>Tìm kiếm
                                                </button>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                            <div class="table_out" id="responsive">
                                <table id="table_data" class="table table-striped table-hover"
                                       style="border: 1px solid #ccc;">
                                    <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Mã số đơn vị</th>
                                        <th>Tên đơn vị</th>
                                        <th>Mã số thuế</th>
                                        <th>Số điện thoại</th>
                                        <th style="text-align: center;">Chức năng</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($list_data as $key => $value)
                                        <tr data-object_value="{{$value->toJson()}}">
                                            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
                                            <td class="maso_dn">{{$value->maso_dn}}</td>
                                            <td class="ten_dn">{{$value->ten_dn}}</td>
                                            <td class="maso_thue">{{$value->maso_thue}}</td>
                                            <td class="tel">{{$value->tel}}</td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-success btn-addon btn-xs m-b-10"
                                                            type="button" data-toggle="dropdown">
                                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                        Chức năng
                                                        <span class="caret"></span>
                                                    </button>
                                                    <ul class="dropdown-menu ul-group-button">
                                                        <li>
                                                            <a data-toggle="modal" class="btn-view btn"
                                                               data-target="#modal_view">Xem</a>
                                                        </li>
                                                        <li><a class="btn-edit btn">Sửa</a></li>
                                                        <li><a class="btn-delete btn" data-primary_key="{{$value->id}}">Xóa</a>
                                                        </li>
                                                    </ul>
                                                    <button type="button"
                                                            class="btn btn-info btn-addon btn-xs m-b-10 btn_duyet_hoso_dn"
                                                            data-primary_key="{{$value->id}}"
                                                            data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                                                                class="fa fa-check" aria-hidden="true"></i>Duyệt hồ sơ
                                                    </button>


                                                </div>

                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                                <center>
                                    {{ $list_data->links() }}
                                </center>
                            </div>
                        </div>
                    </div>
                </div><!-- /# column -->
            </div>
        </div><!-- /# card -->
    </div><!-- /# column -->


    {{--Modal view information--}}
    <div id="modal_view" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Xem thông tin chi tiết doanh nghiệp tham gia bảo hiểm mới</h4>
                </div>
                <div class="modal-body">
                    <table id="modal-table" class="table table-responsive tb-modal-bhxh table-hover"
                           style="font-size: 13px;">
                        <tbody>
                        <tr>
                            <td><strong>Mã số đơn vị</strong></td>
                            <td field_name="maso_dn"></td>
                            <td><strong>Tên đơn vị</strong></td>
                            <td field_name="ten_dn"></td>
                        </tr>

                        <tr>
                            <td><strong>Mã số thuế</strong></td>
                            <td field_name="maso_thue"></td>
                            <td><strong>Địa chỉ đăng ký kinh doanh</strong></td>
                            <td field_name="diachi_dangkykinhdoanh"></td>

                        </tr>

                        <tr>
                            <td><strong>Địa chỉ giao dịch và liên hệ</strong></td>
                            <td field_name="diachi_giaodich"></td>
                            <td><strong>Loại hình đơn vị</strong></td>
                            <td field_name="loai_hinh"></td>
                        </tr>

                        <tr>
                            <td><strong>Số điện thoại</strong></td>
                            <td field_name="tel"></td>
                            <td><strong>Địa chỉ email</strong></td>
                            <td field_name="email"></td>
                        </tr>

                        <tr>
                            <td><strong>Giấy phép đăng ký kinh doanh</strong></td>
                            <td field_name="giayphep_dangkykinhdoanh"></td>
                            <td><strong>Nơi cấp</strong></td>
                            <td field_name="noicap_dangkykinhdoanh"></td>
                        </tr>

                        <tr>
                            <td><strong>Phương thức đóng khác</strong></td>
                            <td field_name="phuongthuc_dong"></td>
                            <td><strong>Nội dung thay đổi, yêu cầu</strong></td>
                            <td field_name="noidung_thaydoi"></td>
                        </tr>

                        <tr>
                            <td><strong>Hồ sơ đính kèm</strong></td>
                            <td colspan="3">
                                <button type="button" class="btn btn-info">Tải về</button>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                </div>
            </div>

        </div>
    </div>

    {{--Modal: Cấp BHXH--}}
    <div id="modal_duyet_bhxh" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Duyệt hồ sơ</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="primary_key">
                    <table id="modal-table" class="table table-responsive tb-modal-bhxh">
                        <tbody>
                        <tr>
                            <td><strong>Ngày duyệt</strong></td>
                            <td>
                                @include('custom_controls.datepicker', array('id'=>'ngay_duyet', 'value'=>""))
                            </td>
                            <td><strong>Tên người duyệt</strong></td>
                            <td>
                                @include('custom_controls.textbox', array('id'=>'nguoi_duyet', 'value'=>""))
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Ghi chú/Lý do</strong></td>
                            <td colspan="3">
                                @include('custom_controls.textarea', array('id'=>'ghichu', 'value'=>""))
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer" style="text-align: center;">
                    <button type="button" id="btn-approve" class="btn btn-info btn-addon btn-sm">
                        <i class="fa fa-check" aria-hidden="true"></i>Duyệt
                    </button>
                    <button type="button" id="btn-not-approve" class="btn btn-danger btn-addon btn-sm">
                        <i class="fa fa-times" aria-hidden="true"></i>Không duyệt
                    </button>
                    <button type="button" class="btn btn-default btn-sm m-b-10 pull-right" data-dismiss="modal">Đóng
                    </button>
                </div>
            </div>

        </div>
    </div>
@stop

@section('javascript')
    <script>
        $(document).ready(function () {
            /**
             * Process display function button on screen
             */
            $(document).on('click', '.btn-edit', function (e) {
                var _tr = $(this).parents('tr');
                var _obj_value = _tr.data('object_value');

                location.href = "/quanly_baohiem/hoso_baohiem_dn/" + _obj_value["id"];
            });

            /**
             *  Open modal view information
             */
            $(document).on('click', '.btn-view', function (e) {
                var _tr = $(this).parents('tr');
                var _obj_value = _tr.data('object_value');

                $('#modal-table tbody td[field_name]').each(function () {
                    var attr = $(this).attr('field_name');

                    if (typeof attr !== typeof undefined && attr !== false) {
                        $(this).text(_obj_value[attr]);
                    }
                });
            });

            /**
             *  Event search
             */
            $(document).on('click', '#btn-search', function (e) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: $('#search-form').attr('action'),
                    type: 'GET',
                    loading: true,
                    dataType: "html",
                    data: $("#search-form").serialize(),
                    success: function (res) {
                        if (res.status == "201" || res.status == "202") {
                            alert(res.message);
                        } else {
                            $('#responsive').empty();
                            $('#responsive').append(res);
                        }
                    }
                });
            });

            /**
             *  Delete single record
             */
            $(document).on('click', 'a.btn-delete', function (e) {
                var _r = confirm("Xóa dữ liệu đã chọn?");
                if (_r) {
                    var _id = $(this).data('primary_key');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: '/quanly_baohiem/hoso_baohiem_dn/delete/' + _id,
                        type: 'POST',
                        loading: true,
                        data: null,
                        success: function (res) {
                            if (res.status == 201) {
                                console.log(res.message);
                                let _errs = "";
                                let _index = 1;
                                $.each(res.message, function (key, value) {
                                    _errs = _errs + _index + ". " + value[0].toString() + "\n";
                                    _index++;
                                });
                                alert(_errs);
                            } else if (res.status == 200) {
                                alert(res.message);
                                location.reload(true);
                            } else {
                                alert(res.message);
                            }
                        }
                    });
                }
            });

            /**
             * Open modal duyet BHXH cá nhân
             */
            $(document).on('click', '.btn_duyet_hoso_dn', function (e) {
                $('#primary_key').val($(this).data('primary_key'));
            });

            /**
             * Duyệt BHXH doanh nghiệp
             */
            $(document).on('click', '#btn-approve', function (e) {
                var _r = confirm("Duyệt hồ sơ bảo hiểm cho doanh nghiệp đang chọn?");
                if (_r) {
                    var _primary_key = $('#primary_key').val();
                    var _url = "/quanly_baohiem/hoso_baohiem_dn/duyet_hoso/" + _primary_key;

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: _url,
                        type: 'POST',
                        loading: true,
                        data: {
                            ngay_duyet: $('#ngay_duyet').val(),
                            nguoi_duyet: $('#nguoi_duyet').val(),
                            ghichu: $('#ghichu').val(),
                            trang_thai: 3
                        },
                        success: function (res) {
                            if (res.status == 201) {
                                console.log(res.message);
                                let _errs = "";
                                let _index = 1;
                                $.each(res.message, function (key, value) {
                                    _errs = _errs + _index + ". " + value[0].toString() + "\n";
                                    _index++;
                                });
                                alert(_errs);
                            } else if (res.status == 200) {
                                alert(res.message);
                                location.reload(true);
                            } else {
                                alert(res.message);
                            }
                        }
                    });
                }
            });

            /**
             * Không duyệt BHXH doanh nghiệp
             */
            $(document).on('click', '#btn-not-approve', function (e) {
                var _r = confirm("Không duyệt hồ sơ bảo hiểm cho doanh nghiệp đang chọn?");
                if (_r) {
                    var _primary_key = $('#primary_key').val();
                    var _url = "/quanly_baohiem/hoso_baohiem_dn/duyet_hoso/" + _primary_key;

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: _url,
                        type: 'POST',
                        loading: true,
                        data: {
                            ngay_duyet: $('#ngay_duyet').val(),
                            nguoi_duyet: $('#nguoi_duyet').val(),
                            ghichu: $('#ghichu').val(),
                            trang_thai: 2
                        },
                        success: function (res) {
                            if (res.status == 201) {
                                console.log(res.message);
                                let _errs = "";
                                let _index = 1;
                                $.each(res.message, function (key, value) {
                                    _errs = _errs + _index + ". " + value[0].toString() + "\n";
                                    _index++;
                                });
                                alert(_errs);
                            } else if (res.status == 200) {
                                alert(res.message);
                                location.reload(true);
                            } else {
                                alert(res.message);
                            }
                        }
                    });
                }
            });
        });
    </script>
    {{--    {!! public_url('js/quanly_baohiem/list.js')!!}--}}
@stop