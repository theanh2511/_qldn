<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số đơn vị</th>
        <th>Tên đơn vị</th>
        <th>Mã số thuế</th>
        <th>Số điện thoại</th>
        <th style="text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as $key => $value)
        <tr data-object_value="{{$value->toJson()}}">
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="maso_dn">{{$value->maso_dn}}</td>
            <td class="ten_dn">{{$value->ten_dn}}</td>
            <td class="maso_thue">{{$value->maso_thue}}</td>
            <td class="tel">{{$value->tel}}</td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-success btn-addon btn-xs m-b-10"
                            type="button" data-toggle="dropdown">
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                        Chức năng
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu ul-group-button">
                        <li>
                            <a data-toggle="modal" class="btn-view btn"
                               data-target="#modal_view">Xem</a>
                        </li>
                        <li><a class="btn-edit btn">Sửa</a></li>
                        <li><a class="btn-delete btn" data-primary_key="{{$value->id}}">Xóa</a>
                        </li>
                    </ul>
                    <button type="button" class="btn btn-info btn-addon btn-xs m-b-10 btn_duyet_hoso_dn"
                            data-primary_key="{{$value->id}}"
                            data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                                class="fa fa-check" aria-hidden="true"></i>Duyệt hồ sơ
                    </button>


                </div>

            </td>
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>