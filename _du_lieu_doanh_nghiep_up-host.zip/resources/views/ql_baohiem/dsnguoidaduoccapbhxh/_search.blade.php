<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Họ và tên</th>
        <th>Số CMND/Hộ chiếu</th>
        <th>Mã số BHXH</th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    @foreach($list_data as $key => $value)
        <tr data-object_value="{{$value->toJson()}}">
            <td class="stt_ht">{{($perPage*($currentPage-1))+$key+1}}</td>
            <td class="ten_ca_nhan">{{$value->ten_ca_nhan}}</td>
            <td class="so_cmt">{{$value->so_cmt}}</td>
            <td class="maso_bhxh">{{$value->maso_bhxh}}</td>
            @include('layouts.baohiem_grid_buttons')
        </tr>
    @endforeach
    </tbody>
</table>
<center>
    {{ $list_data->links() }}
</center>