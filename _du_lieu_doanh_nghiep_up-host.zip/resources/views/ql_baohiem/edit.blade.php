@extends('layouts.main')

@section('css')

@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Tạo mới </h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Bảo hiểm</a></li>
                            <li class="active">Tạo mới</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="editor-form"
                                      action="{{ url('/quanly_baohiem/hoso_baohiem_dn/update/'.($item_hsbh->id??"")) }}"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      class="form-horizontal">@csrf
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số đơn vị</label>
                                                @include('custom_controls.textbox', array('id'=>'maso_dn', 'value'=>$item_hsbh->maso_dn))
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Tên đơn vị</label>
                                                @include('custom_controls.textbox', array('id'=>'ten_dn', 'value'=>$item_hsbh->ten_dn))
                                            </div>
                                        </div>


                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số thuế</label>
                                                @include('custom_controls.textbox', array('id'=>'maso_thue', 'value'=>$item_hsbh->maso_thue))
                                            </div>
                                        </div>

                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Địa chỉ đăng ký kinh doanh</label>
                                                @include('custom_controls.textbox', array('id'=>'diachi_dangkykinhdoanh', 'value'=>$item_hsbh->diachi_dangkykinhdoanh))
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Địa chỉ giao dịch và liên hệ</label>
                                                @include('custom_controls.textbox', array('id'=>'diachi_giaodich', 'value'=>$item_hsbh->diachi_giaodich))
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Loại hình đơn vị</label>
                                                @include('custom_controls.selectbox',
                                                    array('id'=>'loai_hinh',
                                                        'select_data'=>$list_loai_hinh_dn,
                                                        'value_member'=>'ma_lh',
                                                        'display_member'=>'ten_lh',
                                                        'selected_value'=>$item_hsbh->loai_hinh
                                                    ))
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Số điện thoại</label>
                                                @include('custom_controls.textbox', array('id'=>'tel', 'value'=>$item_hsbh->tel))
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Email</label>
                                                @include('custom_controls.textbox', array('id'=>'email', 'value'=>$item_hsbh->email))
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Quyết định thành lập/ Giấy phép đăng ký kinh doanh</label>
                                                @include('custom_controls.textbox', array('id'=>'giayphep_dangkykinhdoanh', 'value'=>$item_hsbh->giayphep_dangkykinhdoanh))
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Nơi cấp</label>
                                                @include('custom_controls.textbox', array('id'=>'noicap_dangkykinhdoanh', 'value'=>$item_hsbh->noicap_dangkykinhdoanh))
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Phương thức đóng khác</label>
                                                @include('custom_controls.textbox', array('id'=>'phuongthuc_dong', 'value'=>$item_hsbh->phuongthuc_dong))
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label>Nội dung thay đổi, yêu cầu</label>
                                                <textarea class="form-control input-sm input-default"
                                                          id="noidung_thaydoi"
                                                          name="noidung_thaydoi"
                                                          rows="3">{{$item_hsbh->noidung_thaydoi}}</textarea>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label>Hồ sơ kèm theo (Nếu có)</label>
                                                <input type="file" class="form-control  input-sm input-default ">
                                            </div>
                                        </div>


                                        <div class="col-lg-12" style="text-align: center;">
                                            @if($item_hsbh->id)
                                                <button type="submit" class="btn btn-info  btn-addon m-b-10 m-l-5">
                                                    <i class="ti-save"></i>Lưu
                                                </button>
                                            @else
                                                <button type="submit" class="btn btn-info  btn-addon m-b-10 m-l-5">
                                                    <i class="ti-plus"></i>Thêm mới
                                                </button>
                                            @endif
                                            <button type="button" id="btn-back" class="btn btn-danger btn-addon m-b-10 m-l-5"><i
                                                        class="ti-close"></i>Hủy bỏ
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div><!-- /# card -->
            </div><!-- /# column -->
        </div><!-- /# row -->
    </div><!-- /# main content -->
    </div><!-- /# container-fluid -->
@stop

@section('javascript')
    {!! public_url('js/quanly_baohiem/edit.js')!!}
@stop



