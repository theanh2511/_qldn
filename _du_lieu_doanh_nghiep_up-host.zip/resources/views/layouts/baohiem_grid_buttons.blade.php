{{--<td width="15%" style="max-width: 100px;">--}}
{{--<div class="input-group">--}}
{{--<div id="radioBtn" class="btn-group">--}}
{{--<a class="btn btn-info btn-sm {{$value->deleted_at?"notActive":"active"}}"--}}
{{--data-toggle="is_active" data-primary_key="{{$value->id}}"--}}
{{--data-title="Y">Hiện</a>--}}
{{--<a class="btn btn-info btn-sm {{$value->deleted_at?"active":"notActive"}}"--}}
{{--data-toggle="is_active" data-primary_key="{{$value->id}}"--}}
{{--data-title="N">Ẩn</a>--}}
{{--</div>--}}
{{--<input type="hidden" class="is_active" id="is_active">--}}
{{--</div>--}}
{{--</td>--}}
{{--<td class="text-center" width="15%">--}}
{{--<button type="button" data-primary_key="{{$value->id}}"--}}
{{--class="btn btn-success btn-edit btn-addon btn-xs">--}}
{{--<i class="fa fa-pencil-square-o"--}}
{{--aria-hidden="true"></i>Sửa--}}
{{--</button>--}}
{{--<button type="button" data-primary_key="{{$value->id}}"--}}
{{--class="btn btn-danger btn-delete btn-addon btn-xs">--}}
{{--<i class="fa fa-times" aria-hidden="true"></i>Xóa--}}
{{--</button>--}}
{{--</td>--}}

<td class="text-center" width="20%">
    <button type="button"
            class="btn btn-warning btn-addon btn-xs m-b-10 btn-view btn-view"
            data-toggle="modal" data-target="#modal_view">
        <i class="fa fa-eye" aria-hidden="true"></i>Xem
    </button>

    <button type="button" data-primary_key="{{$value->id}}"
            class="btn btn-success btn-addon btn-xs m-b-10 btn-edit">
        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>Sửa
    </button>

    <button type="button" data-primary_key="{{$value->id}}"
            class="btn btn-danger btn-addon btn-xs m-b-10 btn-delete">
        <i class="fa fa-times" aria-hidden="true"></i>Xóa
    </button>

</td>