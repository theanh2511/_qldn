{!! public_url('js/lib/jquery.min.js')!!}
{!! public_url('js/lib/jquery.nanoscroller.min.js')!!}
{!! public_url('js/lib/sidebar.js')!!}
{!! public_url('js/lib/bootstrap.min.js')!!}
{!! public_url('js/lib/mmc-common.js')!!}
{{--    {!! public_url('js/lib/mmc-chat.js')!!}--}}
{{--{!! public_url('js/lib/chart-js/Chart.bundle.js')!!}--}}
{{--{!! public_url('js/lib/chart-js/chartjs-init.js')!!}--}}
{{--{!! public_url('js/lib/sparklinechart/jquery.sparkline.min.js')!!}--}}
{{--{!! public_url('js/lib/sparklinechart/sparkline.init.js')!!}--}}
{!! public_url('js/lib/datamap/d3.min.js')!!}
{!! public_url('js/lib/datamap/topojson.js')!!}
{{--    {!! public_url('js/lib/datamap/datamaps.world.min.js')!!}--}}
{{--{!! public_url('js/lib/datamap/datamap-init.js')!!}--}}

{{--{!! public_url('js/lib/weather/jquery.simpleWeather.min.js')!!}--}}
{{--{!! public_url('js/lib/weather/weather-init.js')!!}--}}

{!! public_url('js/lib/owl-carousel/owl.carousel.min.js')!!}
{!! public_url('js/lib/owl-carousel/owl.carousel-init.js')!!}
{{--{!! public_url('js/scripts.js')!!}--}}
<script>

</script>
@yield('javascript')
</body>

</html>
