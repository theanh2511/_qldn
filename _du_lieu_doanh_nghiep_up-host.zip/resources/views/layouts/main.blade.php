@include('layouts.header')

<div class="content-wrap">
    <div class="main">
            @yield('content')

        </div><!-- /# row -->
    </div><!-- /# main content -->
</div><!-- /# container-fluid -->
</div><!-- /# main -->
</div><!-- /# content wrap -->




@include('layouts.footer')