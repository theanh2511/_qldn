<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/variable-pie.js"></script>
<script>
	Highcharts.chart('container_dathamgiabhxh', {
    chart: {
        type: 'variablepie'
    },
    title: {
        text: 'Báo cáo doanh nghiệp đã tham gia bảo hiểm'
    },
    tooltip: {
        headerFormat: '',
        pointFormat: '<span style="color:{point.color}">\u25CF</span> <b> {point.name}</b><br/>' +
            'Area (square km): <b>{point.y}</b><br/>' +
            'Population density (people per square km): <b>{point.z}</b><br/>'
    },
    series: [{
        minPointSize: 10,
        innerSize: '20%',
        zMin: 0,
        name: 'Thành phố/Thị xã/Huyện',
        data: [{
            name: 'Thành phố Bắc Ninh ',
            y: 505370,
            z: 92.9
        }, {
            name: 'Huyện Gia Bình',
            y: 551500,
            z: 118.7
        }, {
            name: 'Huyện Lương Tài',
            y: 312685,
            z: 124.6
        }, {
            name: 'Huyện Quế Võ',
            y: 78867,
            z: 137.5
        }, {
            name: 'Huyện Thuận Thành',
            y: 301340,
            z: 201.8
        }, {
            name: 'Huyện Tiên Du',
            y: 41277,
            z: 214.5
        }, {
            name: 'Thị xã Từ Sơn',
            y: 357022,
            z: 235.6
        },
        {
            name: 'Huyện Yên Phong',
            y: 78867,
            z: 235.6
        }]
    }]
});

</script>