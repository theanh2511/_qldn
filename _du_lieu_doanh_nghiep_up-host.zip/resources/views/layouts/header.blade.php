<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{$title ?? "Form name"}}</title>
    {{--{!! public_url('css/bootstrap.min.css')!!}--}}
    {{--{!! public_url('css/font-awesome.css')!!}--}}
    {{--{!! public_url('css/owl.carousel2.css')!!}--}}
    {{--{!! public_url('css/owl.theme2.css')!!}--}}
    {{--{!! public_url('css/menu-2.css')!!}--}}
    {{--{!! public_url('css/style00.css')!!}--}}
    {{--{!! public_url('css/setmedia.css')!!}--}}
    {{--{!! public_url('css/bootstrap-datetimepicker.css')!!}--}}



    {{--{!! public_url('js/jquery-1.11.1.min.js')!!}--}}
    {{--{!! public_url('js/bootstrap.min.js')!!}--}}
    {{--{!! public_url('js/menu-2.js')!!}--}}
    {{--{!! public_url('js/style-img.js')!!}--}}
    {{--{!! public_url('js/wow.min.js')!!}--}}
    {{--{!! public_url('js/main.js')!!}--}}
    {{--{!! public_url('js/moment.js')!!}--}}
    {{--{!! public_url('js/bootstrap-datetimepicker.min.js')!!}--}}


   
	{{--<!-- Styles -->--}}
    {!! public_url('css/lib/bootstrap.min.css')!!}
    {!! public_url('css/lib/font-awesome.min.css')!!}
    {!! public_url('css/lib/themify-icons.css')!!}
    {!! public_url('css/lib/owl.carousel.min.css')!!}
    {!! public_url('css/lib/owl.theme.default.min.css')!!}
    {!! public_url('css/lib/weather-icons.css')!!}
    {!! public_url('css/lib/mmc-chat.css')!!}
    {!! public_url('css/lib/sidebar.css')!!}
    {!! public_url('css/lib/bootstrap.min.css')!!}
    {!! public_url('css/lib/simdahs.css')!!}
    {!! public_url('css/style.css')!!}
    {!! public_url('css/custom_style.css')!!}
    @yield('css')
</head>

<body>

    <div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                @include('layouts.left')
            </div>
        </div>
    </div><!-- /# sidebar -->




    <div class="header" style="background: url(/images/header.jpg);">
        <div class="pull-left">
            <div class="logo" id="sideLogo" style="background:transparent;">
                <a href="/index">
                    <img class="full-logo" src="/images/quochuy.png" alt="SimDahs">
                    <img class="small-logo" src="/images/quochuy.png" alt="SimDahs">
                </a>
            </div>
            <div class="hamburger sidebar-toggle">
                <span class="ti-menu"></span>
            </div>
        </div>
        <div style=" font-weight: bold; font-size:20px; margin-top:10px;margin-left: 50px;  color: #fff; float: left;">Phần mềm quản lý dữ liệu doanh nghiệp tỉnh Bắc Ninh</div>
        <div class="pull-right p-r-15">
            <ul>
                <li class="header-icon dib"><i class="ti-bell"></i>
                    <div class="drop-down">
                        <div class="dropdown-content-heading">
                            <span class="text-left">Thông báo</span>
                        </div>
                        <div class="dropdown-content-body">
                            <ul>
                                <li>
                                    <a href="#">
                                        <img class="pull-left m-r-10 avatar-img" src="/images/avatar/3.jpg" alt="" />
                                        <div class="notification-content">
                                            <small class="notification-timestamp pull-right">02:34 PM</small>
                                            <div class="notification-heading">Mr Hiền</div>
                                            <div class="notification-text">Văn bản pháp quy... </div>
                                        </div>
                                    </a>
                                </li>

                               
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="header-icon dib"><i class="ti-email"></i>
                    <div class="drop-down">
                        <div class="dropdown-content-heading">
                            <span class="text-left">2 tin nhắn</span>
                            <a href="email.html"><i class="ti-pencil-alt pull-right"></i></a>
                        </div>
                        <div class="dropdown-content-body">
                            <ul>
                                <li class="notification-unread">
                                    <a href="#">
                                        <img class="pull-left m-r-10 avatar-img" src="/images/avatar/1.jpg" alt="" />
                                        <div class="notification-content">
                                            <small class="notification-timestamp pull-right">02:34 PM</small>
                                            <div class="notification-heading">Trần Văn Trung</div>
                                            <div class="notification-text">Chuyển dữ liệu từ  ...</div>
                                        </div>
                                    </a>
                                </li>

                               

                               
                                <li class="text-center">
                                    <a href="#" class="more-link">Xem tất cả</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
				
                <li class="header-icon dib"><img class="avatar-img" src="/images/avatar/1.jpg" alt="" />
                    <span class="user-avatar">Admin <i class="ti-angle-down f-s-10"></i></span>
                    <div class="drop-down dropdown-profile">
                        
                        <div class="dropdown-content-body">
                            <ul>
                                <li><a href="#"><i class="ti-user"></i> <span>Thêm tài khoản</span></a></li>
                                <li><a href="#"><i class="ti-wallet"></i> <span>Danh sách tài khoản</span></a></li>
                                <li><a href="#"><i class="ti-write"></i> <span>Phân quyền tài khoản</span></a></li>
                                <li><a href="#"><i class="ti-calendar"></i> <span>Thông tin tài khoản</span></a></li>
                                <li><a href="#"><i class="ti-email"></i> <span>Đổi mật khẩu</span></a></li>
                                
                                <li><a href="#"><i class="ti-help-alt"></i> <span>Quản lý log truy cập</span></a></li>
                                <li><a href="#"><i class="ti-lock"></i> <span>Thống kê truy cập </span></a></li>
                               
                                <li><a href="#"><i class="ti-settings"></i> <span>Thoát</span></a></li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
