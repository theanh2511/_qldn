<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{$title ?? "Form name"}}</title>
    {!! public_url('css/bootstrap.min.css')!!}
    {!! public_url('css/font-awesome.css')!!}
    {!! public_url('css/owl.carousel2.css')!!}
    {!! public_url('css/owl.theme2.css')!!}
    {!! public_url('css/menu-2.css')!!}
    {!! public_url('css/style00.css')!!}
    {!! public_url('css/setmedia.css')!!}
    {!! public_url('css/bootstrap-datetimepicker.css')!!}
    {!! public_url('css/custom_style.css')!!}


    {!! public_url('js/jquery-1.11.1.min.js')!!}
    {!! public_url('js/bootstrap.min.js')!!}
    {!! public_url('js/menu-2.js')!!}
    {!! public_url('js/style-img.js')!!}
    {!! public_url('js/wow.min.js')!!}
    {!! public_url('js/main.js')!!}
    {!! public_url('js/moment.js')!!}
    {!! public_url('js/bootstrap-datetimepicker.min.js')!!}

    @yield('css')
    {{--<link href="../css/bootstrap.min.css" rel="stylesheet"/>--}}
    {{--<link href="../css/font-awesome.css" rel="stylesheet"/>--}}
    {{--<link href="../css/owl.carousel2.css" rel="stylesheet"/>--}}
    {{--<link href="../css/owl.theme2.css" rel="stylesheet"/>--}}
    {{--<link href="../css/menu-2.css" rel="stylesheet"/>--}}
    {{--<link href="../css/style00.css" rel="stylesheet"/>--}}
    {{--<link href="../css/setmedia.css" rel="stylesheet"/>--}}
    {{--<link href="../css/bootstrap-datetimepicker.css" rel="stylesheet"/>--}}
    {{--<script type="text/javascript" src="../js/jquery-1.11.1.min.js"></script>--}}
    {{--<script type="text/javascript" src="../js/bootstrap.min.js"></script>--}}
    {{--<script type="text/javascript" src="../js/menu-2.js"></script>--}}
    {{--<script type="text/javascript" src="../js/style-img.js"></script>--}}
    {{--<script type="text/javascript" src="../js/wow.min.js"></script>--}}
    {{--<script type="text/javascript" src="../js/main.js"></script>--}}
    {{--<script type='text/javascript' src='../js/moment.js'></script>--}}
    {{--<script type='text/javascript' src='../js/bootstrap-datetimepicker.min.js'></script>--}}
    {{--<script type='text/javascript' src='js/tao_moi.js'></script>--}}
    <script>
        new WOW().init();
    </script>
</head>
<body>
<header id="header">
    <div class="menu_mb butt_mobile visible-xs visible-sm clearfix">
        <button class="nav-toggle">
            <div class="icon-menu"><span class="line line-1"></span> <span class="line line-2"></span> <span
                        class="line line-3"></span></div>
        </button>
        <div class="text-center">
            <h2>Phần mềm quản lý dữ liệu doanh nghiệp tỉnh Bắc Ninh</h2>
        </div>
    </div>
    <!-- /menu_mb -->
    <div class="clearfix clearfix-60 visible-sm visible-xs"></div>
    <div class="qts_header">
        <div class="container-fluid">
            <div class="row hidden-xs hidden-sm">
                <div class="logo_pp"><a href="#" title=""> <span class="txt_logo">
            <h2 class="text-center">Phần mềm quản lý dữ liệu doanh nghiệp tỉnh Bắc Ninh</h2>
          </span> </a></div>
            </div>
            <div class="nav_login row_pc">
                <div class="menu_main">
                    <nav class="nav is-fixed" role="navigation">
                        <div class="wrapper wrapper-flush">
                            <div class="nav-container">
                                @include('layouts.menu')

                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</header>
<!-- end header-->

<div class="clearfix"></div>
<article id="body_home">
    @yield('content')

    <div class="clearfix-10"></div>
</article>
<div class="clearfix"></div>
<footer id="footer"><a href="#top" id="go_top"><i class="fa fa-angle-up"></i></a></footer>

<script>
    new WOW().init();
    $('.date_time').datetimepicker({
        format: 'DD/MM/YYYY'
    });
</script>
@yield('javascript')
</body>
</html>
