<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>




<script type="text/javascript">


Highcharts.chart('container4', {
  chart: {
    zoomType: 'xy'
  },
  title: {
    text: 'Báo cáo tổng số tiền thuế của doanh nghiệp',
    align: 'left'
  },
  subtitle: {
    // text: 'Source: WorldClimate.com',
    // align: 'left'
  },
  xAxis: [{
    categories: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6',
      'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'],
    crosshair: true
  }],
  yAxis: [{ // Primary yAxis
    labels: {
      format: '{value}°C',
      style: {
        color: Highcharts.getOptions().colors[2]
      }
    },
    title: {
      text: 'Temperature',
      style: {
        color: Highcharts.getOptions().colors[2]
      }
    },
    opposite: true

  }, { // Secondary yAxis
    gridLineWidth: 0,
    title: {
      text: 'Nghìn tỷ đồng',
      style: {
        color: Highcharts.getOptions().colors[0]
      }
    },
    labels: {
      format: '{value}',
      style: {
        color: Highcharts.getOptions().colors[0]
      }
    }

  }, { // Tertiary yAxis
    gridLineWidth: 0,
    title: {
      text: 'Sea-Level Pressure',
      style: {
        color: Highcharts.getOptions().colors[1]
      }
    },
    labels: {
      format: '{value} mb',
      style: {
        color: Highcharts.getOptions().colors[1]
      }
    },
    opposite: true
  }],
  tooltip: {
    shared: true
  },
  legend: {
    layout: 'vertical',
    align: 'left',
    x: 80,
    verticalAlign: 'top',
    y: 55,
    floating: true,
    backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || 'rgba(255,255,255,0.25)'
  },
  series: [{
    name: 'Thuế',
    type: 'column',
    yAxis: 1,
    data: [423, 574, 625, 638, 522, 385, 475, 536, 612, 658, 673, 691],
    tooltip: {
      valueSuffix: ' nghìn tỷ đồng'
    }

  }, {
    name: 'Sea-Level Pressure',
    type: 'spline',
    yAxis: 2,
    data: [1016, 1016, 1015.9, 1015.5, 1012.3, 1009.5, 1009.6, 1010.2, 1013.1, 1016.9, 1018.2, 1016.7],
    marker: {
      enabled: false
    },
    dashStyle: 'shortdot',
    tooltip: {
      valueSuffix: ' mb'
    }

  }, {
    name: 'Temperature',
    type: 'spline',
    data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6],
    tooltip: {
      valueSuffix: ' °C'
    }
  }],
  responsive: {
    rules: [{
      condition: {
        maxWidth: 500
      },
      chartOptions: {
        legend: {
          floating: false,
          layout: 'horizontal',
          align: 'center',
          verticalAlign: 'bottom',
          x: 0,
          y: 0
        }
      }
    }]
  }
});

</script>