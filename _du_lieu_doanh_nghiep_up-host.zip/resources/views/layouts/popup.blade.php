<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{$title ?? "Form name"}}</title>
    {!! public_url('css/bootstrap.min.css')!!}
    {!! public_url('css/font-awesome.css')!!}
    {!! public_url('css/owl.carousel2.css')!!}
    {!! public_url('css/owl.theme2.css')!!}
    {!! public_url('css/menu-2.css')!!}
    {!! public_url('css/style00.css')!!}
    {!! public_url('css/setmedia.css')!!}
    {!! public_url('css/bootstrap-datetimepicker.css')!!}
    {!! public_url('css/custom_style.css')!!}


    {!! public_url('js/jquery-1.11.1.min.js')!!}
    {!! public_url('js/bootstrap.min.js')!!}
    {!! public_url('js/menu-2.js')!!}
    {!! public_url('js/style-img.js')!!}
    {!! public_url('js/wow.min.js')!!}
    {!! public_url('js/main.js')!!}
    {!! public_url('js/moment.js')!!}
    {!! public_url('js/bootstrap-datetimepicker.min.js')!!}

    @yield('css')
    {{--<link href="../css/bootstrap.min.css" rel="stylesheet"/>--}}
    {{--<link href="../css/font-awesome.css" rel="stylesheet"/>--}}
    {{--<link href="../css/owl.carousel2.css" rel="stylesheet"/>--}}
    {{--<link href="../css/owl.theme2.css" rel="stylesheet"/>--}}
    {{--<link href="../css/menu-2.css" rel="stylesheet"/>--}}
    {{--<link href="../css/style00.css" rel="stylesheet"/>--}}
    {{--<link href="../css/setmedia.css" rel="stylesheet"/>--}}
    {{--<link href="../css/bootstrap-datetimepicker.css" rel="stylesheet"/>--}}
    {{--<script type="text/javascript" src="../js/jquery-1.11.1.min.js"></script>--}}
    {{--<script type="text/javascript" src="../js/bootstrap.min.js"></script>--}}
    {{--<script type="text/javascript" src="../js/menu-2.js"></script>--}}
    {{--<script type="text/javascript" src="../js/style-img.js"></script>--}}
    {{--<script type="text/javascript" src="../js/wow.min.js"></script>--}}
    {{--<script type="text/javascript" src="../js/main.js"></script>--}}
    {{--<script type='text/javascript' src='../js/moment.js'></script>--}}
    {{--<script type='text/javascript' src='../js/bootstrap-datetimepicker.min.js'></script>--}}
    {{--<script type='text/javascript' src='js/tao_moi.js'></script>--}}
    <script>
        new WOW().init();
    </script>
</head>
<body>

<div class="clearfix"></div>
<article id="body_home">
    @yield('content')

    <div class="clearfix-10"></div>
</article>

<script>
    new WOW().init();
    $('.date_time').datetimepicker({
        format: 'DD/MM/YYYY'
    });
</script>
@yield('javascript')
</body>
</html>
