<ul class="nav-menu menu clearfix">
    <li class="menu-item ">
        <a href="/trungtamdieuhanh" class="menu-link">
            <i class="fa fa-home" aria-hidden="true"></i>
        </a>
    </li>
    <li class="menu-item has-dropdown"><a href="#" class="menu-link text_upper">Quản trị
            hệ thống</a>
        <ul class="width_230 nav-dropdown menu">
            <li class="menu-item"><a href="/Quantri_hethong/donvi_sudung"
                                     class="menu-link">Quản trị đơn vị sử dụng</a></li>
            <li class="menu-item"><a href="/Quantri_hethong/Phong_ban"
                                     class="menu-link">Quản lý phòng ban </a></li>
            <li class="menu-item"><a href="/Quantri_hethong/nhom_taikhoan"
                                     class="menu-link">Nhóm tài khoản </a></li>
            <li class="menu-item"><a href="/Quantri_hethong/quanly_taikhoan"
                                     class="menu-link">Quản lý tài khoản </a></li>
            <li class="menu-item"><a href="/Quantri_hethong/quanly_logtruycap"
                                     class="menu-link">Quản lý log truy cập </a></li>
            <li class="menu-item"><a href="/Quantri_hethong/quanly_lichsu"
                                     class="menu-link">Quản lý lịch sử sử dụng phần
                    mềm </a></li>
        </ul>
    </li>

    <li class="menu-item has-dropdown"><a href="#" class="menu-link text_upper">Quản trị doanh nghiệp</a>
        <ul class="width_230 nav-dropdown menu">
            <li class="menu-item">
                <a href="/danhmuc/diagioi_caphuyen" class="menu-link">Quản lý địa giới cấp huyện</a>
            </li>
            <li class="menu-item">
                <a href="/danhmuc/diagioi_capxa" class="menu-link">Quản lý địa giới cấp xã</a>
            </li>
            <li class="menu-item">
                <a href="/danhmuc/loaihinh_doanhnghiep" class="menu-link">Quản lý loại hình doanh nghiệp</a>
            </li>
            <li class="menu-item">
                <a href="/danhmuc/trangthai_doanhnghiep" class="menu-link">Quản lý trạng thái doanh nghiệp</a>
            </li>
            <li class="menu-item">
                <a href="/danhmuc/quoctich" class="menu-link">Quản lý danh mục quốc tịch</a></li>
            <li class="menu-item">
                <a href="/danhmuc/dantoc" class="menu-link">Quản lý danh mục dân tộc</a></li>
            <li class="menu-item">
                <a href="/danhmuc/nganhnghe_kinhdoanh" class="menu-link">Quản lý ngành nghề kinh doanh</a></li>
            <li class="menu-item">
                <a href="/quanly_doanhnghiep/hoso_doanhnghiep" class="menu-link">Tạo mới hồ sơ doanh nghiệp</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_doanhnghiep/danhsach_moitao" class="menu-link">Danh sách doanh nghiệp mới
                    tạo</a></li>
            <li class="menu-item">
                <a href="/quanly_doanhnghiep/danhsach_choduyet" class="menu-link">Danh sách doanh nghiệp chờ duyệt</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_doanhnghiep/danhsach_guilai" class="menu-link">Danh sách doanh nghiệp không duyệt </a>
            </li>
            <li class="menu-item">
                <a href="/quanly_doanhnghiep/danhsach_daduyet" class="menu-link">Danh sách doanh nghiệp đã duyệt</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_doanhnghiep/danhsach_tatca" class="menu-link">Danh sách tất cả doanh nghiệp</a>
            </li>
        </ul>
    </li>
    <li class="menu-item has-dropdown"><a href="" class="menu-link text_upper">Quản trị
            thuế</a>
        <ul class="width_230 nav-dropdown menu">
            <li class="menu-item"><a href="/quanly_thue/hinhthuc_hachtoan"
                                     class="menu-link">Hình thức hạch toán</a></li>
            <li class="menu-item"><a href="/quanly_thue/khobac"
                                     class="menu-link">Danh mục kho bạc</a></li>
            <li class="menu-item"><a href="/quanly_thue/loaithue"
                                     class="menu-link">Danh mục loại thuế</a></li>
            <li class="menu-item"><a href="/quanly_thue/themmoi_thongtin"
                                     class="menu-link">Thêm mới thông tin liên ngành</a>
            </li>
            <li class="menu-item"><a href="/quanly_thue/nopthue_moithem"
                                     class="menu-link">Doanh nghiệp nộp thuế mới
                    thêm</a></li>
            <li class="menu-item"><a href="/quanly_thue/nopthue_choduyet"
                                     class="menu-link">Doanh nghiệp nộp thuế chờ
                    duyệt</a></li>
            <li class="menu-item"><a href="/quanly_thue/khongduyet_guilai"
                                     class="menu-link">Doanh nghiệp không duyệt gửi
                    lại</a></li>
            <li class="menu-item"><a href="/quanly_thue/nopthue_daduyet"
                                     class="menu-link">Doanh nghiệp nộp thuế đã
                    duyệt</a></li>
        </ul>
    </li>
    <li class="menu-item has-dropdown"><a href="" class="menu-link text_upper">Quản trị
            bảo hiểm</a>
        <ul class="width_230 nav-dropdown menu">
            <li class="menu-item">
                <a href="/quanly_baohiem/hoso_baohiem" class="menu-link">Thêm mới thông tin liên ngành</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_baohiem/thamgia_moithem"
                   class="menu-link">Ds doanh nghiệp tham gia bảo hiểm mới thêm</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_baohiem/thamgia_choduyet"
                   class="menu-link">Ds doanh nghiệp tham gia bảo hiểm chờ duyệt</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_baohiem/thamgia_khongduyet_guilai"
                   class="menu-link">Ds doanh nghiệp tham gia bảo hiểm không duyệt gửi lại</a>
            </li>
            <li class="menu-item">
                <a href="/quanly_baohiem/thamgia_daduyet"
                   class="menu-link">Ds doanh nghiệp tham gia bảo hiểm đã duyệt</a>
            </li>
        </ul>
    </li>
    <li class="menu-item has-dropdown"><a href="" class="menu-link text_upper">Quản trị
            cổng thông tin</a>
        <ul class="width_230 nav-dropdown menu">
            <li class="menu-item"><a href="/quanly_cong/danhmuc_tinbai"
                                     class="menu-link">Danh mục tin bài</a></li>
            <li class="menu-item"><a href="/quanly_cong/quanly_tinbai"
                                     class="menu-link">Quản lý tin bài</a></li>
            <li class="menu-item"><a href="/quanly_cong/pheduyet_tinbai"
                                     class="menu-link">Quản lý phê duyệt tin bài</a>
            </li>
            <li class="menu-item"><a href="/quanly_cong/pahnloai_vanban"
                                     class="menu-link">Quản lý phân loại văn bản</a>
            </li>
            <li class="menu-item"><a href="/quanly_cong/vanban_quypham"
                                     class="menu-link">Quản lý văn bản quy phạm pháp
                    luật</a></li>
        </ul>
    </li>
    <li class="menu-item has-dropdown pull-right"><a href="#"
                                                     class="menu-link a_name_login">
            <h5 class="h5_name_goin">Xin chào, <span class="name_login">Jone</span> <i
                        class="fa fa-caret-down" aria-hidden="true"></i></h5>
        </a>
        <ul class="nav-dropdown menu login_menu">
            <li class="menu-item"><a href="/thongtin_canhan" class="menu-link">Thông
                    tin cá nhân</a></li>
            <li class="menu-item"><a href="/doi_matkhau" class="menu-link">Đổi
                    mật khẩu</a></li>
            <div class="divider"></div>
            <li class="menu-item"><a href="#" class="menu-link">Đăng xuất</a></li>
        </ul>
    </li>
</ul>