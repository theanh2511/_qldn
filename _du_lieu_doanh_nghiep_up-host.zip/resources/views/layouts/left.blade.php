<ul>
    <li class="label">Danh mục hệ thống</li>
    
    <li><a class="sidebar-sub-toggle"><i class="ti-home"></i>Cổng thông tin DN   <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a arget="_bank" href="Congthongtin.jpg">Trang cổng thông tin doanh nghiệp </a></li>--}}
            {{--<li><a href="">Quản lý danh mục tin bài </a></li>--}}
            {{--<li><a href="">Quản lý biên tập tin bài </a></li>--}}
            {{--<li><a href="">Quản lý xuất bản tin bài </a></li>--}}
        </ul>
    </li>
    
    <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i>Quản lý văn bản <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/danhmuc/phanloai_vanban">Quản lý phân loại văn bản</a></li>
            {{--<li><a href="">Quản lý danh sách văn bản</a></li>--}}
        </ul>

    </li>

    <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i>Quản lý danh mục <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a href="/danhmuc/tochuc_hanhchinh">Danh mục cấp tổ chức hành chính</a></li>--}}
            <li><a href="/danhmuc/loaihinh_doanhnghiep">Quản lý loại hình doanh nghiệp</a></li>
            <li><a href="/danhmuc/trangthai_doanhnghiep">Quản lý trạng thái doanh nghiệp</a></li>
            <li><a href="/danhmuc/chucdanh_nguoidaidien">Danh mục chức danh người đại diện</a></li>
            <li><a href="/danhmuc/giayto_tuythan">Danh mục loại giấy tờ tùy thân</a></li>
            {{--<li><a href="">Thông tin cổ đông nước ngoài</a></li>--}}
            {{--<li><a href="">Thông tin cổ đông sáng lập</a></li>--}}
            {{--<li><a href="">Thông tin người liên hệ/quản lý khác</a></li>--}}
            {{--<li><a href="">Thông tin hồ sơ doanh nghiệp khi đăng ký</a></li>--}}
            <li><a href="/danhmuc/nganhnghe_kinhdoanh">Quản lý ngành nghề kinh doanh</a></li>
            <li><a href="/danhmuc/hinhthuc_hachtoan">Hình thức hạch toán</a></li>
            <li><a href="/danhmuc/khobac">Quản lý danh mục kho bạc</a></li>
            <li><a href="/danhmuc/loaithue">Quản lý danh mục loại thuế </a></li>
            {{--<li><a href="">Quản lý danh mục tin bài</a></li>--}}

        </ul>

    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i>Cấu hình hệ thống <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/danhmuc/diagioi_captinh">Địa giới cấp tỉnh</a></li>
            <li><a href="/danhmuc/diagioi_caphuyen">Địa giới cấp huyện</a></li>
            <li><a href="/danhmuc/diagioi_capxa">Địa giới cấp xã</a></li>
            <li><a href="/danhmuc/quoctich">Quản lý danh mục quốc tịch</a></li>
            <li><a href="/danhmuc/dantoc">Quản lý danh mục dân tộc </a></li>
        </ul>
    </li>
    <li><a class="sidebar-sub-toggle"><i class="ti-panel"></i> Quản lý Doanh nghiệp <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/quanly_doanhnghiep/hoso_doanhnghiep">Tạo mới hồ sơ</a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_moitao">Danh sách doanh nghiệp mới</a></li>
            <li><a href="">Import dữ liệu </a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_choduyet">Doanh nghiệp chờ duyệt </a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_guilai">Doanh nghiệp không duyệt</a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_daduyet">Doanh nghiệp đã duyệt</a></li>
        </ul>
    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-layout-grid4-alt"></i> Bảo hiểm  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/quanly_baohiem/hoso_baohiem_dn">Thêm mới bảo hiểm của doanh nghiệp </a></li>
            <li><a href="/quanly_baohiem/nguoichuacapbhxh">Thêm mới người chưa được cấp BHXH</a></li>
            <li><a href="/quanly_baohiem/dsnguoichuaduoccapbhxh">Danh sách người chưa được cấp BHXH</a></li>
            <li><a href="/quanly_baohiem/dsnguoidaduoccapbhxh">Thêm mới người đã được cấp BHXH</a></li>
            <li><a href="/quanly_baohiem/dsnguoidaduoccapbhxh">Danh sách người đã được cấp BHXH</a></li>
            <!--  -->
            <li><a href="/quanly_baohiem/danhsach_thamgiabhxh">Doanh nghiệp tham gia bảo hiểm mới</a></li>
            <li><a href="/quanly_baohiem/danhsach_choduyet">Doanh nghiệp tham gia chờ duyệt</a></li>
            <li><a href="/quanly_baohiem/danhsach_guilai">Doanh nghiệp tham gia không duyệt gửi lại</a></li>
            <li><a href="/quanly_baohiem/danhsach_daduyet">Doanh nghiệp tham gia bảo hiểm đã duyệt</a></li>
        </ul>
    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-target"></i> Thuế  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a href="themmoi_thongtin">Thêm mới thông tin liên ngành</a></li>--}}
            {{--<li><a href="nopthue_moithem">Doanh nghiệp nộp thuế mới thêm</a></li>--}}
            {{--<li><a href="nopthue_choduyet">Doanh nghiệp nộp thuế chờ duyệt</a></li>--}}
            {{--<li><a href="khongduyet_guilai">Doanh nghiệp nộp thuế không duyệt gửi lại</a></li>--}}
            {{--<li><a href="nopthue_daduyet">Doanh nghiệp nộp thuế đã duyệt</a></li>--}}
        </ul>
    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-file"></i> Báo cáo bảo hiểm <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a href="">Báo cáo doanh nghiệp chưa tham gia bảo hiểm</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp tham gia bảo hiểm</a></li>--}}

        </ul>

    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-file"></i> Báo cáo bảo thuế <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a href="">Báo cáo doanh nghiệp đã nộp thuế</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp chưa nộp thuế</a></li>--}}
            {{--<li><a href="">Thống kê doanh nghiệp đã nộp thuế theo từng thời điểm</a></li>--}}
        </ul>
    </li>




    <li><a class="sidebar-sub-toggle"><i class="ti-file"></i> Báo cáo Sở KHĐT <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a href="baocao_dangkythanhlap">Báo cáo doanh nghiệp đăng ký thành lập</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp hoạt động trở lại</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp vi phạm, cảnh báo, thu hồi</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp giải thể tự nguyện</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp giải thể do thu hồi, tòa án</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp số vốn đăng ký</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp đăng ký tạm dừng hoạt động</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp đăng ký mẫu dấu</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp số lần thay đổi</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp chuyển đổi</a></li>--}}
            {{--<li><a href="">Doanh nghiệp thuộc khu công nghiệp</a></li>--}}
            {{--<li><a href="baocao_biendongdoanhnghiep">Báo cáo tình hình biến động doanh nghiệp</a></li>--}}
            {{--<li><a href="">Báo cáo tổng hợp số liệu doanh nghiệp theo khu vực</a></li>--}}
            {{--<li><a href="">Báo cáo tổng hợp doanh nghiệp theo lĩnh vực/ngành nghề kinh doanh</a></li>--}}
            {{--<li><a href="">Báo cáo tổng hợp dạng biểu đồ về tình hình doanh nghiệp</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp giải thể tự nguyện</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp giải thể do thu hồi, tòa án</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp số vốn đăng ký</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp đăng ký tạm dừng hoạt động</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp đăng ký mẫu dấu</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp số lần thay đổi</a></li>--}}
            {{--<li><a href="">Báo cáo doanh nghiệp chuyển đổi</a></li>--}}
        </ul>
    </li>
    <li><a class="sidebar-sub-toggle"><i class="ti-search"></i> Tra cứu  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            {{--<li><a href="tracuu_thongbaothaydoiDN">Tra cứu thông báo thay đổi DN</a></li>--}}
            {{--<li><a href="">Tra cứu thông báo tạm dừng doanh nghiệp</a></li>--}}
            {{--<li><a href="">Tra cứu thông báo giải thể Doanh nghiệp</a></li>--}}
            {{--<li><a href="">Tra cứu số người tham gia bảo hiểm </a></li>--}}
        </ul>
    </li>
    
    <li><a><i class="ti-close"></i> Thoát </a></li>
</ul>


<style type="text/css">
    .sidebar-sub-toggle,.active{
        font-size: 15px;
    }
</style>               