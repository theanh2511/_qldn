
    
        
    
        
    
    
            
            
        
    
    
            
        
    
    
       
        


<div class="col-lg-12" style="text-align: center;">
    <button type="button" id="btn-search"
            class="btn btn-success btn-addon btn-sm m-b-10 m-l-5">
        <i class="ti-search"></i>Tìm kiếm
    </button>
    <button id="btn-open-new-form" type="button" class="btn btn-info btn-addon btn-sm m-b-10 m-l-5"
            data-toggle="modal" data-target="#modal_editor">
        <i class="ti-plus"></i>Thêm mới
    </button>
    <button type="submit" form="search-form"
            class="btn btn-success btn-addon btn-sm m-b-10 m-l-5" id="btn-save"
            style="display: none;">
        <i class="fa fa-save"></i>&nbsp;Lưu
    </button>
    
            
        
    
    <a class="btn btn-danger btn-addon btn-sm m-b-10 m-l-5" id="btn-cancel"
       style="display: none;">
        <i class="fa fa-ban"></i>&nbsp;Hủy</a>
</div><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/layouts/buttons_danhmuc.blade.php ENDPATH**/ ?>