<input type="text" id="<?php echo e(isset($id)?$id:''); ?>" placeholder="<?php echo e(isset($placeholder)?$placeholder:''); ?>"
       <?php echo e((isset($disabled)?$disabled:'')=="1"?"disabled":""); ?>

       class="form-control input-sm input-default input-sm money <?php echo e(isset($class)?$class:''); ?> <?php echo e(isset($is_required) && $is_required ?'required':''); ?>"
       real_len="<?php echo e((isset($real_len)?$real_len:'12')); ?>"
       decimal_len="<?php echo e((isset($decimal_len)?$decimal_len:'0')); ?>"
       name="<?php echo e(isset($name)?$name:(isset($id)?$id:null)); ?>"
       value="<?php echo e(isset($value)?$value:''); ?>"
       style="text-align: right;"><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/custom_controls/numeric.blade.php ENDPATH**/ ?>