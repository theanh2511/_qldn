<?php echo public_url('js/lib/jquery.min.js'); ?>

<?php echo public_url('js/lib/jquery.nanoscroller.min.js'); ?>

<?php echo public_url('js/lib/sidebar.js'); ?>

<?php echo public_url('js/lib/bootstrap.min.js'); ?>

<?php echo public_url('js/lib/mmc-common.js'); ?>






<?php echo public_url('js/lib/datamap/d3.min.js'); ?>

<?php echo public_url('js/lib/datamap/topojson.js'); ?>







<?php echo public_url('js/lib/owl-carousel/owl.carousel.min.js'); ?>

<?php echo public_url('js/lib/owl-carousel/owl.carousel-init.js'); ?>


<script>

</script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>

</html>
<?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/layouts/footer.blade.php ENDPATH**/ ?>