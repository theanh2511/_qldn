<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1><?php echo e($title ?? "Form name"); ?></h1>
                    </div>
                </div>
            </div><!-- /# column -->
            <div class="col-lg-7 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Quản trị doanh nghiệp</a></li>
                            <li class="active"><?php echo e($title ?? "Form name"); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /# column -->
        </div><!-- /# row -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="search-form"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      class="form-horizontal"><?php echo csrf_field(); ?>
                                    <div class="form_search">
                                        <div class="form_search">
                                            <div class="container-fluid">
                                                <div class="clearfix-10"></div>
                                                <div class="form-group">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Lựa chọn huyện</label>
                                                            <?php echo $__env->make('custom_controls.selectbox',
                                                            array('id'=>'ma_huyen',
                                                                'select_data'=>$list_quan_huyen,
                                                                'value_member'=>'ma_huyen',
                                                                'display_member'=>'ten_huyen',
                                                                'selected_value'=>""
                                                            ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix-10"></div>
                                                    <div class="col-md-4">
                                                        <label class="col-md-12" for="">Mã xã </label>
                                                        <div class="col-md-12">
                                                            <input type="text"
                                                                   class="form-control input-sm input-default"
                                                                   id="ma_xa"
                                                                   name="ma_xa">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="col-md-12" for="">Tên xã</label>
                                                        <div class="col-md-12">
                                                            <input type="text"
                                                                   class="form-control input-sm input-default"
                                                                   id="ten_xa"
                                                                   name="ten_xa">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label for="">&nbsp;</label>
                                                        <?php echo $__env->make('layouts.buttons_danhmuc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </div>
                                                </div>
                                                <div class="clearfix-10"></div>
                                                <div class="clearfix-10"></div>
                                            </div>
                                        </div>
                                        <div class="table_out" id="responsive">
                                            <table id="table_data" class="table table-striped table-hover"
                                                   style="border: 1px solid #ccc;">
                                                <thead class="text-center">
                                                <tr>
                                                    <th>STT</th>
                                                    <th>Mã xã</th>
                                                    <th>Tên xã</th>
                                                    <th></th>
                                                    <th>Chức năng</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td width="5%"
                                                            class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
                                                        <td width="15%" class="ma_xa"><?php echo e($value->ma_xa); ?></td>
                                                        <td class="ten_xa"><?php echo e($value->ten_xa); ?></td>
                                                        <td class="ma_tinh hidden"><?php echo e($value->ma_tinh); ?></td>
                                                        <td class="ma_huyen hidden"><?php echo e($value->ma_huyen); ?></td>
                                                        <td class="ghichu hidden"><?php echo e($value->ghichu); ?></td>
                                                        <?php echo $__env->make('layouts.grid_buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <center>
                                                <?php echo e($list_data->links()); ?>

                                            </center>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div><!-- /# column -->
            </div>
        </div><!-- /# column -->
    </div>

    <div id="modal_editor" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Cập nhật địa giới cấp xã</h4>
                </div>
                <div class="modal-body">
                    <form id="editor-form"
                          action="<?php echo e(url('/danhmuc/'.$command_key.'/update')); ?>"
                          method="POST"
                          enctype="multipart/form-data"
                          class="form-horizontal"><?php echo csrf_field(); ?>
                        <input type="hidden" id="primary_key" name="id" value="">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Lựa chọn tỉnh</label>
                                    <?php echo $__env->make('custom_controls.selectbox',
                                    array('id'=>'ma_tinh',
                                        'select_data'=>$list_tinh_thanh,
                                        'value_member'=>'ma_tinh',
                                        'display_member'=>'ten_tinh',
                                        'selected_value'=>""
                                    ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Lựa chọn huyện</label>
                                    <?php echo $__env->make('custom_controls.selectbox',
                                    array('id'=>'ma_huyen',
                                        'select_data'=>$list_quan_huyen,
                                        'value_member'=>'ma_huyen',
                                        'display_member'=>'ten_huyen',
                                        'selected_value'=>""
                                    ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Mã xã</label>
                                    <input name="ma_xa" type="text" class="form-control input-sm input-default">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Tên xã</label>
                                    <input name="ten_xa" type="text" class="form-control  input-sm input-default ">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label>Ghi chú</label>
                                    <textarea name="ghichu" class="form-control input-default input-sm"
                                              rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" form="editor-form" id="btn-save" class="btn btn-info btn-sm ">Cập nhật
                    </button>
                    <button type="button" class="btn btn-default btn-sm " data-dismiss="modal">Đóng</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        var _command_key = '<?php echo $command_key ?>';
        $(document).ready(function () {
            /**
             * @Description: Process display function button on screen
             */
            $(document).on('click', '.btn-edit', function (e) {
                var _row_detail = $(this).parents('tr');
                $('#primary_key').val($(this).data('primary_key'));
                $('#modal_editor').find('select[name="ma_tinh"]').val(_row_detail.find('.ma_tinh').text());
                $('#modal_editor').find('select[name="ma_huyen"]').val(_row_detail.find('.ma_huyen').text());
                $('#modal_editor').find('input[name="ma_xa"]').val(_row_detail.find('.ma_xa').text());
                $('#modal_editor').find('input[name="ten_xa"]').val(_row_detail.find('.ten_xa').text());
                $('#modal_editor').find('textarea[name="ghichu"]').val(_row_detail.find('.ghichu').text());

                $('#modal_editor').modal('show');
            });
            ///End: Process display function button on screen
        });
    </script>
    <?php echo public_url('js/danhmuc/func_danhmuc.js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/danhmuc/diagioi_capxa/index.blade.php ENDPATH**/ ?>