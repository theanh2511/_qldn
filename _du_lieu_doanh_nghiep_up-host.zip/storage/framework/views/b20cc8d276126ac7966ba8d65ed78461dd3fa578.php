<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Tạo mới hồ sơ doanh nghiệp</h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Quản trị doanh nghiệp</a></li>
                            <li class="active">Tạo mới hồ sơ doanh nghiệp</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-header">
                        </div>
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="editor-form"
                                      action="<?php echo e(url('/quanly_doanhnghiep/hoso_doanhnghiep/update/'.($item_hsdn->id??""))); ?>"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      class="form-horizontal"><?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số doanh nghiệp</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'maso_dn', 'value'=>$item_hsdn->maso_dn), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Tên doanh nghiệp</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'ten_dn', 'value'=>$item_hsdn->ten_dn), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Quận huyện</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                array('id'=>'quan_huyen',
                                                    'select_data'=>$list_quan_huyen,
                                                    'value_member'=>'ma_huyen',
                                                    'display_member'=>'ten_huyen',
                                                    'selected_value'=>$item_hsdn->quan_huyen
                                                ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Xã phường</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                array('id'=>'xa_phuong',
                                                    'select_data'=>$list_xa_phuong,
                                                    'value_member'=>'ma_xa',
                                                    'display_member'=>'ten_xa',
                                                    'selected_value'=>$item_hsdn->xa_phuong
                                                ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Vốn điều lệ</label>
                                                <?php echo $__env->make('custom_controls.numeric', array('id'=>'von_dl', 'value'=>number_format($item_hsdn->von_dl)), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Trạng thái</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                array('id'=>'trang_thai',
                                                    'select_data'=>$item_hsdn->getListOfStatus(),
                                                    'array_source'=>'1',
                                                    'selected_value'=>$item_hsdn->trang_thai
                                                ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Người đại diện theo pháp luật</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'nguoi_daidien', 'value'=>$item_hsdn->nguoi_daidien), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Số chứng minh thư/Hộ chiếu</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'cmt_hochieu', 'value'=>$item_hsdn->cmt_hochieu), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Ngày cấp</label>
                                                
                                                       
                                                       
                                                <?php echo $__env->make('custom_controls.datepicker', array('id'=>'ngaycap_cmt', 'value'=>$item_hsdn->ngaycap_cmt), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Nơi cấp</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'noi_cap', 'value'=>$item_hsdn->noi_cap), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Chủ sở hữu</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'so_huu', 'value'=>$item_hsdn->so_huu), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Ngành nghề kinh doanh chính</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'kinhdoanh_chinh', 'value'=>$item_hsdn->kinhdoanh_chinh), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label>Ngành nghề kinh doanh</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'nganh_nghe', 'value'=>$item_hsdn->nganh_nghe), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Ngày cấp</label>
                                                <?php echo $__env->make('custom_controls.datepicker', array('id'=>'ngay_cap', 'value'=>$item_hsdn->ngay_cap), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Ngày đăng ký thay đổi</label>
                                                <?php echo $__env->make('custom_controls.datepicker', array('id'=>'ngay_thay_doi', 'value'=>$item_hsdn->ngay_thay_doi), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Loại hình doanh nghiệp</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                array('id'=>'loai_hinh',
                                                    'select_data'=>$list_loai_hinh_dn,
                                                    'value_member'=>'ma_lh',
                                                    'display_member'=>'ten_lh',
                                                    'selected_value'=>$item_hsdn->loai_hinh
                                                ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Số lượng lao động</label>
                                                <?php echo $__env->make('custom_controls.numeric', array('id'=>'so_laodong', 'value'=>number_format($item_hsdn->so_laodong)), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Danh sách thành viên góp vốn</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'ds_thanhvien', 'value'=>$item_hsdn->ds_thanhvien), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Danh sách cổ đông <span style="color: #FF0000;">(mỗi cổ đông ngăn cách bởi dấu ';')</span></label>
                                                <textarea class="form-control input-sm input-default"
                                                          rows="3"><?php echo e($item_hsdn->ds_codong); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Loại doanh nghiệp</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                        array('id'=>'loai_dn',
                                                            'select_data'=>$item_hsdn->list_of_types,
                                                            'array_source'=>'1',
                                                            'selected_value'=>$item_hsdn->loai_dn
                                                        ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row toggle-form">
                                                <div class="col-md-5 tittle-toggle-form">Ngành nghề kinh doanh</div>
                                                <div class="col-md-7">

                                                    <button type="button"
                                                            class="btn btn-default btn-outline btn-xs pull-right"
                                                            id="btn1"><i class="fa fa-caret-up" aria-hidden="true"></i>
                                                        Mở rộng
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid">
                                            <div class="form-group">
                                                <label>Tên ngành nghề kinh doanh</label>
                                                <select class="form-control input-sm input-default">
                                                    <option>=== Lựa chọn ===</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid">
                                            <div class="form-group">
                                                <label>Ngày cập nhật</label>
                                                <input type="date" class="form-control  input-sm input-default ">
                                            </div>
                                        </div>

                                        <div class="col-lg-12 toggel-hid">
                                            <div class="form-group">
                                                <label>Ghi chú</label>
                                                <textarea class="form-control input-default" rows="3" placeholder="">

                                                        </textarea>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row toggle-form">
                                                <div class="col-md-5 tittle-toggle-form">Loại hình doanh nghiệp</div>
                                                <div class="col-md-7">

                                                    <button type="button"
                                                            class="btn btn-default btn-outline btn-xs pull-right"
                                                            id="btn2"><i class="fa fa-caret-up" aria-hidden="true"></i>
                                                        Mở rộng
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-2">
                                            <div class="form-group">
                                                <label>Tên loại hình doanh nghiệp</label>
                                                <select class="form-control input-sm input-default">
                                                    <option>=== Lựa chọn ===</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-2">
                                            <div class="form-group">
                                                <label>Ngày cập nhật</label>
                                                <input type="date" class="form-control  input-sm input-default ">
                                            </div>
                                        </div>

                                        <div class="col-lg-12 toggel-hid-2">
                                            <div class="form-group">
                                                <label>Ghi chú</label>
                                                <textarea class="form-control input-default" rows="3" placeholder="">

                                                        </textarea>
                                            </div>
                                        </div>

                                        <!-- Người đại diện theo pháp luật -->
                                        <div class="col-lg-12">
                                            <div class="row toggle-form">
                                                <div class="col-md-5 tittle-toggle-form">Người đại diện theo pháp luật
                                                </div>
                                                <div class="col-md-7">

                                                    <button type="button"
                                                            class="btn btn-default btn-outline btn-xs pull-right"
                                                            id="btn3"><i class="fa fa-caret-up" aria-hidden="true"></i>
                                                        Mở rộng
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-3">
                                            <div class="form-group">
                                                <label>Họ tên</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-3">
                                            <div class="form-group">
                                                <label>Số điện thoại</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 toggel-hid-3">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-3">
                                            <div class="form-group">
                                                <label>Địa chỉ</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row toggle-form">
                                                <div class="col-md-5 tittle-toggle-form">Thông tin người liên hệ/quản lý
                                                    khác
                                                </div>
                                                <div class="col-md-7">

                                                    <button type="button"
                                                            class="btn btn-default btn-outline btn-xs pull-right"
                                                            id="btn4"><i class="fa fa-caret-up" aria-hidden="true"></i>
                                                        Mở rộng
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-4">
                                            <div class="form-group">
                                                <label>Họ tên</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-4">
                                            <div class="form-group">
                                                <label>Số điện thoại</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 toggel-hid-4">
                                            <div class="form-group">
                                                <label>Email</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 toggel-hid-4">
                                            <div class="form-group">
                                                <label>Địa chỉ</label>
                                                <input type="text" class="form-control  input-sm input-default">
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row toggle-form">
                                                <div class="col-md-5 tittle-toggle-form">Quá trình lịch sử thay đổi
                                                </div>
                                                <div class="col-md-7">

                                                    <button type="button"
                                                            class="btn btn-default btn-outline btn-xs pull-right"
                                                            id="btn5"><i class="fa fa-caret-up" aria-hidden="true"></i>
                                                        Mở rộng
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-12 toggel-hid-5">
                                            <div class="form-group">
                                                <label>Nội dung</label>
                                                <textarea class="form-control input-default" rows="3" placeholder="">

                                                        </textarea>
                                            </div>
                                        </div>


                                        <div class="col-lg-12" style="text-align: center;">
                                            <button type="button" class="btn btn-info  btn-addon m-b-10 m-l-5"><i
                                                        class="ti-plus"></i>Thêm mới
                                            </button>
                                            <button type="button" class="btn btn-danger btn-addon m-b-10 m-l-5"><i
                                                        class="ti-close"></i>Hủy bỏ
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- /# column -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $("#btn1").click(function () {
            $(".toggel-hid").toggle();
        });
        $("#btn2").click(function () {
            $(".toggel-hid-2").toggle();
        });
        $("#btn3").click(function () {
            $(".toggel-hid-3").toggle();
        });
        $("#btn4").click(function () {
            $(".toggel-hid-4").toggle();
        });
        $("#btn5").click(function () {
            $(".toggel-hid-5").toggle();
        });
    </script>
    <?php echo public_url('js/quanly_doanhnghiep/edit.js'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_doanhnghiep/edit.blade.php ENDPATH**/ ?>