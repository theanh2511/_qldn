<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Họ và tên</th>
        <th>Số CMND/Hộ chiếu</th>
        <th>Họ tên cha/mẹ/giám hộ (đối với trẻ em < 6 tuổi)</th>
        <th></th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-object_value="<?php echo e($value->toJson()); ?>">
            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
            <td class="ten_ca_nhan"><?php echo e($value->ten_ca_nhan); ?></td>
            <td class="so_cmt"><?php echo e($value->so_cmt); ?></td>
            <td class="nguoi_giam_ho"><?php echo e($value->nguoi_giam_ho); ?></td>
            <td>
                <button type="button"
                        class="btn btn-info btn-addon btn-xs m-b-10 btn-cap-bhxh"
                        data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                            class="fa fa-check" aria-hidden="true"></i>Cấp BHXH
                </button>
            </td>
            <?php echo $__env->make('layouts.baohiem_grid_buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<center>
    <?php echo e($list_data->links()); ?>

</center><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_baohiem/dsnguoichuaduoccapbhxh/_search.blade.php ENDPATH**/ ?>