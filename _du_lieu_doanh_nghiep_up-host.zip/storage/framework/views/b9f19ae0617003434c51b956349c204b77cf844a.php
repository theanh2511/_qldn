<textarea id="<?php echo e(isset($id)?$id:''); ?>" placeholder="<?php echo e(isset($placeholder)?$placeholder:''); ?>"
          <?php echo e((isset($disabled)?$disabled:'')=="1"?"disabled":""); ?>

          class="form-control input-sm input-default <?php echo e(isset($class)?$class:''); ?> <?php echo e(isset($is_required) && $is_required ?'required':''); ?>"
          rows="<?php echo e(isset($number_of_row)?$number_of_row:3); ?>" cols="100" wrap="hard"
          name="<?php echo e(isset($name)?$name:(isset($id)?$id:null)); ?>"><?php echo e(isset($value)?$value:''); ?></textarea><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/custom_controls/textarea.blade.php ENDPATH**/ ?>