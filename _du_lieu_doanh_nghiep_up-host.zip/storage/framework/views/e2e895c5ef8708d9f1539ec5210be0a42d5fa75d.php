
























<td class="text-center" width="20%">
    <button type="button"
            class="btn btn-warning btn-addon btn-xs m-b-10 btn-view btn-view"
            data-toggle="modal" data-target="#modal_view">
        <i class="fa fa-eye" aria-hidden="true"></i>Xem
    </button>

    <button type="button" data-primary_key="<?php echo e($value->id); ?>"
            class="btn btn-success btn-addon btn-xs m-b-10 btn-edit">
        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>Sửa
    </button>

    <button type="button" data-primary_key="<?php echo e($value->id); ?>"
            class="btn btn-danger btn-addon btn-xs m-b-10 btn-delete">
        <i class="fa fa-times" aria-hidden="true"></i>Xóa
    </button>

</td><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/layouts/baohiem_grid_buttons.blade.php ENDPATH**/ ?>