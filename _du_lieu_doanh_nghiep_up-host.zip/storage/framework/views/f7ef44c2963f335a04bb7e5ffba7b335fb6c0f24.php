<input type="file"
       id="<?php echo e(isset($id)?$id:''); ?>" placeholder="<?php echo e(isset($placeholder)?$placeholder:''); ?>"
       <?php echo e((isset($disabled)?$disabled:'')=="1"?"disabled":""); ?>

       name="<?php echo e(isset($name)?$name:(isset($id)?$id:null)); ?>"
       class="form-control  input-sm input-default input-sm <?php echo e(isset($class)?$class:''); ?>"/><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/custom_controls/input_file.blade.php ENDPATH**/ ?>