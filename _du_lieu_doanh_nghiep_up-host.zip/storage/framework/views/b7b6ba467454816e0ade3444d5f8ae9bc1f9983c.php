<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead class="text-center">
    <tr>
        <th>STT</th>
        <th>Mã quốc tịch</th>
        <th>Tên quốc tịch</th>
        <th></th>
        <th>Chức năng</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
            <td class="ma_qt"><?php echo e($value->ma_qt); ?></td>
            <td class="ten_qt"><?php echo e($value->ten_qt); ?></td>
            <td class="ghichu hidden"><?php echo e($value->ghichu); ?></td>
            <?php echo $__env->make('layouts.grid_buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<center>
    <?php echo e($list_data->links()); ?>

</center><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/danhmuc/quoctich/_search.blade.php ENDPATH**/ ?>