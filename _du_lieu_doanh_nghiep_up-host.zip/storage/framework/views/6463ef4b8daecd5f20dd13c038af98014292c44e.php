<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số doanh nghiệp</th>
        <th>Tên doanh nghiệp</th>
        <th>Người đại diện</th>
        <th>Trạng thái</th>
        <th style="width: 110px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-object_value="<?php echo e($value->toJson()); ?>">
            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
            <td class="maso_dn"><?php echo e($value->maso_dn); ?></td>
            <td class="ten_dn"><?php echo e($value->ten_dn); ?></td>
            <td class="nguoi_dai_dien"><?php echo e($value->nguoi_daidien); ?></td>
            <td class="ten_trang_thai"><?php echo e($value->ten_trang_thai); ?></td>
            <td>
                <div class="dropdown">
                    <button type="button"
                            class="btn btn-info btn-addon btn-xs m-b-10 btn_duyet_hoso_dn"
                            data-primary_key="<?php echo e($value->id); ?>"
                            data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                                class="fa fa-check" aria-hidden="true"></i>Duyệt hồ sơ
                    </button>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<center>
    <?php echo e($list_data->links()); ?>

</center><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_doanhnghiep/danhsach_guilai/_search.blade.php ENDPATH**/ ?>