<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số đơn vị</th>
        <th>Tên đơn vị</th>
        <th>Mã số thuế</th>
        <th>Số điện thoại</th>
        <th>Email</th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-object_value="<?php echo e($value->toJson()); ?>"
            data-list_cnbhxh="<?php echo e($value->getDanhSachCaNhanBHXH()); ?>">
            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
            <td class="maso_dn"><?php echo e($value->maso_dn); ?></td>
            <td class="ten_dn"><?php echo e($value->ten_dn); ?></td>
            <td class="maso_thue"><?php echo e($value->maso_thue); ?></td>
            <td class="tel"><?php echo e($value->tel); ?></td>
            <td class="email"><?php echo e($value->email); ?></td>
            <?php echo $__env->make('layouts.baohiem_grid_buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<center>
    <?php echo e($list_data->links()); ?>

</center><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_baohiem/ds_moi_thamgia/_search.blade.php ENDPATH**/ ?>