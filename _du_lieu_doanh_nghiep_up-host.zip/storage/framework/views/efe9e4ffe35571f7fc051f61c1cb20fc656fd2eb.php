
    
           
           
           
           
           
           
    
        
            
        
    


<input type="date" id="<?php echo e(isset($id)?$id:''); ?>" name="<?php echo e(isset($id)?$id:''); ?>"
       value="<?php echo e(isset($value)?$value:''); ?>"
       placeholder="dd/mm/yyyy" autocomplete="off"
       <?php echo e((isset($disabled)?$disabled:'')=="1"?"disabled":""); ?>

       class="form-control input-sm input-default <?php echo e(isset($class)?$class:''); ?>"><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/custom_controls/datepicker.blade.php ENDPATH**/ ?>