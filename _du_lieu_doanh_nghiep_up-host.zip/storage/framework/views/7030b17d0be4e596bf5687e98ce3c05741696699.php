<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 p-0">
                <div class="page-header">

                </div>
            </div><!-- /# column -->
            <div class="col-lg-4 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li class="active">Home</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /# column -->
        </div><!-- /# row -->
        <div class="main-content">
            <div class="row">


                <ul style="font-size: 15px; font-weight: bold" class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#home">Báo cáo Sở kế hoạch đầu tư</a></li>
                    <li><a data-toggle="tab" href="#menu1">Báo cáo Thuế</a></li>
                    <li><a data-toggle="tab" href="#menu2">Báo cáo Bảo Hiểm</a></li>

                </ul>


                <div class="tab-content">
                    <div id="home" class="tab-pane fade in active">

                        <div class="col-lg-3"><select class="form-control input-default input-sm">
                                <option>Lựa chọn tháng</option>
                            </select></div>
                        <div class="col-lg-3"><select class="form-control input-default input-sm">
                                <option>Lựa chọn năm</option>
                            </select></div>
                        <div class="col-lg-3"><select class="form-control input-default input-sm">
                                <option>Lựa chọn quý</option>
                            </select></div>
                        <div class="col-lg-3">
                            <button type="button" class="btn btn-success btn-addon btn-sm m-b-10 m-l-5"><i
                                        class="ti-search"></i>Tìm kiếm
                            </button>
                        </div>


                        <div style="margin-bottom: 20px" class="clearfix"></div>

                        <div class="col-lg-9">
                            <div class="card alert">
                                <div class="card-header">

                                    <div class="card-header-right-icon">
                                        <ul>
                                            <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sales-chart">

                                    <<?php echo $__env->make('layouts.bando', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </div>
                            </div>
                        </div><!-- /# column -->
                        <div class="col-lg-3">
                            <div class="card alert nestable-cart single-card">
                                <div class="card-header">
                                    <h4>Đăng ký mới</h4>
                                </div>
                                <div class="sparkline-box">
                                    <span id="sparklinedash"><canvas width="67" height="30"
                                                                     style="display: inline-block; width: 67px; height: 30px; vertical-align: top;"></canvas></span>
                                </div>
                                <div class="visit-count">
                                    8.23K
                                </div>
                            </div>

                            <div class="card alert nestable-cart single-card">
                                <div class="card-header">
                                    <h4>Hoạt động trở lại</h4>
                                </div>
                                <div class="sparkline-box">
                                    <span id="sparklinedash3"><canvas width="67" height="30"
                                                                      style="display: inline-block; width: 67px; height: 30px; vertical-align: top;"></canvas></span>
                                </div>
                                <div class="visit-count">
                                    4.5K
                                </div>
                            </div>
                            <div class="card alert nestable-cart single-card">
                                <div class="card-header">
                                    <h4>Doanh nghiệp giải thể</h4>
                                </div>
                                <div class="sparkline-box">
                                    <span id="sparklinedash2"><canvas width="67" height="30"
                                                                      style="display: inline-block; width: 67px; height: 30px; vertical-align: top;"></canvas></span>
                                </div>
                                <div class="visit-count">
                                    92.5K
                                </div>
                            </div>

                            <div class="card alert nestable-cart single-card">
                                <div class="card-header">
                                    <h4>Đang khởi tạo</h4>
                                </div>
                                <div class="sparkline-box">
                                    <span id="sparklinedash2"><canvas width="67" height="30"
                                                                      style="display: inline-block; width: 67px; height: 30px; vertical-align: top;"></canvas></span>
                                </div>
                                <div class="visit-count">
                                    2.5K
                                </div>
                            </div>


                        </div>


                    </div>
                    <div id="menu1" class="tab-pane fade">


                        <div class="col-lg-6">
                            <div class="card alert">

                                <div class="card-body" id="container1"
                                     style="min-width: 430px; height: 400px; margin: 0 auto">
                                    <?php echo $__env->make('layouts.bando_danopthue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div><!-- /# column -->

                        <div class="col-lg-6">
                            <div class="card alert">

                                <div class="card-body" id="container2"
                                     style="min-width: 430px; height: 400px; margin: 0 auto">
                                    <?php echo $__env->make('layouts.bando_chuanopthue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div><!-- /# column -->
                        <div class="col-lg-12">
                            <div class="card alert">

                                <div class="card-body" id="container4"
                                     style="width: 900px; height: 400px; margin: 0 auto">
                                    <?php echo $__env->make('layouts.bando4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div><!-- /# column -->

                    </div>
                    <div id="menu2" class="tab-pane fade">

                        <div class="col-lg-12">
                            <div class="card alert">

                                <div class="card-body" id="container_dathamgiabhxh"
                                     style="width: 900px; height: 500px; margin: 0 auto">
                                    <?php echo $__env->make('layouts.bando_dathamgiabhxh', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div><!-- /# column -->
                    </div>

                    <div id="menu3" class="tab-pane fade">
                        <h3>Menu 3</h3>
                        <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt
                            explicabo.</p>
                    </div>
                </div>


            </div><!-- /# row -->


            <div class="row">


                <div style="margin-left: 20px;"><h4>Văn bản mới nhất </h4></div>
                <div class="col-lg-12">
                    <div class="card bg-success" style="background: #fff; border: 1px solid #ccc; color: #333">
                        <div class="testimonial-widget-one p-17">
                            <div class="owl-carousel owl-theme">

                                <div class="item">
                                    <div class="testimonial-content">
                                        <div class="testimonial-text">
                                            <i class="fa fa-quote-left"></i> Căn cứ các quy định của Luật Đấu thầu
                                            số 43/2013/QH13; Nghị định số 63/2014/NĐ-CP ngày 26/6/2014 và Nghị định
                                            số 30/2015/NĐ-CP ngày 17/3/2015 của Chính phủ; Thông tư số 06/2017/TT-BKHĐT
                                            ngày 05/12/2017 của Bộ Kế hoạch và Đầu tư V/v Quy định chi tiết việc cung
                                            cấp thông tin về đấu thầu, báo cáo tình hình thực hiện hoạt động đấu thầu về
                                            lựa chọn nhà thầu...<i class="fa fa-quote-right"></i>
                                        </div>


                                        <img class="testimonial-author-img"
                                             src="http://css.hcmussh.edu.vn/Services/GetArticleImage.ashx?Id=f646839a-1ce3-4510-9189-1d171b35aa4e"
                                             alt=""/>


                                        <div class="testimonial-author">V/v Báo cáo THTH công tác đấu thầu năm 2018
                                        </div>
                                        <div class="testimonial-author-position"><a style="color: red"
                                                                                    href="http://skhdt.bacninh.gov.vn/documents/57283/0/Desktop......rar/30ef4e05-7b14-4fb3-b502-6d185fa10d80"><b>Tải
                                                    file đính kèm</b></a></div>
                                    </div>
                                </div>

                                <div class="item">
                                    <div class="testimonial-content">
                                        <div class="testimonial-text">
                                            <i class="fa fa-quote-left"></i> Căn cứ các quy định của Luật Đấu thầu
                                            số 43/2013/QH13; Nghị định số 63/2014/NĐ-CP ngày 26/6/2014 và Nghị định
                                            số 30/2015/NĐ-CP ngày 17/3/2015 của Chính phủ; Thông tư số 06/2017/TT-BKHĐT
                                            ngày 05/12/2017 của Bộ Kế hoạch và Đầu tư V/v Quy định chi tiết việc cung
                                            cấp thông tin về đấu thầu, báo cáo tình hình thực hiện hoạt động đấu thầu về
                                            lựa chọn nhà thầu...<i class="fa fa-quote-right"></i>
                                        </div>

                                        <img class="testimonial-author-img"
                                             src="http://css.hcmussh.edu.vn/Services/GetArticleImage.ashx?Id=f646839a-1ce3-4510-9189-1d171b35aa4e"
                                             alt=""/>

                                        <div class="testimonial-author">V/v Báo cáo THTH công tác đấu thầu năm 2018
                                        </div>
                                        <div class="testimonial-author-position"><a style="color: red"
                                                                                    href="http://skhdt.bacninh.gov.vn/documents/57283/0/Desktop......rar/30ef4e05-7b14-4fb3-b502-6d185fa10d80"><b>Tải
                                                    file đính kèm</b></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div><!-- /# main content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/index.blade.php ENDPATH**/ ?>