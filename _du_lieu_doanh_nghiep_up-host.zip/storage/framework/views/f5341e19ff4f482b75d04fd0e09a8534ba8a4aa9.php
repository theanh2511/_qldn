<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số đơn vị</th>
        <th>Tên đơn vị</th>
        <th>Mã số thuế</th>
        <th>Số điện thoại</th>
        <th style="text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-object_value="<?php echo e($value->toJson()); ?>">
            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
            <td class="maso_dn"><?php echo e($value->maso_dn); ?></td>
            <td class="ten_dn"><?php echo e($value->ten_dn); ?></td>
            <td class="maso_thue"><?php echo e($value->maso_thue); ?></td>
            <td class="tel"><?php echo e($value->tel); ?></td>
            <td>
                <div class="dropdown">
                    <button class="btn btn-success btn-addon btn-xs m-b-10"
                            type="button" data-toggle="dropdown">
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                        Chức năng
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu ul-group-button">
                        <li>
                            <a data-toggle="modal" class="btn-view btn"
                               data-target="#modal_view">Xem</a>
                        </li>
                        <li><a class="btn-edit btn">Sửa</a></li>
                        <li><a class="btn-delete btn" data-primary_key="<?php echo e($value->id); ?>">Xóa</a>
                        </li>
                    </ul>
                    <button type="button" class="btn btn-info btn-addon btn-xs m-b-10 btn_duyet_hoso_dn"
                            data-primary_key="<?php echo e($value->id); ?>"
                            data-toggle="modal" data-target="#modal_duyet_bhxh"><i
                                class="fa fa-check" aria-hidden="true"></i>Duyệt hồ sơ
                    </button>


                </div>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<center>
    <?php echo e($list_data->links()); ?>

</center><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_baohiem/ds_choduyet/_search.blade.php ENDPATH**/ ?>