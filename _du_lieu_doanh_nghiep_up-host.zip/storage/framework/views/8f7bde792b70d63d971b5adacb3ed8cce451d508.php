<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>




<script>
	Highcharts.chart('container2', {
  chart: {
    type: 'spline'
  },
  title: {
    text: 'Báo cáo doanh nghiệp chưa nộp thuế'
  },
  subtitle: {
    // text: 'Source: WorldClimate.com'
  },
  xAxis: {
    categories: ['Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12']
  },
  yAxis: {
    title: {
      text: 'Nghìn tỷ đồng'
    },
    labels: {
      formatter: function () {
        return this.value;
      }
    }
  },
  tooltip: {
    crosshairs: true,
    shared: true
  },
  plotOptions: {
    spline: {
      marker: {
        radius: 4,
        lineColor: '#666666',
        lineWidth: 1
      }
    }
  },
  series: [{
    name: 'Tỉnh Bắc Ninh',
    marker: {
      symbol: 'square'
    },
    data: [147, {
      y: 172,
      marker: {
        symbol: 'url(https://www.highcharts.com/samples/graphics/sun.png)'
      }
    }, 156, 143, 131, 125]

  }]
});
</script><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/layouts/bando_chuanopthue.blade.php ENDPATH**/ ?>