<?php
    $select_data;
    $selected_value;

    $value_member = isset($value_member)?$value_member:'id';
    $display_member = isset($display_member)?$display_member:'';
    $array_source = isset($array_source)?$array_source:'0';
?>

<select class="form-control input-sm input-default input-sm <?php echo e(isset($class)?$class:''); ?>"
        <?php echo e((isset($disabled)?$disabled:'')=="1"?"disabled":""); ?>

        name="<?php echo e(isset($name)?$name:(isset($id)?$id:null)); ?>"
        <?php echo e(isset($multiple)&&$multiple=='1'?"multiple":'id'); ?> style="font-weight: <?php echo e(isset($is_bold)&&$is_bold=='1'?"700":'500'); ?>;font-style: <?php echo e(isset($is_italic)&&$is_italic=='1'?"italic":'normal'); ?>;">
    <option value="">=== Lựa chọn ===</option>
    <?php $__currentLoopData = $select_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($array_source!='1'): ?>
            <option
                    <?php
                        if(isset($arr_attributes)){
                        foreach($arr_attributes as $arr_attribute){
                                echo  ("data-".$arr_attribute.'="'. $item->$arr_attribute .'"');
                            }
                        }else{
                        echo  ('data-name="'. ($item->name??"") .'"');
                        }
                    ?>
                    value="<?php echo e($item->$value_member); ?>" <?php echo e($item->$value_member==$selected_value?'selected':''); ?>

                    title="<?php echo e($item->$display_member); ?>"><?php echo e($item->$display_member); ?>

            </option>
        <?php else: ?>
            <option value="<?php echo e($key); ?>" <?php echo e($key==$selected_value?'selected':''); ?>

                    title="<?php echo e($item); ?>"><?php echo e($item); ?>

            </option>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/custom_controls/selectbox.blade.php ENDPATH**/ ?>