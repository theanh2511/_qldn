<table id="table_data" class="table table-striped table-hover"
       style="border: 1px solid #ccc;">
    <thead>
    <tr>
        <th>STT</th>
        <th>Mã số doanh nghiệp</th>
        <th>Tên doanh nghiệp</th>
        <th>Số ĐT</th>
        <th>Người đại diện</th>
        <th>Trạng thái</th>
        <th style="width: 200px;text-align: center;">Chức năng</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr data-object_value="<?php echo e($value->toJson()); ?>">
            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
            <td class="maso_dn"><?php echo e($value->maso_dn); ?></td>
            <td class="ten_dn"><?php echo e($value->ten_dn); ?></td>
            <td class="tel"><?php echo e($value->tel); ?></td>
            <td class="nguoi_dai_dien"><?php echo e($value->nguoi_daidien); ?></td>
            <td class="ten_trang_thai"><?php echo e($value->ten_trang_thai); ?></td>
            <?php echo $__env->make('layouts.baohiem_grid_buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<center>
    <?php echo e($list_data->links()); ?>

</center><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_doanhnghiep/danhsach_daduyet/_search.blade.php ENDPATH**/ ?>