<?php $__env->startSection('css'); ?>
    <style>
        .tb-modal-bhxh th, .tb-modal-bhxh td {
            text-align: left;
            border: none !important;
        }

        tbody tr td:last-child {
            text-align: left;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1><?php echo e($title); ?></h1>
                    </div>
                </div>
            </div><!-- /# column -->
            <div class="col-lg-7 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Quản lý doanh nghiệp</a></li>
                            <li class="active"><?php echo e($title); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /# column -->
        </div><!-- /# row -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="search-form"
                                      method="POST"
                                      action="/quanly_doanhnghiep/danhsach_daduyet/search"
                                      enctype="multipart/form-data"
                                      class="form-horizontal"><?php echo csrf_field(); ?>
                                    <input type="hidden" name="trang_thai_duyet" value="3">
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số đơn vị</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'maso_dn', 'value'=>""), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Tên đơn vị</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'ten_dn', 'value'=>""), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Họ tên chủ doanh nghiệp</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'so_huu', 'value'=>""), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Quận huyện</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                        array('id'=>'quan_huyen',
                                                            'select_data'=>$list_quan_huyen,
                                                            'value_member'=>'ma_huyen',
                                                            'display_member'=>'ten_huyen',
                                                            'selected_value'=>''
                                                        ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Xã phường</label>
                                                <div class="col-md-12" id="ht_xa">
                                                    <?php echo $__env->make('custom_controls.selectbox',
                                                            array('id'=>'xa_phuong',
                                                                'select_data'=>$list_xa_phuong,
                                                                'value_member'=>'ma_xa',
                                                                'display_member'=>'ten_xa',
                                                                'selected_value'=>''
                                                            ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Ngành nghề kinh doanh</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'nganh_nghe', 'value'=>""), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-12" style="text-align: center;">
                                            <div class="form-group">
                                                <button type="button" id="btn-search"
                                                        class="btn btn-success btn-addon btn-sm m-b-10 m-l-5">
                                                    <i class="ti-search"></i>Tìm kiếm
                                                </button>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                            <div class="table_out" id="responsive">
                                <table id="table_data" class="table table-striped table-hover"
                                       style="border: 1px solid #ccc;">
                                    <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Mã số doanh nghiệp</th>
                                        <th>Tên doanh nghiệp</th>
                                        <th>Người đại diện</th>
                                        <th>Trạng thái</th>
                                        <th style="width: 200px;text-align: center;">Chức năng</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $list_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-object_value="<?php echo e($value->toJson()); ?>">
                                            <td class="stt_ht"><?php echo e(($perPage*($currentPage-1))+$key+1); ?></td>
                                            <td class="maso_dn"><?php echo e($value->maso_dn); ?></td>
                                            <td class="ten_dn"><?php echo e($value->ten_dn); ?></td>
                                            <td class="nguoi_dai_dien"><?php echo e($value->nguoi_daidien); ?></td>
                                            <td class="ten_trang_thai"><?php echo e($value->ten_trang_thai); ?></td>
                                            <td style="text-align: center;">
                                                <?php if($value->hsdn_logs->count()!=0): ?>
                                                    <button type="button" data-s_logs="<?php echo e($value->hsdn_logs->toJson()); ?>"
                                                            class="btn btn-warning btn-addon btn-xs m-b-10 m-l-5 btn-view-notification"
                                                            data-toggle="modal" data-target="#modal_notification">
                                                        <i class="fa fa-bell" aria-hidden="true"></i>Xem
                                                    </button>
                                                <?php endif; ?>
                                                <button type="button"
                                                        class="btn btn-info btn-addon btn-xs m-b-10 m-l-5 pull-right"
                                                        data-toggle="modal" data-target="#modal_view">
                                                    <i class="fa fa-eye" aria-hidden="true"></i>Xem
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <center>
                                    <?php echo e($list_data->links()); ?>

                                </center>
                            </div>
                        </div>
                    </div>
                </div><!-- /# column -->
            </div>
        </div><!-- /# card -->
    </div><!-- /# column -->


    
    <div id="modal_view" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Xem thông tin chi tiết doanh nghiệp tham gia bảo hiểm mới</h4>
                </div>
                <div class="modal-body" style="height: 500px;overflow: scroll;">
                    <div class="custom-tab">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#1" aria-controls="1" role="tab"
                                                                      data-toggle="tab" aria-expanded="true">Thông tin
                                    doanh nghiệp</a></li>
                            <li role="presentation" class=""><a href="#2" aria-controls="2" role="tab" data-toggle="tab"
                                                                aria-expanded="false">Quá trình hoạt động của doanh
                                    nghiệp</a></li>

                        </ul>
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="1">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Mã số doanh nghiệp</label>
                                        <input type="text" class="form-control input-sm input-default input-sm "
                                               disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-8">
                                    <div class="form-group">
                                        <label>Tên doanh nghiệp</label>
                                        <input type="text" class="form-control  input-sm input-default input-sm "
                                               disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Quận huyện</label>
                                        <select class="form-control input-sm input-default input-sm" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label>Xã phường</label>
                                        <select class="form-control input-sm input-default input-sm" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group" disabled="">
                                        <label>Vốn điều lệ</label>
                                        <input type="text" class="form-control  input-sm input-default input-sm"
                                               disabled>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Trạng thái</label>
                                        <select class="form-control input-sm input-default input-sm" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Người đại diện theo pháp luật</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Số chứng minh thư/Hộ chiếu</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Ngày cấp</label>
                                        <input type="date" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Nơi cấp</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Chủ sở hữu</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="form-group">
                                        <label>Ngành nghề kinh doanh chính</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Ngành nghề kinh doanh</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Ngày cấp</label>
                                        <input type="date" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Ngày đăng ký thay đổi</label>
                                        <input type="date" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Loại hình doanh nghiệp</label>
                                        <select class="form-control input-sm input-default" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Số lượng lao động</label>
                                        <input type="number" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-8">
                                    <div class="form-group">
                                        <label>Danh sách thành viên góp vốn</label>
                                        <input type="text" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="form-group">
                                        <label>Danh sách cổ đông <span style="color: #FF0000;">(mỗi cổ đông ngăn cách bởi dấu ';')</span></label>
                                        <textarea class="form-control input-sm input-default" rows="3"
                                                  disabled=""></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Loại doanh nghiệp</label>
                                        <select class="form-control input-sm input-default" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row toggle-form">
                                        <div class="col-md-5 tittle-toggle-form">Ngành nghề kinh doanh</div>
                                        <div class="col-md-7">

                                            <button type="button" class="btn btn-default btn-outline btn-xs pull-right"
                                                    id="btn1"><i class="fa fa-caret-up" aria-hidden="true"></i> Mở rộng
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid">
                                    <div class="form-group">
                                        <label>Tên ngành nghề kinh doanh</label>
                                        <select class="form-control input-sm input-default" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid">
                                    <div class="form-group">
                                        <label>Ngày cập nhật</label>
                                        <input type="date" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-12 toggel-hid">
                                    <div class="form-group">
                                        <label>Ghi chú</label>
                                        <textarea class="form-control input-default" rows="3"
                                                  placeholder="" disabled="">
                                                        </textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row toggle-form">
                                        <div class="col-md-5 tittle-toggle-form">Loại hình doanh nghiệp</div>
                                        <div class="col-md-7">

                                            <button type="button" class="btn btn-default btn-outline btn-xs pull-right"
                                                    id="btn2"><i class="fa fa-caret-up" aria-hidden="true"></i> Mở rộng
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-2">
                                    <div class="form-group">
                                        <label>Tên loại hình doanh nghiệp</label>
                                        <select class="form-control input-sm input-default" disabled="">
                                            <option>=== Lựa chọn ===</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-2">
                                    <div class="form-group">
                                        <label>Ngày cập nhật</label>
                                        <input type="date" class="form-control  input-sm input-default " disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-12 toggel-hid-2">
                                    <div class="form-group">
                                        <label>Ghi chú</label>
                                        <textarea class="form-control input-default" rows="3"
                                                  placeholder="" disabled="">
                                                        </textarea>
                                    </div>
                                </div>

                                <!-- Người đại diện theo pháp luật -->
                                <div class="col-lg-12">
                                    <div class="row toggle-form">
                                        <div class="col-md-5 tittle-toggle-form">Người đại diện theo pháp luật</div>
                                        <div class="col-md-7">

                                            <button type="button" class="btn btn-default btn-outline btn-xs pull-right"
                                                    id="btn3"><i class="fa fa-caret-up" aria-hidden="true"></i> Mở rộng
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-3">
                                    <div class="form-group">
                                        <label>Họ tên</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-3">
                                    <div class="form-group">
                                        <label>Số điện thoại</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-6 toggel-hid-3">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-3">
                                    <div class="form-group">
                                        <label>Địa chỉ</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row toggle-form">
                                        <div class="col-md-5 tittle-toggle-form">Thông tin người liên hệ/quản lý khác
                                        </div>
                                        <div class="col-md-7">

                                            <button type="button" class="btn btn-default btn-outline btn-xs pull-right"
                                                    id="btn4"><i class="fa fa-caret-up" aria-hidden="true"></i> Mở rộng
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-4">
                                    <div class="form-group">
                                        <label>Họ tên</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-4">
                                    <div class="form-group">
                                        <label>Số điện thoại</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-6 toggel-hid-4">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-6 toggel-hid-4">
                                    <div class="form-group">
                                        <label>Địa chỉ</label>
                                        <input type="text" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row toggle-form">
                                        <div class="col-md-5 tittle-toggle-form">Quá trình lịch sử thay đổi</div>
                                        <div class="col-md-7">

                                            <button type="button" class="btn btn-default btn-outline btn-xs pull-right"
                                                    id="btn5"><i class="fa fa-caret-up" aria-hidden="true"></i> Mở rộng
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12 toggel-hid-5">
                                    <div class="form-group">
                                        <label>Nội dung</label>
                                        <textarea class="form-control input-default" rows="3"
                                                  placeholder="" disabled="">
                                                        </textarea>
                                    </div>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="2">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Từ ngày</label>
                                        <input type="date" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label>Đến ngày</label>
                                        <input type="date" class="form-control  input-sm input-default" disabled="">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label>Nội dung, thay đổi</label>
                                        <textarea class="form-control input-default" rows="3" placeholder=""
                                                  disabled=""></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                </div>
            </div>

        </div>
    </div>

    
    <div id="modal_notification" class="modal fade in" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <h4 class="modal-title">Thông báo</h4>
                </div>
                <div class="modal-body">

                </div>

                <div class="hidden">
                    <div class="row div_item_slogs card-body">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="lbl_stt">Ngày gửi thông báo</label>
                                <?php echo $__env->make('custom_controls.datepicker', array('class'=>'ngaygui_thongbao', 'value'=>"", "disabled"=>"1"), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Nơi gửi</label>
                                <?php echo $__env->make('custom_controls.textbox', array('class'=>'noi_gui', 'value'=>"", "disabled"=>"1"), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label>Nội dung thay đổi</label>
                                <?php echo $__env->make('custom_controls.textarea', array('class'=>'noidung_thaydoi', "disabled"=>"1", 'value'=>""), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer" style="text-align: center;">
                    <button type="button" id="btn-approve-logs" class="btn btn-info btn-addon btn-sm">
                        <i class="fa fa-check" aria-hidden="true"></i>Duyệt
                    </button>
                    <button type="button" class="btn btn-default btn-sm m-b-10 pull-right" data-dismiss="modal">Close
                    </button>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $("#btn1").click(function () {
            $(".toggel-hid").toggle();
        });
        $("#btn2").click(function () {
            $(".toggel-hid-2").toggle();
        });
        $("#btn3").click(function () {
            $(".toggel-hid-3").toggle();
        });
        $("#btn4").click(function () {
            $(".toggel-hid-4").toggle();
        });
        $("#btn5").click(function () {
            $(".toggel-hid-5").toggle();
        });
    </script>
    <script>
        $(document).ready(function () {
            /**
             *  Redirect link to edit single record
             */
            $(document).on('click', '.btn-edit', function (e) {
                var _tr = $(this).parents('tr');
                var _obj_value = _tr.data('object_value');

                location.href = "/quanly_doanhnghiep/hoso_doanhnghiep/" + _obj_value["id"];
            });

            /**
             *  Open modal view information
             */
            $(document).on('click', '.btn-view', function (e) {
                var _tr = $(this).parents('tr');
                var _obj_value = _tr.data('object_value');

                $('#modal-table tbody td[field_name]').each(function () {
                    var attr = $(this).attr('field_name');

                    if (typeof attr !== typeof undefined && attr !== false) {
                        $(this).text(_obj_value[attr]);
                    }
                });
            });


            /**
             *  Open modal view change log information
             */
            $(document).on('click', '.btn-view-notification', function (e) {
                var _obj_value = $(this).data('s_logs');
                var x = "";
                $('#modal_notification div.modal-body').empty();
                $.each(_obj_value, function (i) {
                    let _div_item_slogs = $('div.div_item_slogs').parent().clone();

                    _div_item_slogs.find('.ngaygui_thongbao').val(_obj_value[i]['modify_date']);
                    _div_item_slogs.find('input.noi_gui').val("2222222");
                    _div_item_slogs.find('textarea.noidung_thaydoi').text(_obj_value[i]['modify_content']);
                    _div_item_slogs.find('label.lbl_stt').text((i + 1) + '. Ngày gửi thông báo');
                    // x = x + _div_item_slogs.html();

                    // console.log(_div_item_slogs.find('input.noi_gui').length);
                    $('#modal_notification .modal-body').append(_div_item_slogs);
                });
                // $('#modal_notification .modal-body').append(x);
            });

            /**
             *  Event search
             */
            $(document).on('click', '#btn-search', function (e) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: $('#search-form').attr('action'),
                    type: 'GET',
                    loading: true,
                    dataType: "html",
                    data: $("#search-form").serialize(),
                    success: function (res) {
                        if (res.status == "201" || res.status == "202") {
                            alert(res.message);
                        } else {
                            $('#responsive').empty();
                            $('#responsive').append(res);
                        }
                    }
                });
            });

            /**
             *  Delete single record
             */
            $(document).on('click', 'button.btn-delete', function (e) {
                var _r = confirm("Xóa dữ liệu đã chọn?");
                if (_r) {
                    var _id = $(this).data('primary_key');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: '/quanly_doanhnghiep/hoso_doanhnghiep/delete/' + _id,
                        type: 'POST',
                        loading: true,
                        data: null,
                        success: function (res) {
                            if (res.status == 201) {
                                console.log(res.message);
                                let _errs = "";
                                let _index = 1;
                                $.each(res.message, function (key, value) {
                                    _errs = _errs + _index + ". " + value[0].toString() + "\n";
                                    _index++;
                                });
                                alert(_errs);
                            } else if (res.status == 200) {
                                alert(res.message);
                                location.reload(true);
                            } else {
                                alert(res.message);
                            }
                        }
                    });
                }
            });

            /**
             * List xa_phuong by quan_huyen
             */
            $(document).on('change', 'select[name="quan_huyen"]', function (e) {
                var _ma_huyen = $(this).val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: '/quanly_doanhnghiep/search_quan_huyen',
                    type: 'POST',
                    loading: true,
                    data: {
                        ma_huyen: _ma_huyen
                    },
                    success: function (res) {
                        var _div_xa_phuong = $('select[name="xa_phuong"]').parent();
                        _div_xa_phuong.empty();
                        _div_xa_phuong.append(res);
                    }
                });
            });
        });
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_doanhnghiep/danhsach_daduyet/index.blade.php ENDPATH**/ ?>