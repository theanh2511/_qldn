<input type="text" id="<?php echo e(isset($id)?$id:''); ?>" placeholder="<?php echo e(isset($placeholder)?$placeholder:''); ?>"
       <?php echo e((isset($disabled)?$disabled:'')=="1"?"disabled":""); ?>

       class="form-control input-sm input-default input-sm <?php echo e(isset($class)?$class:''); ?> <?php echo e(isset($is_required) && $is_required ?'required':''); ?>"
       name="<?php echo e(isset($name)?$name:(isset($id)?$id:null)); ?>"
       value="<?php echo e(isset($value)?$value:''); ?>"
       title="<?php echo e(isset($value)?$value:''); ?>"><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/custom_controls/textbox.blade.php ENDPATH**/ ?>