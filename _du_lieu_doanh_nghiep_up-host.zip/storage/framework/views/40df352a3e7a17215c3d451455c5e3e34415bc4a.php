<ul>
    <li class="label">Danh mục hệ thống</li>
    
    <li><a class="sidebar-sub-toggle"><i class="ti-home"></i>Cổng thông tin DN   <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            
            
            
        </ul>
    </li>
    
    <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i>Quản lý văn bản <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/danhmuc/phanloai_vanban">Quản lý phân loại văn bản</a></li>
            
        </ul>

    </li>

    <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i>Quản lý danh mục <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            <li><a href="/danhmuc/loaihinh_doanhnghiep">Quản lý loại hình doanh nghiệp</a></li>
            <li><a href="/danhmuc/trangthai_doanhnghiep">Quản lý trạng thái doanh nghiệp</a></li>
            <li><a href="/danhmuc/chucdanh_nguoidaidien">Danh mục chức danh người đại diện</a></li>
            <li><a href="/danhmuc/giayto_tuythan">Danh mục loại giấy tờ tùy thân</a></li>
            
            
            
            
            <li><a href="/danhmuc/nganhnghe_kinhdoanh">Quản lý ngành nghề kinh doanh</a></li>
            <li><a href="/danhmuc/hinhthuc_hachtoan">Hình thức hạch toán</a></li>
            <li><a href="/danhmuc/khobac">Quản lý danh mục kho bạc</a></li>
            <li><a href="/danhmuc/loaithue">Quản lý danh mục loại thuế </a></li>
            

        </ul>

    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i>Cấu hình hệ thống <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/danhmuc/diagioi_captinh">Địa giới cấp tỉnh</a></li>
            <li><a href="/danhmuc/diagioi_caphuyen">Địa giới cấp huyện</a></li>
            <li><a href="/danhmuc/diagioi_capxa">Địa giới cấp xã</a></li>
            <li><a href="/danhmuc/quoctich">Quản lý danh mục quốc tịch</a></li>
            <li><a href="/danhmuc/dantoc">Quản lý danh mục dân tộc </a></li>
        </ul>
    </li>
    <li><a class="sidebar-sub-toggle"><i class="ti-panel"></i> Quản lý Doanh nghiệp <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/quanly_doanhnghiep/hoso_doanhnghiep">Tạo mới hồ sơ</a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_moitao">Danh sách doanh nghiệp mới</a></li>
            <li><a href="">Import dữ liệu </a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_choduyet">Doanh nghiệp chờ duyệt </a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_guilai">Doanh nghiệp không duyệt</a></li>
            <li><a href="/quanly_doanhnghiep/danhsach_daduyet">Doanh nghiệp đã duyệt</a></li>
        </ul>
    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-layout-grid4-alt"></i> Bảo hiểm  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            <li><a href="/quanly_baohiem/hoso_baohiem_dn">Thêm mới bảo hiểm của doanh nghiệp </a></li>
            <li><a href="/quanly_baohiem/nguoichuacapbhxh">Thêm mới người chưa được cấp BHXH</a></li>
            <li><a href="/quanly_baohiem/dsnguoichuaduoccapbhxh">Danh sách người chưa được cấp BHXH</a></li>
            <li><a href="/quanly_baohiem/dsnguoidaduoccapbhxh">Thêm mới người đã được cấp BHXH</a></li>
            <li><a href="/quanly_baohiem/dsnguoidaduoccapbhxh">Danh sách người đã được cấp BHXH</a></li>
            <!--  -->
            <li><a href="/quanly_baohiem/danhsach_thamgiabhxh">Doanh nghiệp tham gia bảo hiểm mới</a></li>
            <li><a href="/quanly_baohiem/danhsach_choduyet">Doanh nghiệp tham gia chờ duyệt</a></li>
            <li><a href="/quanly_baohiem/danhsach_guilai">Doanh nghiệp tham gia không duyệt gửi lại</a></li>
            <li><a href="/quanly_baohiem/danhsach_daduyet">Doanh nghiệp tham gia bảo hiểm đã duyệt</a></li>
        </ul>
    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-target"></i> Thuế  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            
            
            
            
        </ul>
    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-file"></i> Báo cáo bảo hiểm <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            

        </ul>

    </li>


    <li><a class="sidebar-sub-toggle"><i class="ti-file"></i> Báo cáo bảo thuế <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            
            
        </ul>
    </li>




    <li><a class="sidebar-sub-toggle"><i class="ti-file"></i> Báo cáo Sở KHĐT <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        </ul>
    </li>
    <li><a class="sidebar-sub-toggle"><i class="ti-search"></i> Tra cứu  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
        <ul>
            
            
            
            
        </ul>
    </li>
    
    <li><a><i class="ti-close"></i> Thoát </a></li>
</ul>


<style type="text/css">
    .sidebar-sub-toggle,.active{
        font-size: 15px;
    }
</style>               <?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/layouts/left.blade.php ENDPATH**/ ?>