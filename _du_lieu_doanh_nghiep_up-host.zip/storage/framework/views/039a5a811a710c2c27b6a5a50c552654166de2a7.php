<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <h1>Người chưa được cấp mã số BHXH</h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 p-0">
                <div class="page-header">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Trang chủ</a></li>
                            <li><a href="#">Bảo hiểm</a></li>
                            <li class="active">Người chưa được cấp mã số BHXH</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card alert">
                        <div class="card-body">
                            <div class="basic-elements">
                                <form id="editor-form"
                                      action="<?php echo e(url('/quanly_baohiem/nguoichuacapbhxh/update/'.($item_hsbh->id??""))); ?>"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      class="form-horizontal"><?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mã số đơn vị</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'maso_dn', 'value'=>$item_hsbh->maso_dn), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="form-group">
                                                <label>Tên đơn vị</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'ten_dn', 'value'=>$item_hsbh->ten_dn,'disabled'=>'1'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Họ và tên</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'ten_ca_nhan', 'value'=>$item_hsbh->ten_ca_nhan), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Ngày/tháng/năm sinh</label>
                                                <?php echo $__env->make('custom_controls.datepicker', array('id'=>'ngay_sinh', 'value'=>$item_hsbh->ngay_sinh), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Giới tính</label>
                                                <?php echo $__env->make('custom_controls.selectbox',
                                                array('id'=>'gioi_tinh',
                                                'select_data'=>$item_hsbh->list_of_gender,
                                                'array_source'=>'1',
                                                'selected_value'=>$item_hsbh->gioi_tinh
                                                ), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Quốc tịch</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'quoc_tich', 'value'=>$item_hsbh->quoc_tich), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Dân tộc</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'dan_toc', 'value'=>$item_hsbh->dan_toc), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Nơi đăng ký giấy khai sinh</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'dangky_khaisinh', 'value'=>$item_hsbh->dangky_khaisinh), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>Địa chỉ nhận kết quả</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'diachi', 'value'=>$item_hsbh->diachi), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Số CMND/Hộ chiếu/Thẻ căn cước</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'so_cmt', 'value'=>$item_hsbh->so_cmt), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label>Số điện thoại liên hệ</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'tel', 'value'=>$item_hsbh->tel), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Họ tên cha/mẹ/giám hộ (đối với trẻ em < 6 tuổi)</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'nguoi_giam_ho', 'value'=>$item_hsbh->nguoi_giam_ho), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Mức tiền đóng</label>
                                                <?php echo $__env->make('custom_controls.numeric', array('id'=>'muc_tien_dong', 'value'=>$item_hsbh->muc_tien_dong), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="form-group">
                                                <label>Phương thức đóng</label>
                                                <?php echo $__env->make('custom_controls.textbox', array('id'=>'phuongthuc_dong', 'value'=>$item_hsbh->phuongthuc_dong), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        </div>


                                        <div class="col-lg-12" style="text-align: center;">
                                            <?php if($item_hsbh->id): ?>
                                                <button type="submit" class="btn btn-info  btn-addon m-b-10 m-l-5">
                                                    <i class="ti-save"></i>Lưu
                                                </button>
                                            <?php else: ?>
                                                <button type="submit" class="btn btn-info  btn-addon m-b-10 m-l-5">
                                                    <i class="ti-plus"></i>Thêm mới
                                                </button>
                                            <?php endif; ?>
                                            <button type="button" id="btn-back" class="btn btn-danger btn-addon m-b-10 m-l-5"><i
                                                        class="ti-close"></i>Hủy bỏ
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div><!-- /# card -->
            </div><!-- /# column -->
        </div><!-- /# row -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <?php echo public_url('js/quanly_baohiem/edit_baohiem_cn.js'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/ql_baohiem/edit_nguoichuacapbhxh.blade.php ENDPATH**/ ?>