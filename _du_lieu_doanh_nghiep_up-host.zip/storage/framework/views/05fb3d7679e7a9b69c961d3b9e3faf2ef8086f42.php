<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrap">
    <div class="main">
            <?php echo $__env->yieldContent('content'); ?>

        </div><!-- /# row -->
    </div><!-- /# main content -->
</div><!-- /# container-fluid -->
</div><!-- /# main -->
</div><!-- /# content wrap -->




<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\E-Works\_du_lieu_doanh_nghiep\resources\views/layouts/main.blade.php ENDPATH**/ ?>