$(document).ready(function () {
    "use strict";

    initTriggers();
    initEvents();
});

function initTriggers() {

}

function initEvents() {
    /**
     * @Description: Submit form (Event update)
     */
    $('#editor-form').submit(function (e) {
        e.preventDefault();
        var _r = confirm("Lưu dữ liệu hiện tại");
        if (_r) {
            $.ajax({
                url: $('#editor-form').attr('action'),
                type: 'POST',
                loading: true,
                data: $("#editor-form").serialize(),
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        if (res.primary_key) {
                            location.href = '/quanly_baohiem/nguoichuacapbhxh/' + res.primary_key;
                        } else {
                            location.reload(true);
                        }

                    } else {
                        alert(res.message);
                    }
                }
            });
        }
        return false;
    });

    // editor-form-nguoidacapbhxh submit
    $('#editor-form-nguoidacapbhxh').submit(function (e) {
        e.preventDefault();
        var _r = confirm("Lưu dữ liệu hiện tại");
        if (_r) {
            $.ajax({
                url: $('#editor-form-nguoidacapbhxh').attr('action'),
                type: 'POST',
                loading: true,
                data: $("#editor-form-nguoidacapbhxh").serialize(),
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        if (res.primary_key) {
                            location.href = '/quanly_baohiem/nguoidacapbhxh/' + res.primary_key;
                        } else {
                            location.reload(true);
                        }

                    } else {
                        alert(res.message);
                    }
                }
            });
        }
        return false;
    });

    $(document).on('change', '#maso_dn', function (e) {
        console.log(111);
        var _maso_dn = $(this).val();
        if (_maso_dn != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/api/quanly_doanhnghiep/hoso_doanhnghiep/get/maso_dn',
                type: 'POST',
                loading: true,
                data: {
                    maso_dn: _maso_dn
                },
                success: function (res) {
                    console.log(res);
                    if (res) {
                        $('#ten_dn').val(res.ten_dn);
                    }
                }
            });
        }
    });


    $(document).on('click', '#btn-back', function (e) {
        e.preventDefault();
        if ('referrer' in document) {
            window.location.href = document.referrer;
        } else {
            window.history.back();
        }
    });
}
