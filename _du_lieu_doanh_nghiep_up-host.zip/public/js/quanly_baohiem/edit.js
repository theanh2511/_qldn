$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    /**
     * @Description: Submit form (Event update)
     */
    $('#editor-form').submit(function (e) {
        e.preventDefault();

        $.ajax({
            url: $('#editor-form').attr('action'),
            type: 'POST',
            loading: true,
            data: $("#editor-form").serialize(),
            success: function (res) {
                if (res.status == 201) {
                    console.log(res.message);
                    let _errs = "";
                    let _index = 1;
                    $.each(res.message, function (key, value) {
                        _errs = _errs + _index + ". " + value[0].toString() + "\n";
                        _index++;
                    });
                    alert(_errs);
                } else if (res.status == 200) {
                    alert(res.message);
                    if (res.primary_key) {
                        location.href = '/quanly_baohiem/hoso_baohiem_dn/' + res.primary_key;
                    } else {
                        location.reload(true);
                    }

                } else {
                    alert(res.message);
                }
            }
        });
        return false;
    });

    $(document).on('change', '#maso_dn', function (e) {
        var _maso_dn = $(this).val();
        if (_maso_dn != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/api/quanly_doanhnghiep/hoso_doanhnghiep/get/maso_dn',
                type: 'POST',
                loading: true,
                data: {
                    maso_dn: _maso_dn
                },
                success: function (res) {
                    console.log(res);
                    if (res) {
                        $('#ten_dn').val(res.ten_dn);
                        $('#diachi_dangkykinhdoanh').val(res.diachi);
                        $('#diachi_giaodich').val(res.diachi);
                        $('#tel').val(res.tel);
                        $('#email').val(res.email);
                        $('select[name="loai_hinh"]').val(res.loai_hinh);
                    }
                }
            });
        }
    });

    $(document).on('click', '#btn-back', function (e) {
        e.preventDefault();
        if ('referrer' in document) {
            window.location.href = document.referrer;
        } else {
            window.history.back();
        }
    });
}
