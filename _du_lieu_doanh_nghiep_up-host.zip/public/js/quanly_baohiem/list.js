$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    /**
     * @Description: Event search
     */
    $(document).on('click', '#btn-search', function (e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: $('#search-form').attr('action'),
            type: 'GET',
            loading: true,
            dataType: "html",
            data: $("#search-form").serialize(),
            success: function (res) {
                if (res.status == "201" || res.status == "202") {
                    alert(res.message);
                } else {
                    $('#responsive').empty();
                    $('#responsive').append(res);
                }
            }
        });
    });

    $(document).on('click', '#responsive li.page-item a.page-link', function (e) {
        e.preventDefault();
        var _page = $(this).text();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: $('#search-form').attr('action'),
            type: 'GET',
            loading: true,
            dataType: "html",
            data: $("#search-form").serialize() + "&page=" + _page,
            success: function (res) {
                if (res.status == "201" || res.status == "202") {
                    alert(res.message);
                } else {
                    $('#responsive').empty();
                    $('#responsive').append(res);
                }
            }
        });
        return false;
    });

    //End search

    /**
     * @Description: Delete single record
     */
    $(document).on('click', 'button.btn-delete', function (e) {
        var _r = confirm("Xóa dữ liệu đã chọn?");
        if (_r) {
            var _id = $(this).data('primary_key');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/quanly_baohiem/bhxh_cn/delete/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    $(document).on('click', 'ul.ul-group-button a.btn-delete', function (e) {
        var _r = confirm("Xóa dữ liệu đã chọn?");
        if (_r) {
            var _id = $(this).data('primary_key');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/quanly_baohiem/hoso_baohiem_dn/delete/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    /**
     * @Description: Open modal duyet BHXH cá nhân
     */
    $(document).on('click', '.btn-cap-bhxh', function (e) {
        var _tr = $(this).parents('tr');
        var _obj_value = _tr.data('object_value');
        $('#primary_key').val(_obj_value["id"]);
    });


    /**
     * @Description: Open modal view information
     */
    $(document).on('click', '.btn-view', function (e) {
        var _tr = $(this).parents('tr');
        var _obj_value = _tr.data('object_value');

        $('#modal-table tbody td[field_name]').each(function () {
            var attr = $(this).attr('field_name');

            if (typeof attr !== typeof undefined && attr !== false) {
                if (attr == "ngay_sinh") {
                    $(this).text(_obj_value[attr].split("-").reverse().join("/"));
                } else {
                    $(this).text(_obj_value[attr]);
                }

            }
        });
    });

    /**
     * Duyệt cấp BHXH cá nhân
     */
    $(document).on('click', '#btn-cap-bhxh', function (e) {
        var _r = confirm("Cấp bảo hiểm xã hội cho cá nhân đang chọn?");
        if (_r) {
            var _primary_key = $('#primary_key').val();
            var _url = "/quanly_baohiem/duyetcapbhxh/" + _primary_key;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: _url,
                type: 'POST',
                loading: true,
                data: {
                    ngaycap_bhxh: $('#ngaycap_bhxh').val(),
                    maso_bhxh: $('#maso_bhxh').val(),
                    ghichu: $('#ghichu').val()
                },
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);

                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });
}
