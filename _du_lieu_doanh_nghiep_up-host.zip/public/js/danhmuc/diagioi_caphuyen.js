$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    /**
     * @Description: Process display function button on scree
     */
    $(document).on('click', '.btn-edit', function (e) {
        var _row_detail = $(this).parents('tr');
        $('#primary_key').val($(this).data('primary_key'));
        $('#ma_huyen').val(_row_detail.find('.ma_huyen').text());
        $('#ten_huyen').val(_row_detail.find('.ten_huyen').text());
        $('#stt_ht').val(_row_detail.find('.stt_ht').text());

        $('#btn-save').css('display', 'inline-block');
        $('#btn-delete').css('display', 'inline-block');
        $('#btn-cancel').css('display', 'inline-block');
        $('#btn-add').css('display', 'none');
    });

    $(document).on('click', '#btn-cancel', function (e) {
        $('#btn-save').css('display', 'none');
        $('#btn-delete').css('display', 'none');
        $('#btn-cancel').css('display', 'none');
        $('#btn-add').css('display', 'inline-block');

        $('#primary_key').val('');
        $('#ma_huyen').val('');
        $('#ten_huyen').val('');
        $('#stt_ht').val('');
    });
    ///End: Process display function button on scree

    /**
     * @Description: Add new record
     */
    $(document).on('click', '#btn-add', function (e) {
        var _r = confirm("Lưu dữ liệu hiện tại");
        if (_r) {
            $.ajax({
                url: '/danhmuc/diagioi_caphuyen/store',
                type: 'POST',
                loading: true,
                data: $("#editor-form").serialize(),
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        var _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    /**
     * @Description: Submit form (Event update)
     */
    $('#editor-form').submit(function (e) {
        e.preventDefault();

        $.ajax({
            url: $('#editor-form').attr('action'),
            type: 'POST',
            loading: true,
            data: $("#editor-form").serialize(),
            success: function (res) {
                if (res.status == 201) {
                    console.log(res.message);
                    let _errs = "";
                    let _index = 1;
                    $.each(res.message, function (key, value) {
                        _errs = _errs + _index + ". " + value[0].toString() + "\n";
                        _index++;
                    });
                    alert(_errs);
                } else if (res.status == 200) {
                    alert(res.message);
                    location.reload(true);
                } else {
                    alert(res.message);
                }
            }
        });
        return false;
    });

    /**
     * @Description: Delete single record
     */
    $(document).on('click', '#btn-delete', function (e) {
        var _r = confirm("Lưu dữ liệu hiện tại");
        if (_r) {
            var _id = $('#primary_key').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/danhmuc/diagioi_caphuyen/delete/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    /**
     * @Description: Event search
     */
    $(document).on('click', '#btn-search', function (e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/danhmuc/diagioi_caphuyen/search',
            type: 'POST',
            loading: true,
            data: $("#editor-form").serialize(),
            success: function (res) {
                $('#table_data tbody').empty();
                $('#table_data tbody').append(res);
            }
        });
    });
}
