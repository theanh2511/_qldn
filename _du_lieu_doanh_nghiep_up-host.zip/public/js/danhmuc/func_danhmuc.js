$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    // /**
    //  * @Description: Process display function button on scree
    //  */
    // $(document).on('click', '.btn-edit', function (e) {
    //     var _row_detail = $(this).parents('tr');
    //     $('#primary_key').val($(this).data('primary_key'));
    //     $('#ma_huyen').val(_row_detail.find('.ma_huyen').text());
    //     $('#ten_huyen').val(_row_detail.find('.ten_huyen').text());
    //     $('#stt_ht').val(_row_detail.find('.stt_ht').text());
    //
    //     $('#btn-save').css('display', 'inline-block');
    //     $('#btn-delete').css('display', 'inline-block');
    //     $('#btn-cancel').css('display', 'inline-block');
    //     $('#btn-add').css('display', 'none');
    // });
    //
    // $(document).on('click', '#btn-cancel', function (e) {
    //     $('#btn-save').css('display', 'none');
    //     $('#btn-delete').css('display', 'none');
    //     $('#btn-cancel').css('display', 'none');
    //     $('#btn-add').css('display', 'inline-block');
    //
    //     $('#primary_key').val('');
    //     $('#ma_huyen').val('');
    //     $('#ten_huyen').val('');
    //     $('#stt_ht').val('');
    // });
    // ///End: Process display function button on screen

    // /**
    //  * @Description: Add new record
    //  */
    // $(document).on('click', '#btn-add', function (e) {
    //     console.log(4444);
    //     return;
    //     var _r = confirm("Lưu dữ liệu hiện tại");
    //     if (_r) {
    //         $.ajax({
    //             url: '/danhmuc/' + _command_key + '/store',
    //             type: 'POST',
    //             loading: true,
    //             data: $("#editor-form").serialize(),
    //             success: function (res) {
    //                 if (res.status == 201) {
    //                     console.log(res.message);
    //                     var _errs = "";
    //                     let _index = 1;
    //                     $.each(res.message, function (key, value) {
    //                         _errs = _errs + _index + ". " + value[0].toString() + "\n";
    //                         _index++;
    //                     });
    //                     alert(_errs);
    //                 } else if (res.status == 200) {
    //                     alert(res.message);
    //                     location.reload(true);
    //                 } else {
    //                     alert(res.message);
    //                 }
    //             }
    //         });
    //     }
    // });

    /**
     * @Description: Submit form (Event update)
     */
    $('#editor-form').submit(function (e) {
        e.preventDefault();
        // console.log($('#primary_key').val());
        // return false;
        $.ajax({
            url: $('#editor-form').attr('action'),
            type: 'POST',
            loading: true,
            data: $("#editor-form").serialize(),
            success: function (res) {
                if (res.status == 201) {
                    console.log(res.message);
                    let _errs = "";
                    let _index = 1;
                    $.each(res.message, function (key, value) {
                        _errs = _errs + _index + ". " + value[0].toString() + "\n";
                        _index++;
                    });
                    alert(_errs);
                } else if (res.status == 200) {
                    alert(res.message);
                    location.reload(true);
                } else {
                    alert(res.message);
                }
            }
        });
        return false;
    });

    // btn-show-hide
    /**
     * @Description: Show/Hide single record
     */
    $(document).on('click', '#radioBtn a:not(.active)', function (e) {
        var _state = $(this).data('title');
        var _msg = "";
        if (_state == "Y") {
            _msg = "Hiển thị bản ghi đã chọn";
        } else {
            _msg = "Ẩn bản ghi đã chọn?";
        }
        var _r = confirm(_msg);


        if (_r) {
            var sel = $(this).data('title');
            var tog = $(this).data('toggle');
            $('#' + tog).prop('value', sel);
            var _tr = $(this).parents('tr');
            _tr.find('a[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
            _tr.find('a[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');

            var _id = $(this).data('primary_key');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/danhmuc/' + _command_key + '/show_hide/' + _state + '/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        } else {
            e.preventDefault();
            return false;
        }
    });

    /**
     * @Description: Delete single record
     */
    $(document).on('click', '.btn-delete', function (e) {
        var _r = confirm("Xóa bản ghi đã chọn?");
        if (_r) {
            var _id = $(this).data('primary_key');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/danhmuc/' + _command_key + '/delete/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    /**
     * @Description: Event search
     */
    $(document).on('click', '#btn-search', function (e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/danhmuc/' + _command_key + '/search',
            type: 'GET',
            loading: true,
            dataType: "html",
            data: $("#search-form").serialize(),
            success: function (res) {
                if (res.status == "201" || res.status == "202") {
                    alert(res.message);
                } else {
                    $('#responsive').empty();
                    $('#responsive').append(res);
                }
            }
        });
    });

    $(document).on('click', '#responsive li.page-item a.page-link', function (e) {
        e.preventDefault();
        var _page = $(this).text();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/danhmuc/' + _command_key + '/search',
            type: 'GET',
            loading: true,
            dataType: "html",
            data: $("#search-form").serialize() + "&page=" + _page,
            success: function (res) {
                if (res.status == "201" || res.status == "202") {
                    alert(res.message);
                } else {
                    $('#responsive').empty();
                    $('#responsive').append(res);
                }
            }
        });
        return false;
    });

    // btn-open-new-form
    $(document).on('click', '#btn-open-new-form', function (e) {
        $('#modal_editor').find('input.form-control').val('');
        $('#modal_editor').find('select.form-control').val('');
        $('#modal_editor').find('textarea.form-control').val('');
        $('#modal_editor').find('input#primary_key').val('');
    });
}
