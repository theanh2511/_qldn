 $(document).ready(function() {
            
              $("ul.menu_left>ul.menu_child>li").click(function(e) {
                e.preventDefault();
                $(this).addClass("active");
                $(this).siblings('li.active').removeClass("active");                
                
				var file = $(this).attr('id');
				 var url = 'Bao_cao/'+file+'.html';    
                var kiemtra = doesFileExist(url); 
                if(kiemtra ==2){
                   $( "#hienthi_bc" ).load(url );  
                 }else{
                   $( "#hienthi_bc" ).html('Đang cập nhật nội dung....');
                 }    
                //hienthi_so(giatri,1);
               // hienthi_chitietcoquan(giatri,1);
               
             });  
			  var url2 = 'Bao_cao/KHDT/dangky_thanhlap.html';    
                var kiemtra2 = doesFileExist(url2); 
                if(kiemtra2 ==2){
                   $( "#hienthi_bc" ).load(url2 );  
                 }else{
                   $( "#hienthi_bc" ).html('Đang cập nhật nội dung....');
                 }               
 })
 

function doesFileExist(urlToFile) {
 var xhr = new XMLHttpRequest();
 xhr.open('HEAD', urlToFile, false);
 xhr.send();
 if (xhr.status == "404") {
   console.log("File doesn't exist");
    return 1;
  } else {
    console.log("File exists");
    return 2;
  }
 }