$(document).ready(function(){
	$(".visi_hidden").hide();
    $("#search_nang_cao").click(function(){
        $(".visi_hidden").slideToggle("slow");
    });
});
