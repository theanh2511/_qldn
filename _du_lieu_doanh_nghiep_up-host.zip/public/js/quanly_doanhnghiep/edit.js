$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    /**
     * @Description: Submit form (Event update)
     */
    $('#editor-form').submit(function (e) {
        e.preventDefault();

        $.ajax({
            url: $('#editor-form').attr('action'),
            type: 'POST',
            loading: true,
            data: $("#editor-form").serialize(),
            success: function (res) {
                if (res.status == 201) {
                    console.log(res.message);
                    let _errs = "";
                    let _index = 1;
                    $.each(res.message, function (key, value) {
                        _errs = _errs + _index + ". " + value[0].toString() + "\n";
                        _index++;
                    });
                    alert(_errs);
                } else if (res.status == 200) {
                    alert(res.message);
                    if (res.primary_key) {
                        location.href = '/quanly_doanhnghiep/hoso_doanhnghiep/' + res.primary_key;
                    } else {
                        location.reload(true);
                    }

                } else {
                    alert(res.message);
                }
            }
        });
        return false;
    });

    $(document).on('change', 'select[name="quan_huyen"]', function (e) {
        var _ma_huyen = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/quanly_doanhnghiep/search_quan_huyen',
            type: 'POST',
            loading: true,
            data: {
                ma_huyen: _ma_huyen
            },
            success: function (res) {
                var _div_xa_phuong = $('select[name="xa_phuong"]').parent();
                _div_xa_phuong.empty();
                _div_xa_phuong.append(res);
            }
        });
    });

    $(document).on('click', '#btn-back', function (e) {
        e.preventDefault();
        if ('referrer' in document) {
            window.location.href = document.referrer;
        } else {
            window.history.back();
        }
    });
}
