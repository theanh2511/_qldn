$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    /**
     * @Description: Delete single record
     */
    $(document).on('click', 'button.btn-delete', function (e) {
        var _r = confirm("Xóa dữ liệu đã chọn?");
        if (_r) {
            var _id = $(this).data('primary_key');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/quanly_doanhnghiep/hoso_doanhnghiep/delete/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    /**
     * @Description: Gửi trình hồ sơ doanh nghiệp
     */
    $(document).on('click', 'button.btn-send-file', function (e) {
        var _r = confirm("Gửi trình hồ sơ doanh nghiệp đã chọn?");
        if (_r) {
            var _id = $(this).data('primary_key');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '/quanly_doanhnghiep/hoso_doanhnghiep/gui_trinh/' + _id,
                type: 'POST',
                loading: true,
                data: null,
                success: function (res) {
                    if (res.status == 201) {
                        console.log(res.message);
                        let _errs = "";
                        let _index = 1;
                        $.each(res.message, function (key, value) {
                            _errs = _errs + _index + ". " + value[0].toString() + "\n";
                            _index++;
                        });
                        alert(_errs);
                    } else if (res.status == 200) {
                        alert(res.message);
                        location.reload(true);
                    } else {
                        alert(res.message);
                    }
                }
            });
        }
    });

    /**
     * @Description: Gửi trình hồ sơ doanh nghiệp
     */
    $(document).on('click', 'button.btn-approve', function (e) {
        var _id = $(this).data('primary_key');

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/quanly_doanhnghiep/hoso_doanhnghiep/modal/' + _id,
            type: 'POST',
            loading: true,
            data: null,
            success: function (response) {
                $('#modal_duyet_ho_so .modal-body').html(response);
                $('#modal_duyet_ho_so').modal('show');
            }
        });

    });

    //Modal
    $(document).on('click', '#btn-cancel-modal', function (e) {
        $('#modal_duyet_ho_soal').modal('hide');
    });

    $(document).on('click', 'input[name="duyet"]:checked', function (e) {
        if ($(this).attr('value') == 1) {
            $("#hien_lydo").css('display', 'none');
        } else {
            $("#hien_lydo").css('display', 'block');
        }
    });


    /**
     * @Description: Event search
     */
    $(document).on('click', '#btn-search', function (e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/quanly_doanhnghiep/search',
            type: 'POST',
            loading: true,
            data: $("#list-form").serialize(),
            success: function (res) {
                $('#table_data tbody').empty();
                $('#table_data tbody').append(res);
            }
        });
    });

    $(document).on('change', 'select[name="quan_huyen"]', function (e) {
        var _ma_huyen = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/quanly_doanhnghiep/search_quan_huyen',
            type: 'POST',
            loading: true,
            data: {
                ma_huyen: _ma_huyen
            },
            success: function (res) {
                var _div_xa_phuong = $('select[name="xa_phuong"]').parent();
                _div_xa_phuong.empty();
                _div_xa_phuong.append(res);
            }
        });
    });

    // event btn-import-excel click: Import excel
    $(document).on('click', '#btn-import-excel', function (e) {
        $('#select_excel_file').click();
    });

    $(document).on('change', '#select_excel_file', function (event) {
        var file_data = $(this).prop('files')[0];
        var form_data = new FormData();
        form_data.append('file', file_data);
        form_data.append('_token', $('[name="csrf-token"]').attr('content'));
        if (typeof file_data == "undefined") {
            return;
        } else {
            var _r = confirm("Import dữ liệu Hồ sơ doanh nghiệp?");
            if (_r) {
                $.ajax({
                    url: '/quanly_doanhnghiep/hoso_doanhnghiep/import_excel',
                    type: 'POST',
                    loading: true,
                    data: form_data,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if (res.status = "200") {
                            alert(res.message);
                            location.reload(true);
                        } else {
                            alert("Error: " + res.message);
                        }
                    }
                });
            }
        }
    });
}
