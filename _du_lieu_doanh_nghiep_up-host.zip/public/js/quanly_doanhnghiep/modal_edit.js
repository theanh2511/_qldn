$(document).ready(function () {
    "use strict";

    initEvents();
});

function initEvents() {
    /**
     * @Description: Submit form (Event update)
     */
    $(document).on('click', '#btn-save-modal', function (e) {
        var _id = $('#primary_key').val();
        var data = {};
        data.trang_thai = 2;
        data.ly_do = $('#ly_do').val();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/quanly_doanhnghiep/hoso_doanhnghiep/duyet_hoso/' + _id,
            type: 'POST',
            loading: true,
            data: data,
            success: function (response) {
                location.reload(true);
            }
        });

    });

}
