<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMNganhngheKinhdoanhTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('m_nganhnghe_kinhdoanh', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('ma_nn', 32)->unique();
            $table->string('ten_nn', 256);
            $table->integer('stt_ht')->nullable();

            $table->integer('created_by')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('m_nganhnghe_kinhdoanh');
    }
}
