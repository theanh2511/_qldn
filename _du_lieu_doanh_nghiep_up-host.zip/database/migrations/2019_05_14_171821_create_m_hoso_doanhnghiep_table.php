<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMHosoDoanhnghiepTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('m_hoso_doanhnghiep', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('maso_dn', 32)->unique();
            $table->string('ten_dn', 256);
            $table->string('diachi', 512)->nullable();
            $table->string('quan_huyen', 32)->nullable();
            $table->string('xa_phuong', 32)->nullable();
            $table->decimal('von_dl', 18, 2)->default('0');
            $table->string('trang_thai', 32)->nullable();
            $table->string('tel', 100)->nullable();
            $table->string('mobile', 32)->nullable();
            $table->string('fax', 32)->nullable();
            $table->string('email', 100)->nullable();
            $table->string('nguoi_daidien', 128)->nullable();
            $table->date('ngay_sinh_ndd')->nullable();
            $table->string('cmt_hochieu', 32)->nullable();
            $table->date('ngaycap_cmt')->nullable();
            $table->string('noi_cap', 128)->nullable();
            $table->string('so_huu', 128)->nullable();
            $table->string('kinhdoanh_chinh', 512)->nullable();
            $table->string('nganh_nghe', 512)->nullable();
            $table->date('ngay_cap')->nullable();
            $table->date('ngay_thay_doi')->nullable();
            $table->string('loai_hinh', 32)->nullable();
            $table->integer('so_laodong')->nullable();
            $table->string('ds_thanhvien', 512)->nullable();
            $table->string('ds_codong', 512)->nullable();
            $table->string('loai_dn', 32)->nullable();
            $table->integer('trang_thai_duyet')->nullable();
            $table->date('ngay_gui_trinh')->nullable();
            $table->date('ngay_duyet')->nullable();
            $table->string('ly_do', 1000)->nullable();

            $table->integer('created_by')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('m_hoso_doanhnghiep');
    }
}
