<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFHosoBaohiemTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('f_hoso_baohiem', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('maso_dn', 32)->unique();
            $table->string('ten_dn', 256);
            $table->string('maso_thue', 32);
            $table->string('diachi_dangkykinhdoanh', 512)->nullable();
            $table->string('diachi_giaodich', 512)->nullable();
            $table->string('loai_hinh', 32)->nullable();
            $table->string('tel', 100)->nullable();
            $table->string('email', 100)->nullable();
            $table->string('giayphep_dangkykinhdoanh', 100)->nullable();
            $table->string('noicap_dangkykinhdoanh', 512)->nullable();
            $table->string('phuongthuc_dong', 100)->nullable();
            $table->string('noidung_thaydoi', 512)->nullable();
            $table->string('id_hoso_dinhkem', 512)->nullable();

            $table->integer('created_by')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('f_hoso_baohiem');
    }
}
