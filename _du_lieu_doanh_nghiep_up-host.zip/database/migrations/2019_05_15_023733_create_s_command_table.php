<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSCommandTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('s_command', function (Blueprint $table) {
            $table->string('command_key', 32)->unique();
            $table->string('form_name', 256);
            $table->string('form_name_en', 256)->nullable();
            $table->string('class_name', 32)->nullable();
            $table->string('ctor_arg1', 64);
            $table->string('ctor_arg2', 64)->nullable();
            $table->string('ctor_args', 256)->nullable();
            $table->integer('stt_ht')->nullable();

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('s_command');
    }
}
