<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFHosoThueTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('f_hoso_thue', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('maso_dn', 32)->unique();
            $table->string('ten_dn', 256);
            $table->string('trang_thai', 32)->nullable();
            $table->date('ngay_cap_nhat')->nullable();
            $table->date('ngay_dang_ky')->nullable();
            $table->string('ma_cq_thue', 50)->nullable();
            $table->string('ten_tep', 256)->nullable();
            $table->string('phuongphap_nopthue', 256)->nullable();
            $table->string('ma_cap', 50)->nullable();
            $table->string('ma_chuong', 50)->nullable();
            $table->string('ma_loai', 50)->nullable();
            $table->string('ma_khoan', 50)->nullable();

            $table->string('ten_giaodich', 100)->nullable();
            $table->string('diachi_truso', 512)->nullable();
            $table->string('ma_tinh_truso', 32)->nullable();
            $table->string('ma_huyen_truso', 32)->nullable();
            $table->string('tel', 100)->nullable();
            $table->string('fax', 32)->nullable();
            $table->string('email', 100)->nullable();
            $table->string('email_giaodich_thue', 100)->nullable();

            $table->string('diachi_nhanthongbao', 512)->nullable();
            $table->string('ma_tinh_nhanthongbao', 32)->nullable();
            $table->string('ma_huyen_nhanthongbao', 32)->nullable();
            $table->string('email_nhanthongbao', 100)->nullable();
            $table->string('tel_nhanthongbao', 100)->nullable();
            $table->string('fax_nhanthongbao', 32)->nullable();

            $table->string('nguoi_daidien', 128)->nullable();
            $table->string('diachi_chudoanhnghiep', 512)->nullable();
            $table->string('ma_tinh_chudoanhnghiep', 32)->nullable();
            $table->string('ma_huyen_chudoanhnghiep', 32)->nullable();

            $table->string('so_quyetdinh', 50)->nullable();
            $table->date('ngay_quyetdinh')->nullable();
            $table->string('cq_quyetdinh', 128)->nullable();
            $table->string('so_giayphep_dkkd', 50)->nullable();
            $table->date('ngaycap_giayphep_dkkd')->nullable();
            $table->string('cq_cap_giapphep_dkkd', 128)->nullable();
            $table->string('ma_tinh_cu', 32)->nullable();
            $table->string('ma_tin_cu', 50)->nullable();
            $table->date('ngay_hoatdong')->nullable();
            $table->decimal('von_pd', 18, 2)->default('0');
            $table->string('loaitien_von_pd', 32)->nullable();
            $table->decimal('von_dl', 18, 2)->default('0');
            $table->string('loaitien_von_dl', 32)->nullable();
            $table->integer('so_laodong')->nullable();
            $table->string('tk_khobac', 50)->nullable();
            $table->string('ma_kb', 32)->nullable();
            $table->string('sohieu_tknh', 50)->nullable();
            $table->string('ngan_hang', 100)->nullable();
            $table->string('thanhphan_kinhte', 100)->nullable();
            $table->string('loaihinh_kinhte', 100)->nullable();
            $table->date('ngay_batdau_namtc')->nullable();
            $table->date('ngay_ketthuc_namtc')->nullable();

            $table->string('maso_thue_ctyme', 32)->nullable();
            $table->string('diachi_ctyme', 512)->nullable();
            $table->string('ma_tinh_ctyme', 32)->nullable();
            $table->string('ma_huyen_ctyme', 50)->nullable();
            $table->string('hinhthuc_hachtoan', 32)->nullable();
            $table->string('thanhvien', 100)->nullable();
            $table->string('cuahang_tructhuoc', 200)->nullable();
            $table->string('chi_nhanh', 200)->nullable();
            $table->string('ten_giamdoc', 50)->nullable();
            $table->string('diachi_giamdoc', 512)->nullable();
            $table->string('ma_tinh_giamdoc', 32)->nullable();
            $table->string('ma_huyen_giamdoc', 50)->nullable();
            $table->string('ten_ktt', 50)->nullable();
            $table->string('diachi_ktt', 512)->nullable();
            $table->string('ma_tinh_ktt', 32)->nullable();
            $table->string('ma_huyen_ktt', 50)->nullable();
            $table->date('ngay_dongcua')->nullable();
            $table->string('lydo_dongcua', 512)->nullable();
            $table->date('ngay_khoiphuc')->nullable();
            $table->string('lydo_khoiphuc', 512)->nullable();
            $table->date('ngay_batdau_tamdung')->nullable();
            $table->date('ngay_ketthuc_tamdung')->nullable();
            $table->string('loai_maso', 50)->nullable();
            $table->string('lydo_tamdung', 512)->nullable();


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('f_hoso_thue');
    }
}
