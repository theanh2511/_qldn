<?php

use Illuminate\Database\Seeder;
use App\Models\SCommand;

class SCommandSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $command_arrs = [];

        $command_arrs[] = [
            'command_key' => 'diagioi_caphuyen',
            'form_name' => 'Quản lý địa giới cấp huyện',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_diagioi_caphuyen',
            'stt_ht' => 1
        ];
        $command_arrs[] = [
            'command_key' => 'diagioi_capxa',
            'form_name' => 'Quản lý địa giới cấp xã',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_diagioi_capxa',
            'stt_ht' => 2
        ];
        $command_arrs[] = [
            'command_key' => 'loaihinh_doanhnghiep',
            'form_name' => 'Quản lý loại hình doanh nghiệp',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_loaihinh_doanhnghiep',
            'stt_ht' => 3
        ];
        $command_arrs[] = [
            'command_key' => 'trangthai_doanhnghiep',
            'form_name' => 'Quản lý trạng thái doanh nghiệp',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_trangthai_doanhnghiep',
            'stt_ht' => 4
        ];
        $command_arrs[] = [
            'command_key' => 'quoctich',
            'form_name' => 'Quản lý danh mục quốc tịch',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_quoctich',
            'stt_ht' => 5
        ];
        $command_arrs[] = [
            'command_key' => 'dantoc',
            'form_name' => 'Quản lý danh mục dân tộc',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_dantoc',
            'stt_ht' => 6
        ];
        $command_arrs[] = [
            'command_key' => 'nganhnghe_kinhdoanh',
            'form_name' => 'Quản lý ngành nghề kinh doanh',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_nganhnghe_kinhdoanh',
            'stt_ht' => 7
        ];
        $command_arrs[] = [
            'command_key' => 'hoso_doanhnghiep',
            'form_name' => 'Tạo mới hồ sơ doanh nghiệp',
            'class_name' => 'Editor',
            'ctor_arg1' => 'm_hoso_doanhnghiep',
            'stt_ht' => 8
        ];


        SCommand::insert($command_arrs);
    }
}
