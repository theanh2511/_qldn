<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    return redirect('/index');
});

Route::get('/index', function () {

    return view('index');
});

Route::group([
    'namespace' => '\App\Http\Controllers\DoanhNghiep',
    'prefix' => 'danhmuc',
//    'middleware' => 'auth'
], function () {
    Route::get('/{command_key}/search', 'DanhMucController@search');
    Route::get('/{command_key}', 'DanhMucController@edit');
    Route::post('/{command_key}/update', 'DanhMucController@update');
    Route::post('/{command_key}/store', 'DanhMucController@store');
    Route::post('/{command_key}/delete/{id}', 'DanhMucController@delete');
    Route::post('/{command_key}/show_hide/{state}/{id}', 'DanhMucController@hideItem');
});

Route::group([
    'namespace' => '\App\Http\Controllers\DoanhNghiep',
    'prefix' => 'quanly_doanhnghiep',
//    'middleware' => 'auth'
], function () {
//    Functions
    Route::get('/hoso_doanhnghiep/{id?}', 'QuanLyDoanhNghiepController@edit');
    Route::post('/hoso_doanhnghiep/update/{id?}', 'QuanLyDoanhNghiepController@update');
    Route::post('/hoso_doanhnghiep/delete/{id?}', 'QuanLyDoanhNghiepController@delete');
    Route::post('/hoso_doanhnghiep/gui_trinh/{id?}', 'QuanLyDoanhNghiepController@gui_trinh');
    Route::post('/hoso_doanhnghiep/duyet_hoso/{id?}', 'QuanLyDoanhNghiepController@duyetHoSo');
    Route::post('/hoso_doanhnghiep/modal/{id?}', 'QuanLyDoanhNghiepController@modal');

    //import excel
    Route::post('/hoso_doanhnghiep/import_excel', 'QuanLyDoanhNghiepController@importExcel');

//    Lists
    Route::get('/danhsach_moitao', 'QuanLyDoanhNghiepController@dsMoiTao');
    Route::get('/danhsach_choduyet', 'QuanLyDoanhNghiepController@dsChoDuyet');
    Route::get('/danhsach_guilai', 'QuanLyDoanhNghiepController@dsKhongDuyet');
    Route::get('/danhsach_daduyet', 'QuanLyDoanhNghiepController@dsDaDuyet');
    Route::get('/{command_key}/search', 'QuanLyDoanhNghiepController@search');
    Route::post('/search_quan_huyen', 'QuanLyDoanhNghiepController@searchQuanHuyen');
});

Route::group([
    'namespace' => '\App\Http\Controllers\BaoHiem',
    'prefix' => 'quanly_baohiem',
//    'middleware' => 'auth'
], function () {
    //*****FUNCTIONS
    //Bảo hiểm doanh nghiệp
    Route::get('/hoso_baohiem_dn/{id?}', 'QuanLyBaoHiemController@edit');
    Route::post('/hoso_baohiem_dn/update/{id?}', 'QuanLyBaoHiemController@update');
    Route::post('/hoso_baohiem_dn/delete/{id?}', 'QuanLyBaoHiemController@delete');
    Route::post('/hoso_baohiem_dn/gui_trinh/{id?}', 'QuanLyBaoHiemController@gui_trinh');
    Route::post('/hoso_baohiem_dn/duyet_hoso/{id?}', 'QuanLyBaoHiemController@approve');
    Route::post('/hoso_baohiem_dn/modal/{id?}', 'QuanLyBaoHiemController@modal');

    //Bảo hiểm cá nhân
    Route::get('/nguoichuacapbhxh/{id?}', 'BaoHiemCaNhanController@edit');
    Route::post('/nguoichuacapbhxh/update/{id?}', 'BaoHiemCaNhanController@update');
    Route::get('/nguoidacapbhxh/{id?}', 'BaoHiemCaNhanController@editDaCapBHXH');
    Route::post('/nguoidacapbhxh/update/{id?}', 'BaoHiemCaNhanController@updateDaCapBHXH');
    Route::post('/duyetcapbhxh/{id?}', 'BaoHiemCaNhanController@approveBHXH');
    Route::post('/bhxh_cn/delete/{id?}', 'BaoHiemCaNhanController@delete');

    //***** LISTS
    //Bảo hiểm doanh nghiệp
    Route::get('/danhsach_thamgiabhxh', 'QuanLyBaoHiemController@dsMoiDuyet');
    Route::get('/danhsach_choduyet', 'QuanLyBaoHiemController@dsChoDuyet');
    Route::get('/danhsach_guilai', 'QuanLyBaoHiemController@dsKhongDuyet');
    Route::get('/danhsach_daduyet', 'QuanLyBaoHiemController@dsDaDuyet');
    Route::get('/search', 'QuanLyBaoHiemController@search');
    Route::post('/search_quan_huyen', 'QuanLyBaoHiemController@searchQuanHuyen');

    //Bảo hiểm cá nhân
    Route::get('/dsnguoichuaduoccapbhxh', 'BaoHiemCaNhanController@dsnguoichuaduoccapbhxh');
    Route::get('/dsnguoidaduoccapbhxh', 'BaoHiemCaNhanController@dsnguoidaduoccapbhxh');
    Route::get('/ds_bhxh/search', 'BaoHiemCaNhanController@search');
});