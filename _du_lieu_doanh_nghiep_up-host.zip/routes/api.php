<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group([
    'namespace' => '\App\Http\Controllers\DoanhNghiep',
], function () {
    Route::get('db_info', 'DanhMucApiController@getDatabaseInformation');
});

Route::group([
    'namespace' => '\App\Http\Controllers\DoanhNghiep',
    'prefix' => 'danh_muc',
], function () {
    Route::any('{command_key}', 'DanhMucApiController@getAll');
    Route::any('{command_key}/search', 'DanhMucApiController@search');
    Route::any('{command_key}/edit/{id}', 'DanhMucApiController@index');
    Route::post('{command_key}/update/{id}', 'DanhMucApiController@update');
    Route::post('{command_key}/store', 'DanhMucApiController@store');
    Route::post('{command_key}/delete/{id}', 'DanhMucApiController@delete');
});

Route::group([
    'namespace' => '\App\Http\Controllers\DoanhNghiep',
    'prefix' => 'quanly_doanhnghiep',
], function () {
    Route::any('hoso_doanhnghiep', 'DanhMucApiController@getAllHoSoDoanhNghiep');
    Route::any('hoso_doanhnghiep/edit/{id}', 'DanhMucApiController@indexHoSoDoanhNghiep');
    Route::any('hoso_doanhnghiep/delete/{id}', 'DanhMucApiController@deleteHoSoDoanhNghiep');
    Route::any('hoso_doanhnghiep/search', 'DanhMucApiController@searchHoSoDoanhNghiep');
    Route::post('hoso_doanhnghiep/update/{id}', 'DanhMucApiController@updateHoSoDoanhNghiep');
    Route::post('hoso_doanhnghiep/approve', 'DanhMucApiController@updateTrangThaiDuyet');
    Route::post('hoso_doanhnghiep/store', 'DanhMucApiController@storeHoSoDoanhNghiep');
    Route::post('hoso_doanhnghiep/get/maso_dn', 'DanhMucApiController@getMaSoDN');
});
