<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class HoSoDoanhNghiep extends Model
{
    use SoftDeletes;
    protected $table = 'm_hoso_doanhnghiep';
    public $incrementing = true;

    protected $fillable = [
        'maso_dn',
        'ten_dn',
        'diachi',
        'quan_huyen',
        'xa_phuong',
        'von_dl',
        'trang_thai',
        'tel',
        'mobile',
        'fax',
        'email',
        'nguoi_daidien',
        'ngay_sinh_ndd',
        'cmt_hochieu',
        'ngaycap_cmt',
        'noi_cap',
        'so_huu',
        'kinhdoanh_chinh',
        'nganh_nghe',
        'ngay_cap',
        'ngay_thay_doi',
        'loai_hinh',
        'so_laodong',
        'ds_thanhvien',
        'ds_codong',
        'loai_dn',
        'trang_thai_duyet',
        'ngay_gui_trinh',
        'ngay_duyet',
        'ly_do',
        'created_by',
        'updated_by',
    ];

    protected $hidden = [
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
        'ngaycap_cmt',
        'ngay_sinh_ndd',
        'ngay_cap',
        'ngay_thay_doi'
    ];

//    protected $dateFormat = 'U';

    public $list_of_status = [
        0 => "Đang hoạt động",
        1 => "Dừng hoạt động"
    ];

    public $list_of_types = [
        "TN" => "Trong nước",
        "FDI" => "Doanh nghiệp FDI"
    ];

    public $list_of_approval = [
        1 => "Chờ duyệt",
        2 => "Không duyệt, gửi lại",
        3 => "Đã duyệt"
    ];

    public function getListOfStatus()
    {
        $trang_thai_dn = DB::table("m_trangthai_doanhnghiep")
            ->select("ma_tt", "ten_tt")
            ->get()->toArray();
        $list_of_status = [];
        foreach ($trang_thai_dn as $key => $value) {
            $list_of_status[$value->ma_tt] = $value->ten_tt ?? "";
        }
        return $list_of_status;
    }

    public function getNgaycapCmtAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setNgaycapCmtAttribute($value)
    {
        $this->attributes['ngaycap_cmt'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function getNgaySinhNddAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setNgaySinhNddAttribute($value)
    {
        $this->attributes['ngay_sinh_ndd'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function getNgayCapAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setNgayCapAttribute($value)
    {
        $this->attributes['ngay_cap'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function getNgayThayDoiAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setNgayThayDoiAttribute($value)
    {
        $this->attributes['ngay_thay_doi'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function setVonDlAttribute($value)
    {
        $this->attributes['von_dl'] = $value ? (float)(str_replace(",", "", $value)) : 0;
    }

    public function hsdn_logs()
    {
        return $this->hasMany(SLogs::class, 'maso_dn', 'maso_dn')->orderBy('modify_date', 'desc');
    }

    public function bindingOtherInformations()
    {
        $trang_thai_dn = DB::table("m_trangthai_doanhnghiep")
                ->where("ma_tt", "=", $this->trang_thai)
                ->select("ten_tt")
                ->first()->ten_tt ?? "";

        $this->ten_trang_thai = $trang_thai_dn;

        $loaihinh_dn = DB::table("m_loaihinh_doanhnghiep")
                ->where("ma_lh", "=", $this->loai_hinh)
                ->select("ten_lh")
                ->first()->ten_lh ?? "";
        $this->ten_lh = $loaihinh_dn;

        $ten_xa = DB::table("m_diagioi_capxa")
                ->where("ma_xa", "=", $this->xa_phuong)
                ->select("ten_xa")
                ->first()->ten_xa ?? "";
        $this->ten_xa = $ten_xa;

        $ten_huyen = DB::table("m_diagioi_caphuyen")
                ->where("ma_huyen", "=", $this->quan_huyen)
                ->select("ten_huyen")
                ->first()->ten_huyen ?? "";
        return $this->ten_huyen = $ten_huyen;
    }
}
