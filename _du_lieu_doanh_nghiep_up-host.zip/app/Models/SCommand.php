<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SCommand extends Model
{
    protected $table = 's_command';
    public $incrementing = false;

    protected $fillable = [
        'command_key',
        'form_name',
        'form_name_en',
        'class_name',
        'ctor_arg1',
        'ctor_arg2',
        'ctor_args',
        'stt_ht'
    ];
}
