<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class HoSoBaoHiem extends Model
{
    use SoftDeletes;
    protected $table = 'f_hoso_baohiem';
    public $incrementing = true;

    protected $fillable = [
        "maso_dn",
        "ten_dn",
        "maso_thue",
        "diachi_dangkykinhdoanh",
        "diachi_giaodich",
        "loai_hinh",
        "tel",
        "email",
        "giayphep_dangkykinhdoanh",
        "noicap_dangkykinhdoanh",
        "phuongthuc_dong",
        "noidung_thaydoi",
        "id_hoso_dinhkem",
        "trang_thai",
        "ngay_duyet",
        "nguoi_duyet",
        "ghichu",
        "created_by",
        "updated_by",
    ];

    protected $hidden = [
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
        'ngay_duyet',
    ];

    public function getNgayDuyetAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setNgayDuyetAttribute($value)
    {
        $this->attributes['ngay_duyet'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function bindingOtherInformations()
    {
        $ten_loai_hinh = DB::table("m_loaihinh_doanhnghiep")
                ->where("ma_lh", "=", $this->loai_hinh)
                ->select("ten_lh")
                ->first()->ten_lh ?? "";
        return $this->ten_loai_hinh = $ten_loai_hinh;
    }

    public function getDanhSachCaNhanBHXH()
    {
        $ds_thamgia_bhxh = DB::table("f_hoso_baohiem_cn")
            ->where("maso_dn", "=", $this->maso_dn)
            ->select("maso_bhxh", "ten_ca_nhan", "ngaycap_bhxh")
            ->get();

        return $ds_thamgia_bhxh;
    }
}
