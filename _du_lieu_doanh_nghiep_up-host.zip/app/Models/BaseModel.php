<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class BaseModel extends Model
{
    public $incrementing = true;

    public static function boot()
    {
        parent::boot();

//        static::creating(function ($model) {
//            if (empty($model->{$model->getKeyName()})) {
//                $model->{$model->getKeyName()} = Str::uuid()->toString();
//            }
//        });
    }

    public function getLink()
    {
        $path = explode('\\', static::class);
        $class = array_pop($path);
        return url('admin/' . strtolower($class), $this->getKey());
    }
}
