<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class SLogs extends Model
{
    use SoftDeletes;
    protected $table = 's_logs';
    public $incrementing = true;
    public $timestamps = true;

    protected $fillable = [
        "field_name",
        "old_value",
        "new_value",
        "modify_date",
        "modify_content",
        "department",
        "status",
        "approved_by",
        "approved_date",
        "description",
        "created_by",
        "updated_by",
    ];

    protected $hidden = [
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
        'modify_date',
        'approved_date',
    ];

    public $list_of_status = [
        1 => "Chờ duyệt",
        2 => "Đã duyệt"
    ];

    public function getModifyDateAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setModifyDateAttribute($value)
    {
        $this->attributes['modify_date'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function getApprovedDateAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setApprovedDateAttribute($value)
    {
        $this->attributes['approved_date'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

//    public function bindingOtherInformations()
//    {
//        $this->gender_name = $this->list_of_gender[$this->gioi_tinh ?? 0];
//
//        $ten_dn = DB::table("m_hoso_doanhnghiep")
//                ->where("maso_dn", "=", $this->maso_dn)
//                ->select("ten_dn")
//                ->first()->ten_dn ?? "";
//        return $this->ten_dn = $ten_dn;
//    }
}
