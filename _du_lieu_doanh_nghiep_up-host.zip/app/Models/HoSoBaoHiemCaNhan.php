<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class HoSoBaoHiemCaNhan extends Model
{
    use SoftDeletes;
    protected $table = 'f_hoso_baohiem_cn';
    public $incrementing = true;

    protected $fillable = [
        "maso_dn",
        "maso_bhxh",
        "ten_ca_nhan",
        "ngay_sinh",
        "gioi_tinh",
        "dangky_khaisinh",
        "diachi",
        "so_cmt",
        "quoc_tich",
        "dan_toc",
        "tel",
        "email",
        "nguoi_giam_ho",
        "muc_tien_dong",
        "phuongthuc_dong",
        "ghichu",
        "trang_thai",
        "created_by",
        "updated_by",
    ];

    protected $hidden = [
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
        'ngay_sinh',
    ];

    public $list_of_gender = [
        0 => "Nữ",
        1 => "Nam"
    ];

    public $list_of_status = [
        0 => "Chưa tham gia",
        1 => "Đã cấp"
    ];

    public function getNgaySinhAttribute($value)
    {
        return $value ? Carbon::parse($value)->toDateString() : null;
    }

    public function setNgaySinhhAttribute($value)
    {
        $this->attributes['ngay_sinh'] = $value ? Carbon::createFromFormat('d/m/Y', $value)->format("Y-m-d") : null;
    }

    public function getMucTienDongAttribute($value)
    {
        return $value ? number_format($value) : 0;
    }

    public function setMucTienDongAttribute($value)
    {
        $this->attributes['muc_tien_dong'] = $value ? (float)(str_replace(",", "", $value)) : 0;
    }

    public function bindingOtherInformations()
    {
        $this->gender_name = $this->list_of_gender[$this->gioi_tinh ?? 0];

        $ten_dn = DB::table("m_hoso_doanhnghiep")
                ->where("maso_dn", "=", $this->maso_dn)
                ->select("ten_dn")
                ->first()->ten_dn ?? "";
        return $this->ten_dn = $ten_dn;
    }
}
