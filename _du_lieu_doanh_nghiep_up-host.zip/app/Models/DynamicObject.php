<?php

namespace App\Models;

use App\Traits\BindsDynamically;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class DynamicObject extends BaseModel
{
    protected $guarded = [];
    public $incrementing = true;

    protected $hidden = [
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    use BindsDynamically, SoftDeletes;

    public $error_messages = [
        'ma_xa.required' => 'Mã không được bỏ trống giá trị',
        'ma_xa.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_xa.required' => 'Tên không được bỏ trống giá trị',
        'ten_xa.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_huyen.required' => 'Mã huyện không được bỏ trống giá trị',
        'ma_huyen.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_huyen.required' => 'Tên huyện không được bỏ trống giá trị',
        'ten_huyen.unique' => 'Đã tồn tại tên huyện tương tự trong cơ sở dữ liệu',

        'ma_dt.required' => 'Mã không được bỏ trống giá trị',
        'ma_dt.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_dt.required' => 'Tên không được bỏ trống giá trị',
        'ten_dt.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_qt.required' => 'Mã không được bỏ trống giá trị',
        'ma_qt.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_qt.required' => 'Tên không được bỏ trống giá trị',
        'ten_qt.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_tt.required' => 'Mã không được bỏ trống giá trị',
        'ma_tt.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_tt.required' => 'Tên không được bỏ trống giá trị',
        'ten_tt.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_nn.required' => 'Mã không được bỏ trống giá trị',
        'ma_nn.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_nn.required' => 'Tên không được bỏ trống giá trị',
        'ten_nn.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_lh.required' => 'Mã không được bỏ trống giá trị',
        'ma_lh.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_lh.required' => 'Tên không được bỏ trống giá trị',
        'ten_lh.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'maloai_vanban.required' => 'Mã loại văn bản không được bỏ trống giá trị',
        'maloai_vanban.unique' => 'Đã tồn tại mã loại văn bản tương tự trong cơ sở dữ liệu',
        'tenloai_vanban.required' => 'Tên loại văn bản không được bỏ trống giá trị',
        'tenloai_vanban.unique' => 'Đã tồn tại tên loại văn bản tương tự trong cơ sở dữ liệu',

        'ma_chuc_danh.required' => 'Mã chức danh không được bỏ trống giá trị',
        'ma_chuc_danh.unique' => 'Đã tồn tại mã chức danh tương tự trong cơ sở dữ liệu',
        'ten_chuc_danh.required' => 'Tên chức danh không được bỏ trống giá trị',
        'ten_chuc_danh.unique' => 'Đã tồn tại tên chức danh tương tự trong cơ sở dữ liệu',

        'maloai_giayto.required' => 'Mã không được bỏ trống giá trị',
        'maloai_giayto.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'tenloai_giayto.required' => 'Tên không được bỏ trống giá trị',
        'tenloai_giayto.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_hinhthuc.required' => 'Mã không được bỏ trống giá trị',
        'ma_hinhthuc.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_hinhthuc.required' => 'Tên không được bỏ trống giá trị',
        'ten_hinhthuc.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_kb.required' => 'Mã không được bỏ trống giá trị',
        'ma_kb.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_kb.required' => 'Tên không được bỏ trống giá trị',
        'ten_kb.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',

        'ma_loaithue.required' => 'Mã không được bỏ trống giá trị',
        'ma_loaithue.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
        'ten_loaithue.required' => 'Tên không được bỏ trống giá trị',
        'ten_loaithue.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',
    ];

//    public $validate_fields = [
//        'm_diagioi_caphuyen' => [
//            'ma_huyen' => 'required|unique:m_diagioi_caphuyen,ma_huyen,',
//            'ten_huyen' => 'required|unique:m_diagioi_caphuyen,ten_huyen,',
//        ],
//
//        'm_diagioi_capxa' => [
//            'ma_xa' => 'required|unique:m_diagioi_capxa,ma_xa,',
//            'ten_xa' => 'required|unique:m_diagioi_capxa,ten_xa,',
//            'ma_huyen' => 'required',
//        ],
//    ];

    public function _validate_fields($id)
    {
        $arr_validates = array(
            'm_diagioi_caphuyen' => [
                'ma_huyen' => 'required|unique:m_diagioi_caphuyen,ma_huyen,' . $id,
                'ten_huyen' => 'required|unique:m_diagioi_caphuyen,ten_huyen,' . $id,
            ],

            'm_diagioi_capxa' => [
                'ma_xa' => 'required|unique:m_diagioi_capxa,ma_xa,' . $id,
                'ten_xa' => 'required|unique:m_diagioi_capxa,ten_xa,' . $id,
                'ma_huyen' => 'required',
            ],

            'm_dantoc' => [
                'ma_dt' => 'required|unique:m_dantoc,ma_dt,' . $id,
                'ten_dt' => 'required|unique:m_dantoc,ten_dt,' . $id,
            ],

            'm_loaihinh_doanhnghiep' => [
                'ma_lh' => 'required|unique:m_loaihinh_doanhnghiep,ma_lh,' . $id,
                'ten_lh' => 'required|unique:m_loaihinh_doanhnghiep,ten_lh,' . $id,
            ],

            'm_nganhnghe_kinhdoanh' => [
                'ma_nn' => 'required|unique:m_nganhnghe_kinhdoanh,ma_nn,' . $id,
                'ten_nn' => 'required|unique:m_nganhnghe_kinhdoanh,ten_nn,' . $id,
            ],

            'm_quoctich' => [
                'ma_qt' => 'required|unique:m_quoctich,ma_qt,' . $id,
                'ten_qt' => 'required|unique:m_quoctich,ten_qt,' . $id,
            ],

            'm_trangthai_doanhnghiep' => [
                'ma_tt' => 'required|unique:m_trangthai_doanhnghiep,ma_tt,' . $id,
                'ten_tt' => 'required|unique:m_trangthai_doanhnghiep,ten_tt,' . $id,
            ],

            'm_phanloai_vanban' => [
                'maloai_vanban' => 'required|unique:m_phanloai_vanban,maloai_vanban,' . $id,
                'tenloai_vanban' => 'required|unique:m_phanloai_vanban,tenloai_vanban,' . $id,
            ],

            'm_chucdanh' => [
                'ma_chuc_danh' => 'required|unique:m_chucdanh,ma_chuc_danh,' . $id,
                'ten_chuc_danh' => 'required|unique:m_chucdanh,ten_chuc_danh,' . $id,
            ],

            'm_giayto_tuythan' => [
                'maloai_giayto' => 'required|unique:m_giayto_tuythan,maloai_giayto,' . $id,
                'tenloai_giayto' => 'required|unique:m_giayto_tuythan,tenloai_giayto,' . $id,
            ],

            'm_hinhthuc_hachtoan' => [
                'ma_hinhthuc' => 'required|unique:m_hinhthuc_hachtoan,ma_hinhthuc,' . $id,
                'ten_hinhthuc' => 'required|unique:m_hinhthuc_hachtoan,ten_hinhthuc,' . $id,
            ],

            'm_khobac' => [
                'ma_kb' => 'required|unique:m_khobac,ma_kb,' . $id,
                'ten_kb' => 'required|unique:m_khobac,ten_kb,' . $id,
            ],

            'm_loaithue' => [
                'ma_loaithue' => 'required|unique:m_loaithue,ma_loaithue,' . $id,
                'ten_loaithue' => 'required|unique:m_loaithue,ten_loaithue,' . $id,
            ],
        );

        return $arr_validates;
    }


}
