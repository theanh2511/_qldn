<?php


use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Session;

//use Config;


/*
 * Add timestamp version
 */
if (!function_exists('file_cached')) {
    function file_cached($path, $bustQuery = false)
    {
        // Get the full path to the file.
        $realPath = public_path($path);

        if (!file_exists($realPath)) {
            throw new \LogicException("File not found at [{$realPath}]");
        }

        // Get the last updated timestamp of the file.
        $timestamp = filemtime($realPath);

        if (!$bustQuery) {
            // Get the extension of the file.
            $extension = pathinfo($realPath, PATHINFO_EXTENSION);

            // Strip the extension off of the path.
            $stripped = substr($path, 0, -(strlen($extension) + 1));

            // Put the timestamp between the filename and the extension.
            $path = implode('.', array($stripped, $timestamp, $extension));
        } else {
            // Append the timestamp to the path as a query string.
            $path .= '?v=' . $timestamp;
        }

        return asset($path);
    }
}

/*
 * Call url file
 */
if (!function_exists('public_url')) {
    function public_url($url, $attributes = null)
    {
        if (file_exists($url)) {
            $attr = '';
            if (!empty($attributes) && is_array($attributes)) {
                foreach ($attributes as $key => $val) {
                    $attr .= $key . '="' . $val . '" ';
                }
            }
            $attr = rtrim($attr);
            if (ends_with($url, '.css')) {
                return '<link rel="stylesheet" href="' . file_cached($url, true) . '" type="text/css" ' . $attr . '>';
            } elseif (ends_with($url, '.js')) {
                return '<script src="' . file_cached($url, true) . '" type="text/javascript" charset="utf-8" ' . $attr . '></script>';
            } else {
                return asset($url);
            }
        }
        $console = 'File:[' . $url . '] not found';
        return "<script>console.log('" . $console . "')</script>";
    }
}