<?php

namespace App\Http\Controllers\DoanhNghiep;

use App\Models\DynamicObject;
use App\Models\HoSoDoanhNghiep;
use App\Models\SCommand;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class DanhMucApiController extends Controller
{
    public function getAll($command_key)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $ctor_args = $s_command->ctor_args ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();

                if ($ctor_args != "") {
                    foreach (explode(";", $ctor_args) as $item_where) {
                        $item_where_detail = explode("|", $item_where);
                        if (!empty($item_where_detail[0]) && !empty($item_where_detail[1]) && !empty($item_where_detail[2])) {
                            $query->where($item_where_detail[0], $item_where_detail[1], $item_where_detail[2]);
                        }
                    }
                }

//                dd($query->where('ma_xa', '09169')->get());
                $dynamicData = $query->withTrashed()->paginate(20);

                return $dynamicData;
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function getAllWithoutPagination($command_key)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $ctor_args = $s_command->ctor_args ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();

                if ($ctor_args != "") {
                    foreach (explode(";", $ctor_args) as $item_where) {
                        $item_where_detail = explode("|", $item_where);
                        if (!empty($item_where_detail[0]) && !empty($item_where_detail[1]) && !empty($item_where_detail[2])) {
                            $query->where($item_where_detail[0], $item_where_detail[1], $item_where_detail[2]);
                        }
                    }
                }
                $dynamicData = $query->get();

                return $dynamicData;
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function search($command_key, Request $request)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $ctor_args = $s_command->ctor_args ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();

                if ($ctor_args != "") {
                    foreach (explode(";", $ctor_args) as $item_where) {
                        $item_where_detail = explode("|", $item_where);
                        if (!empty($item_where_detail[0]) && !empty($item_where_detail[1]) && !empty($item_where_detail[2])) {
                            $query->where($item_where_detail[0], $item_where_detail[1], $item_where_detail[2]);
                        }
                    }
                }

                $filters = $request->all();

                foreach ($filters as $key => $filter) {
                    if (!empty($key) && !empty($filter)) {
                        $query->where($key, 'like', '%' . $filter . '%');
                    }
                }
                $dynamicData = $query->paginate(20);

                return $dynamicData;
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }


    public function index($command_key, $id)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();
                $objData = $query->find($id);
                if ($objData) {
                    return $query->find($id);
                } else {
                    return ['status' => 201, 'message' => trans('system.record_not_exist')];
                }
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    /**
     * @description: Add new record
     * @param Request $request
     * @param $command_key
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request, $command_key)
    {
        DB::beginTransaction();
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();

            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $dynamic_object = new DynamicObject();
                $dynamic_object->setTable($s_command->ctor_arg1);

                if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->ma_xa) || (strpos($dynamic_object->ma_xa, " ") !== false)) {
                    return ['status' => 201, 'message' => trans('system.invalid_characters')];
                }

                //Validate
                $error_messages = [
                    'ma_xa.required' => 'Mã không được bỏ trống giá trị',
                    'ma_xa.unique' => 'Đã tồn tại mã tương tự trong cơ sở dữ liệu',
                    'ten_xa.required' => 'Tên không được bỏ trống giá trị',
                    'ten_xa.unique' => 'Đã tồn tại tên tương tự trong cơ sở dữ liệu',
                    'ma_huyen.required' => 'Mã huyện không được bỏ trống giá trị',

                    'ma_lh.required' => 'Mã không được bỏ trống giá trị',
                    'ten_lh.required' => 'Tên không được bỏ trống giá trị',
                ];
                $validator = Validator::make($request->all(), [
                    'ma_xa' => 'required|unique:' . ($s_command->ctor_arg1 ?? "") . ',ma_xa,' . $dynamic_object->id,
                    'ten_xa' => 'required|unique:' . ($s_command->ctor_arg1 ?? "") . ',ten_xa,' . $dynamic_object->id,
                    'ma_huyen' => 'required|unique:' . ($s_command->ctor_arg1 ?? "") . ',ma_huyen,' . $dynamic_object->id,
                    'ten_huyen' => 'required|unique:' . ($s_command->ctor_arg1 ?? "") . ',ten_huyen,' . $dynamic_object->id,
                ], $error_messages);

                if ($validator->fails()) {
                    $errors = $validator->errors();
                    DB::rollback();
                    return response()->json(['status' => 201, 'message' => $errors]);
                } else {
                    $dynamic_object->fill($request->all());
                    $dynamic_object->save();
                }
                //End validate
            }

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    /**
     * @description: update data
     * @param Request $request
     * @param $command_key
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $command_key, $id)
    {
        DB::beginTransaction();
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();

            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $dynamic_object = new DynamicObject();
                $dynamic_object->setTable($s_command->ctor_arg1);
                $dynamic_object = $dynamic_object->newQuery()->where('id', $id)->first();

                if ($dynamic_object) {
                    $dynamic_object->fill($request->all());
                } else {
                    return ['status' => 201, 'message' => trans('system.record_not_exist')];
                }

                if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->ma_xa) || (strpos($dynamic_object->ma_xa, " ") !== false)) {
                    return ['status' => 201, 'message' => trans('system.invalid_characters')];
                }

                //Validate
                $obj_validate = $dynamic_object->_validate_fields($dynamic_object->id);
                $error_messages = $dynamic_object->error_messages;
                $validator = Validator::make($request->all(), $obj_validate[($s_command->ctor_arg1 ?? "")], $error_messages);

                if ($validator->fails()) {
                    $errors = $validator->errors();
                    DB::rollback();
                    return response()->json(['status' => 201, 'message' => $errors]);
                } else {
                    $dynamic_object->save();
                }
                //End validate
//                $dynamic_object->save();
            }

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function delete($command_key, $id)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();
                $objData = $query->find($id);
                if ($objData) {
                    $objData->delete();
                    return response()->json([
                        'status' => 200,
                        'message' => trans('system.deleted_successfully')
                    ]);
                } else {
                    return ['status' => 201, 'message' => trans('system.record_not_exist')];
                }
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    ///////////////////////QUAN LY DOANH NGHIEP//////////////////////////
    public function getAllHoSoDoanhNghiep()
    {
        try {
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();

            $list_data = $query->paginate(20);

            return $list_data;
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function indexHoSoDoanhNghiep($id)
    {
        try {
            $dynamicData = new HoSoDoanhNghiep();

            $objData = $dynamicData::find($id);
            $objData ? $objData->bindingOtherInformations() : null;

            if ($objData) {
                return $objData;
            } else {
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function deleteHoSoDoanhNghiep($id)
    {
        try {
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();
            $objData = $query->find($id);
            if ($objData) {
                $objData->delete();
                return response()->json([
                    'status' => 200,
                    'message' => trans('system.deleted_successfully')
                ]);
            } else {
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function searchHoSoDoanhNghiep(Request $request)
    {
        try {
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();
            $filters = $request->all();
            foreach ($filters as $key => $filter) {
                if (!empty($key) && !empty($filter)) {
                    $query->where($key, 'like', '%' . $filter . '%');
                }
            }
            $dynamicData = $query->paginate(20);

            $collections = $dynamicData->getCollection();
            foreach ($collections as $collection) {
                $collection ? $collection->bindingOtherInformations() : null;
            }

            return $dynamicData;
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function storeHoSoDoanhNghiep(Request $request)
    {
        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoDoanhNghiep();
            $dynamic_object->fill($request->all());

            if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->maso_dn) || (strpos($dynamic_object->maso_dn, " ") !== false)) {
                return ['status' => 201, 'message' => trans('system.invalid_characters')];
            }

            //Validate
            $validate_fields = [
                'maso_dn' => 'required|unique:m_hoso_doanhnghiep,maso_dn,' . $dynamic_object->id,
                'ten_dn' => 'required|unique:m_hoso_doanhnghiep,ten_dn,' . $dynamic_object->id,
                'diachi' => 'required' . $dynamic_object->id,
                'nguoi_daidien' => 'required' . $dynamic_object->id,
                'loai_hinh' => 'required' . $dynamic_object->id,
            ];
            $error_messages = [
                'maso_dn.required' => 'Mã doanh nghiệp không được bỏ trống giá trị',
                'maso_dn.unique' => 'Đã tồn tại mã doanh nghiệp tương tự trong cơ sở dữ liệu',
                'ten_dn.required' => 'Tên doanh nghiệp không được bỏ trống giá trị',
                'ten_dn.unique' => 'Đã tồn tại tên doanh nghiệp tương tự trong cơ sở dữ liệu',
                'diachi.required' => 'Địa chỉ không được bỏ trống giá trị',
                'nguoi_daidien.required' => 'Người đại diện không được bỏ trống giá trị',
                'loai_hinh.required' => 'Loại hình doanh nghiệp không được bỏ trống giá trị',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function updateHoSoDoanhNghiep(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoDoanhNghiep();
            $dynamic_object = $dynamic_object->find($id);

            if ($dynamic_object) {
                $dynamic_object->fill($request->all());
            } else {
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }

            if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->maso_dn) || (strpos($dynamic_object->maso_dn, " ") !== false)) {
                return ['status' => 201, 'message' => trans('system.invalid_characters')];
            }

            //Validate
            $validate_fields = [
                'maso_dn' => 'required|unique:m_hoso_doanhnghiep,maso_dn,' . $id,
                'ten_dn' => 'required|unique:m_hoso_doanhnghiep,ten_dn,' . $id,
            ];
            $error_messages = [
                'maso_dn.required' => 'Mã doanh nghiệp không được bỏ trống giá trị',
                'maso_dn.unique' => 'Đã tồn tại mã doanh nghiệp tương tự trong cơ sở dữ liệu',
                'ten_dn.required' => 'Tên doanh nghiệp không được bỏ trống giá trị',
                'ten_dn.unique' => 'Đã tồn tại tên doanh nghiệp tương tự trong cơ sở dữ liệu'
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function updateTrangThaiDuyet(Request $request)
    {
        DB::beginTransaction();
        try {
            $id = $request->id ?? null;
            $trang_thai_duyet = $request->trang_thai_duyet ?? null;
            $dynamic_object = new HoSoDoanhNghiep();
            $dynamic_object = $dynamic_object->find($id);

            if ($dynamic_object) {
                $dynamic_object->update(["trang_thai_duyet" => $trang_thai_duyet]);
                DB::commit();
            } else {
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
            //End validate

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.updated_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function getMaSoDN(Request $request)
    {
        try {
            $maso_dn = $request->maso_dn;

            $dynamicData = new DynamicObject();
            $dynamicData->setTable('m_hoso_doanhnghiep');
            $query = $dynamicData->newQuery();
            $objData = $query->where('maso_dn', '=', $maso_dn)->first();

            if ($objData) {
                return $objData->toArray();
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function getDatabaseInformation()
    {
        $exeStr = DB::select(DB::raw("select table_name, column_name, data_type, character_maximum_length
                from information_schema.columns 
                where table_schema = 'dulieudoanhnghiep_bn' and table_name IN (SELECT ctor_arg1 FROM s_command)
                ORDER BY table_name, ordinal_position;"));

        return $exeStr;
    }
}
