<?php

namespace App\Http\Controllers\DoanhNghiep;

use App\Models\DynamicObject;
use App\Models\SCommand;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class DanhMucController extends Controller
{
    public function search($command_key, Request $request)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $ctor_args = $s_command->ctor_args ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();

                if ($ctor_args != "") {
                    foreach (explode(";", $ctor_args) as $item_where) {
                        $item_where_detail = explode("|", $item_where);
                        if (!empty($item_where_detail[0]) && !empty($item_where_detail[1]) && !empty($item_where_detail[2])) {
                            $query->where($item_where_detail[0], $item_where_detail[1], $item_where_detail[2]);
                        }
                    }
                }

                $filters = $request->except('_token', 'page');
                foreach ($filters as $key => $filter) {
                    if (!empty($key) && !empty($filter)) {
                        $query->where($key, 'like', '%' . $filter . '%');
                    }
                }
//                $list_data = $query->paginate(20);
                $list_data = $query->paginate(20, ['*'], 'page', $request->page);
                $currentPage = $list_data->currentPage();
                $perPage = $list_data->perPage();

//                dd($list_data->getUrlRange(1, 3));

                return view('danhmuc.' . $command_key . '._search', compact('list_data', 'currentPage', 'perPage'));
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function edit($command_key)
    {
        try {
            $danhmucAPI = new DanhMucApiController();
            $list_data = $danhmucAPI->getAll($command_key);
            $title = SCommand::where('command_key', $command_key)->first()->form_name ?? null;
            if ($command_key) {

                //Other list
                $danhmucAPI = new DanhMucApiController();
                if ($command_key == 'diagioi_capxa') {
                    $list_tinh_thanh = $danhmucAPI->getAllWithoutPagination('diagioi_captinh');
                    $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
                } elseif ($command_key == 'diagioi_caphuyen') {
                    $list_tinh_thanh = $danhmucAPI->getAllWithoutPagination('diagioi_captinh');
                }
                $currentPage = $list_data->currentPage();
                $perPage = $list_data->perPage();
                return view('danhmuc.' . $command_key . '.index',
                    compact(
                        'list_data', 'title', 'command_key', 'currentPage', 'perPage'
                        , ($command_key == 'diagioi_capxa' ? 'list_quan_huyen' : null)
                        , ($command_key == 'diagioi_caphuyen' || $command_key == 'diagioi_capxa' ? 'list_tinh_thanh' : null)
                    ));
            } else {
                return view('layouts.error-404')
                    ->with([
                        'status' => 202,
                        'message' => trans('system.not_exist')
                    ]);
            }
        } catch (\Exception $e) {
            dd($e);
        }
    }

    public function store($command_key, Request $request)
    {
        DB::beginTransaction();
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            $id = $request->id ?? null;

            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $dynamic_object = new DynamicObject();
                $dynamic_object->setTable($s_command->ctor_arg1);
                $dynamic_object->fill($request->all());

                if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->ma_xa) || (strpos($dynamic_object->ma_xa, " ") !== false)) {
                    return ['status' => 201, 'message' => trans('system.invalid_characters')];
                }

                //Validate
                $obj_validate = $dynamic_object->_validate_fields($dynamic_object->id);
                $error_messages = $dynamic_object->error_messages;
                $validator = Validator::make($request->all(), $obj_validate[($s_command->ctor_arg1 ?? "")], $error_messages);

                if ($validator->fails()) {
                    $errors = $validator->errors();
                    DB::rollback();
                    return response()->json(['status' => 201, 'message' => $errors]);
                } else {
                    $dynamic_object->save();
                }
                //End validate
//                $dynamic_object->save();
            }

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function update($command_key, Request $request)
    {
        DB::beginTransaction();
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            $id = $request->id ?? null;

            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $dynamic_object = new DynamicObject();
                $dynamic_object->setTable($s_command->ctor_arg1);
                $dynamic_object = $dynamic_object->newQuery()->where('id', $id)->first();

                if ($dynamic_object) {
                    $dynamic_object->fill($request->all());
                } else {
                    $dynamic_object = new DynamicObject();
                    $dynamic_object->setTable($s_command->ctor_arg1);
                    $dynamic_object->fill($request->all());
                }

                if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->ma_xa) || (strpos($dynamic_object->ma_xa, " ") !== false)) {
                    DB::rollback();
                    return ['status' => 201, 'message' => trans('system.invalid_characters')];
                }

                //Validate
                $obj_validate = $dynamic_object->_validate_fields($dynamic_object->id);
                $error_messages = $dynamic_object->error_messages;
                $validator = Validator::make($request->all(), $obj_validate[($s_command->ctor_arg1 ?? "")], $error_messages);

                if ($validator->fails()) {
                    $errors = $validator->errors();
                    DB::rollback();
                    return response()->json(['status' => 201, 'message' => $errors]);
                } else {
                    $dynamic_object->save();
                }
                //End validate
//                $dynamic_object->save();
            }

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function hideItem($command_key, $state, $id)
    {
        DB::beginTransaction();
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();
                $objData = $query->withTrashed()->find($id);

                if ($objData) {
                    if ($state == "Y") {
                        $objData->restore();
                    } else {
                        $objData->delete();
                    }

                    DB::commit();
                    return response()->json([
                        'status' => 200,
                        'message' => ($state == "Y") ? trans('system.restored_successfully') : trans('system.deleted_successfully')
                    ]);
                } else {
                    DB::rollback();
                    return ['status' => 201, 'message' => trans('system.record_not_exist')];
                }
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function delete($command_key, $id)
    {
        try {
            $s_command = SCommand::where('command_key', $command_key)->first();
            if ($s_command && ($s_command->class_name ?? "") == "Editor") {
                $ctor_arg1 = $s_command->ctor_arg1 ?? null;
                $dynamicData = new DynamicObject();
                $dynamicData->setTable($ctor_arg1);

                $query = $dynamicData->newQuery();
                $objData = $query->withTrashed()->find($id);
                if ($objData) {
                    $objData->forceDelete();
                    return response()->json([
                        'status' => 200,
                        'message' => trans('system.deleted_successfully')
                    ]);
                } else {
                    return ['status' => 201, 'message' => trans('system.record_not_exist')];
                }
            } else {
                return ['status' => 201, 'message' => trans('system.command_not_exist')];
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }
}
