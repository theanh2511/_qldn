<?php

namespace App\Http\Controllers\DoanhNghiep;

use App\Imports\HoSoDoanhNghiepImport;
use App\Models\DynamicObject;
use App\Models\HoSoDoanhNghiep;
use App\Models\ImportHoSoDoanhNghiep;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

class QuanLyDoanhNghiepController extends Controller
{
    public function edit($id = null)
    {
        try {
            $title = "Tạo mới hồ sơ doanh nghiệp";

            if ($id) {
                $title = "Cập nhật hồ sơ doanh nghiệp";
                $dynamicData = new HoSoDoanhNghiep();
                $item_hsdn = $dynamicData::find($id);
                if ($item_hsdn) {
                    $item_hsdn ? $item_hsdn->bindingOtherInformations() : null;
                } else {
                    $item_hsdn = new HoSoDoanhNghiep();
                }
            } else {
                $item_hsdn = new HoSoDoanhNghiep();
            }

            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $list_loai_hinh_dn = $danhmucAPI->getAllWithoutPagination('loaihinh_doanhnghiep');
//dd($item_hsdn);
            return view('ql_doanhnghiep.edit', compact('title', 'item_hsdn', 'list_quan_huyen', 'list_xa_phuong', 'list_loai_hinh_dn'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function update(Request $request, $id = null)
    {

        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoDoanhNghiep();
            $dynamic_object = $dynamic_object->find($id);

            if ($dynamic_object) {
                $dynamic_object->fill($request->all());
            } else {
                $dynamic_object = new HoSoDoanhNghiep();
                $dynamic_object->fill($request->all());
            }

            if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $dynamic_object->maso_dn) || (strpos($dynamic_object->maso_dn, " ") !== false)) {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.invalid_characters')];
            }

            //Validate
            $validate_fields = [
                'maso_dn' => 'required|unique:m_hoso_doanhnghiep,maso_dn,' . $dynamic_object->id,
                'ten_dn' => 'required|unique:m_hoso_doanhnghiep,ten_dn,' . $dynamic_object->id,
                'diachi' => 'required',
                'nguoi_daidien' => 'required',
                'loai_hinh' => 'required',
            ];
            $error_messages = [
                'maso_dn.required' => 'Mã doanh nghiệp không được bỏ trống giá trị',
                'maso_dn.unique' => 'Đã tồn tại mã doanh nghiệp tương tự trong cơ sở dữ liệu',
                'ten_dn.required' => 'Tên doanh nghiệp không được bỏ trống giá trị',
                'ten_dn.unique' => 'Đã tồn tại tên doanh nghiệp tương tự trong cơ sở dữ liệu',
                'diachi.required' => 'Địa chỉ không được bỏ trống giá trị',
                'nguoi_daidien.required' => 'Người đại diện không được bỏ trống giá trị',
                'loai_hinh.required' => 'Loại hình doanh nghiệp không được bỏ trống giá trị',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    /**
     * @Description: Delete record HoSoDoanhNghiep with $id
     * @param $id
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function delete($id)
    {
        DB::beginTransaction();
        try {
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();
            $objData = $query->find($id);
            if ($objData) {
                $objData->delete();
                DB::commit();
                return response()->json([
                    'status' => 200,
                    'message' => trans('system.deleted_successfully')
                ]);
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsMoiTao()
    {
        try {
            $trang_thai = 3; //Mới tạo
            $date_approve = date('Y-m-d', strtotime("-30 days"));
            $title = "Danh sách doanh nghiệp mới tạo";

            $list_data = HoSoDoanhNghiep::where('trang_thai_duyet', $trang_thai)
                ->where('ngay_duyet', '>=', $date_approve)
                ->orderBy('ngay_duyet', 'desc')
                ->paginate(20);
            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }

            return view('ql_doanhnghiep.danhsach_moitao.index', compact('title', 'list_data', 'trang_thai', 'list_quan_huyen', 'list_xa_phuong', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsChoDuyet()
    {
        try {
            $trang_thai = 1; //Chờ duyệt
            $title = "Danh sách doanh nghiệp chờ duyệt";
            $list_data = HoSoDoanhNghiep::where('trang_thai_duyet', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_doanhnghiep.danhsach_choduyet.index', compact('title', 'list_data', 'trang_thai', 'list_quan_huyen', 'list_xa_phuong', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsKhongDuyet()
    {
        try {
            $trang_thai = 2; //Không duyệt
            $title = "Danh sách doanh nghiệp không duyệt";
            $list_data = HoSoDoanhNghiep::where('trang_thai_duyet', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }

            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_doanhnghiep.danhsach_guilai.index', compact('title', 'list_data', 'trang_thai', 'list_quan_huyen', 'list_xa_phuong', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsDaDuyet()
    {
        try {
            $trang_thai = 3; //Đã duyệt
            $title = "Danh sách doanh nghiệp đã duyệt";
            $list_data = HoSoDoanhNghiep::where('trang_thai_duyet', $trang_thai)->paginate(20);

            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
                $item->hsdn_logs;
//                if ($item->maso_dn != "23001897762") {
//                    dd($item->hsdn_logs);
//                }
            }

            return view('ql_doanhnghiep.danhsach_daduyet.index', compact('title', 'list_data', 'trang_thai', 'list_quan_huyen', 'list_xa_phuong', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }


    public function search(Request $request, $command_key)
    {
        try {
            $date_approve = date('Y-m-d', strtotime("-30 days"));
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();
            $filters = $request->except('_token', 'page');
            $trang_thai = $request->trang_thai_duyet ?? "";

            foreach ($filters as $key => $filter) {
                if (!empty($key) && !empty($filter)) {

                    $query->where($key, 'like', '%' . $filter . '%');
                }
            }
            //Search: danh sách tham gia
            if ($command_key == "danhsach_moitao") {
                $query->where('ngay_duyet', '>=', $date_approve);
            }
            $list_data = $query->paginate(20);

            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_doanhnghiep.' . $command_key . '._search', compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function searchQuanHuyen(Request $request)
    {
        try {
            $dynamicData = new DynamicObject();
            $dynamicData->setTable('m_diagioi_capxa');

            $query = $dynamicData->newQuery();
            $filters = $request->except('_token');

            foreach ($filters as $key => $filter) {
                if (!empty($key) && !empty($filter)) {
                    $query->where($key, 'like', '%' . $filter . '%');
                }
            }
            $list_data = $query->get();

            return view('ql_doanhnghiep._search_quan_huyen', compact('list_data'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    /**
     * @Description: Gửi trình hồ sơ doanh nghiệp
     * @param $id
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function gui_trinh($id)
    {
        DB::beginTransaction();
        try {
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();
            $objData = $query->find($id);
            if ($objData) {
                $objData->update(["trang_thai_duyet" => 1, "ngay_gui_trinh" => date("Y-m-d")]);
                DB::commit();
                return response()->json([
                    'status' => 200,
                    'message' => trans('system.submission_successfully')
                ]);
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    /**
     * @Description: Duyệt hồ sơ doanh nghiệp
     * @param $id
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function duyetHoSo(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $dynamicData = new HoSoDoanhNghiep();
            $query = $dynamicData->newQuery();
            $objData = $query->find($id);
            $trang_thai = $request['trang_thai'] ?? 1;
            $ly_do = $request['ly_do'] ?? 1;

            if ($objData) {
                $objData->update(["trang_thai_duyet" => $trang_thai, "ly_do" => $ly_do, "ngay_duyet" => date("Y-m-d")]);
                DB::commit();
                return response()->json([
                    'status' => 200,
                    'message' => trans('system.approve_successfully')
                ]);
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function modal($id = null)
    {
        try {
            $title = "Tạo mới hồ sơ doanh nghiệp";

            if ($id) {
                $dynamicData = new HoSoDoanhNghiep();
                $item_hsdn = $dynamicData::find($id);
                $item_hsdn ? $item_hsdn->bindingOtherInformations() : null;
            } else {
                $item_hsdn = new HoSoDoanhNghiep();
            }

            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $list_loai_hinh_dn = $danhmucAPI->getAllWithoutPagination('loaihinh_doanhnghiep');

            return view('ql_doanhnghiep.modal_duyet_ho_so', compact('title', 'item_hsdn', 'list_quan_huyen', 'list_xa_phuong', 'list_loai_hinh_dn'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function importExcel(Request $request)
    {
        DB::beginTransaction();
        try {
            $file = $request->file();
//            dd($file["file"]->getRealPath());
//            $path = storage_path('TemplateImport_HoSoDoanhNghiep.xls');
            Excel::import(new HoSoDoanhNghiepImport(), $file["file"]->getRealPath());

            DB::commit();
            return response()->json([
                'status' => 200,
                'message' => trans('system.import_successfully')
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }
}
