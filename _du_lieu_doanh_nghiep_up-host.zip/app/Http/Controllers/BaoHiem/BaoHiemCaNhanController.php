<?php

namespace App\Http\Controllers\BaoHiem;

use App\Http\Controllers\DoanhNghiep\DanhMucApiController;
use App\Models\HoSoBaoHiemCaNhan;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class BaoHiemCaNhanController extends Controller
{
    /*--------------------------------------------------------------------*/
    /******************* CHƯA CẤP & ĐÃ CẤP BẢO HIỂM XÃ HỘI **************************/
    /*--------------------------------------------------------------------*/
    public function dsnguoichuaduoccapbhxh()
    {
        try {
            $trang_thai = 1; // 0: Chưa tham gia BHXH   1: Đã cấp BHXH
            $title = "Danh sách người chưa được cấp BHXH";
            $list_data = HoSoBaoHiemCaNhan::where('trang_thai', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();

            return view('ql_baohiem.dsnguoichuaduoccapbhxh.index',
                compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsnguoidaduoccapbhxh()
    {
        try {
            $trang_thai = 2; // 0: Chưa tham gia BHXH   1: Đã cấp BHXH
            $title = "Danh sách người đã được cấp BHXH";
            $list_data = HoSoBaoHiemCaNhan::where('trang_thai', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();

            return view('ql_baohiem.dsnguoidaduoccapbhxh.index',
                compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function search(Request $request)
    {
        try {
            $filters = $request->except('_token', 'page');

            $dynamicData = new HoSoBaoHiemCaNhan();
            $query = $dynamicData->newQuery();
            foreach ($filters as $key => $filter) {

                if (!empty($key) && !empty($filter)) {
                    $query->where($key, 'like', '%' . $filter . '%');
                }
            }
            $list_data = $query->paginate(20, ['*'], 'page', $request->page);
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();

            $cmd_key = "dsnguoichuaduoccapbhxh";
            if ($request->trang_thai == "2") {
                $cmd_key = "dsnguoidaduoccapbhxh";
            }

            return view('ql_baohiem.' . $cmd_key . '._search',
                compact('list_data', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function delete($id)
    {
        DB::beginTransaction();
        try {
            $dynamicData = new HoSoBaoHiemCaNhan();
            $query = $dynamicData->newQuery();
            $objData = $query->find($id);
            if ($objData) {
                $objData->delete();
                DB::commit();
                return response()->json([
                    'status' => 200,
                    'message' => trans('system.deleted_successfully')
                ]);
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    /*--------------------------------------------------------------------*/
    /******************* CHƯA CẤP BẢO HIỂM XÃ HỘI **************************/
    /*--------------------------------------------------------------------*/

    public function edit($id = null)
    {
        try {
            $title = "Người chưa được cấp mã số BHXH";

            if ($id) {
                $title = "Cập nhật thông tin người chưa được cấp mã số BHXH";
                $dynamicData = new HoSoBaoHiemCaNhan();
                $item_hsbh = $dynamicData::find($id);
                if ($item_hsbh) {
                    $item_hsbh->bindingOtherInformations();
                } else {
                    $item_hsbh = new HoSoBaoHiemCaNhan();
                }
            } else {
                $item_hsbh = new HoSoBaoHiemCaNhan();
                $item_hsbh->bindingOtherInformations();
            }

            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $list_loai_hinh_dn = $danhmucAPI->getAllWithoutPagination('loaihinh_doanhnghiep');

            return view('ql_baohiem.edit_nguoichuacapbhxh', compact('title', 'item_hsbh', 'list_quan_huyen', 'list_xa_phuong', 'list_loai_hinh_dn'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function update(Request $request, $id = null)
    {

        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoBaoHiemCaNhan();
            $dynamic_object = $dynamic_object->find($id);

            if ($dynamic_object) {
                $dynamic_object->fill($request->all());
            } else {
                $dynamic_object = new HoSoBaoHiemCaNhan();
                $dynamic_object->fill($request->all());
            }

            //Validate
            $validate_fields = [
                'so_cmt' => 'required|unique:f_hoso_baohiem_cn,so_cmt,' . $dynamic_object->id,
                'ten_ca_nhan' => 'required',
            ];
            $error_messages = [
                'so_cmt.required' => 'Số CMND/Hộ chiếu/Thẻ căn cước không được bỏ trống giá trị',
                'so_cmt.unique' => 'Số CMND/Hộ chiếu/Thẻ đã có giá trị trong CSDL',
                'ten_ca_nhan.required' => 'Họ và tên không được bỏ trống giá trị',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->trang_thai = 1;
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function approveBHXH(Request $request, $id = null)
    {
        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoBaoHiemCaNhan();
            $dynamic_object = $dynamic_object->find($id);
            if ($dynamic_object) {
                $dynamic_object->fill($request->all());
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }

            //Validate
            $validate_fields = [
                'ngaycap_bhxh' => 'required',
                'maso_bhxh' => 'required|unique:f_hoso_baohiem_cn,maso_bhxh,' . $dynamic_object->id
            ];
            $error_messages = [
                'ngaycap_bhxh.required' => 'Ngày cấp không được bỏ trống giá trị',
                'maso_bhxh.required' => 'Mã số BHXH không được bỏ trống giá trị',
                'maso_bhxh.unique' => 'Mã số BHXH đã tồn tại trong cơ sở dữ liệu',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->trang_thai = 2;
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    /*--------------------------------------------------------------------*/
    /******************* ĐÃ CẤP BẢO HIỂM XÃ HỘI **************************/
    /*--------------------------------------------------------------------*/

    public function editDaCapBHXH($id = null)
    {
        try {
            $title = "Người đã được cấp mã số BHXH";

            if ($id) {
                $title = "Cập nhật thông tin người đã được cấp mã số BHXH";
                $dynamicData = new HoSoBaoHiemCaNhan();
                $item_hsbh = $dynamicData::find($id);
                if ($item_hsbh) {
                    $item_hsbh->bindingOtherInformations();
                } else {
                    $item_hsbh = new HoSoBaoHiemCaNhan();
                }
            } else {
                $item_hsbh = new HoSoBaoHiemCaNhan();
                $item_hsbh->bindingOtherInformations();
            }

            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $list_loai_hinh_dn = $danhmucAPI->getAllWithoutPagination('loaihinh_doanhnghiep');

            return view('ql_baohiem.edit_nguoidacapbhxh', compact('title', 'item_hsbh', 'list_quan_huyen', 'list_xa_phuong', 'list_loai_hinh_dn'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function updateDaCapBHXH(Request $request, $id = null)
    {

        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoBaoHiemCaNhan();
            $dynamic_object = $dynamic_object->find($id);

            if ($dynamic_object) {
                $dynamic_object->fill($request->all());
            } else {
                $dynamic_object = new HoSoBaoHiemCaNhan();
                $dynamic_object->fill($request->all());
            }

            //Validate
            $validate_fields = [
                'so_cmt' => 'required|unique:f_hoso_baohiem_cn,so_cmt,' . $dynamic_object->id,
                'maso_bhxh' => 'required|unique:f_hoso_baohiem_cn,maso_bhxh,' . $dynamic_object->id,
                'ten_ca_nhan' => 'required',
            ];
            $error_messages = [
                'so_cmt.required' => 'Số CMND/Hộ chiếu/Thẻ căn cước không được bỏ trống giá trị',
                'so_cmt.unique' => 'Số CMND/Hộ chiếu/Thẻ đã có giá trị trong CSDL',
                'ten_ca_nhan.required' => 'Họ và tên không được bỏ trống giá trị',
                'maso_bhxh.required' => 'Mã số BHXH không được bỏ trống giá trị',
                'maso_bhxh.unique' => 'Mã số BHXH đã có giá trị trong CSDL',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->trang_thai = 2;
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }
}
