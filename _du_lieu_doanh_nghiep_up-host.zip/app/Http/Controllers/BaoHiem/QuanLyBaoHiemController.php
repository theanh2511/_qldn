<?php

namespace App\Http\Controllers\BaoHiem;

use App\Http\Controllers\DoanhNghiep\DanhMucApiController;
use App\Models\HoSoBaoHiem;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class QuanLyBaoHiemController extends Controller
{
    public function edit($id = null)
    {
        try {
            $title = "Tạo mới hồ sơ doanh nghiệp tham gia bảo hiểm";

            if ($id) {
                $title = "Cập nhật hồ sơ doanh nghiệp tham gia bảo hiểm";
                $dynamicData = new HoSoBaoHiem();
                $item_hsbh = $dynamicData::find($id);
                if ($item_hsbh) {
//                    $item_hsbh->bindingOtherInformations();
                } else {
                    $item_hsbh = new HoSoBaoHiem();
                }
            } else {
                $item_hsbh = new HoSoBaoHiem();
            }

            $danhmucAPI = new DanhMucApiController();
            $list_quan_huyen = $danhmucAPI->getAllWithoutPagination('diagioi_caphuyen');
            $list_xa_phuong = $danhmucAPI->getAllWithoutPagination('diagioi_capxa');
            $list_loai_hinh_dn = $danhmucAPI->getAllWithoutPagination('loaihinh_doanhnghiep');

            return view('ql_baohiem.edit', compact('title', 'item_hsbh', 'list_quan_huyen', 'list_xa_phuong', 'list_loai_hinh_dn'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function update(Request $request, $id = null)
    {

        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoBaoHiem();
            $dynamic_object = $dynamic_object->find($id);

            if ($dynamic_object) {
                $dynamic_object->fill($request->all());
            } else {
                $dynamic_object = new HoSoBaoHiem();
                $dynamic_object->fill($request->all());
            }

            //Validate
            $validate_fields = [
                'maso_dn' => 'required|unique:f_hoso_baohiem,maso_dn,' . $dynamic_object->id,
                'maso_thue' => 'unique:f_hoso_baohiem,maso_thue,' . $dynamic_object->id,
                'ten_dn' => 'required',
            ];
            $error_messages = [
                'maso_dn.required' => 'Mã số đơn vị không được bỏ trống giá trị',
                'maso_dn.unique' => 'Mã số đơn vị đã có giá trị trong CSDL',
                'ten_dn.required' => 'Tên đơn vị không được bỏ trống giá trị',
                'maso_thue.unique' => 'Mã số thuế đã có giá trị trong CSDL',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->trang_thai = 1;
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function approve(Request $request, $id = null)
    {
        DB::beginTransaction();
        try {
            $dynamic_object = new HoSoBaoHiem();
            $dynamic_object = $dynamic_object->find($id);
            $arr = $request->all();
            $arr['ngay_duyet'] = Carbon::createFromFormat('Y-m-d', $request->ngay_duyet)->format("d/m/Y");

            if ($dynamic_object) {
                $dynamic_object->fill($arr);
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }

            //Validate
            $validate_fields = [
                'ngay_duyet' => 'required',
                'nguoi_duyet' => 'required',
            ];
            $error_messages = [
                'ngay_duyet.required' => 'Ngày duyệt không được bỏ trống giá trị',
                'nguoi_duyet.required' => 'Người duyệt không được bỏ trống giá trị',
            ];
            $validator = Validator::make($request->all(), $validate_fields, $error_messages);

            if ($validator->fails()) {
                $errors = $validator->errors();
                DB::rollback();
                return response()->json(['status' => 201, 'message' => $errors]);
            } else {
                $dynamic_object->save();
            }
            //End validate

            DB::commit();

            return response()->json(
                ['status' => 200,
                    'message' => trans('system.saved_successfully'),
                    'primary_key' => $dynamic_object->id]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->getMessage()]);
        }
    }

    public function delete($id)
    {
        DB::beginTransaction();
        try {
            $dynamicData = new HoSoBaoHiem();
            $query = $dynamicData->newQuery();
            $objData = $query->find($id);
            if ($objData) {
                $objData->delete();
                DB::commit();
                return response()->json([
                    'status' => 200,
                    'message' => trans('system.deleted_successfully')
                ]);
            } else {
                DB::rollback();
                return ['status' => 201, 'message' => trans('system.record_not_exist')];
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    /**
     * @Description: search data
     */
    public function search(Request $request)
    {
        try {
            $filters = $request->except('_token', 'page');

            $dynamicData = new HoSoBaoHiem();
            $query = $dynamicData->newQuery();
            foreach ($filters as $key => $filter) {

                if (!empty($key) && !empty($filter)) {
                    $query->where($key, 'like', '%' . $filter . '%');
                }
            }
            $list_data = $query->paginate(20, ['*'], 'page', $request->page);
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();

            $command_key = 'ds_choduyet';
            if ($request->trang_thai == '3') {
                $command_key = 'ds_moi_thamgia';
            } elseif ($request->trang_thai == '2') {
                $command_key = 'ds_khongduyet';
            }

            return view('ql_baohiem.' . $command_key . '._search',
                compact('list_data', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    //1: Chờ duyệt
    //2: Không duyệt gửi lại
    //3: Đã duyệt
    public function dsChoDuyet()
    {
        try {
            $trang_thai = 1;
            $title = "Doanh nghiệp tham gia bảo hiểm chờ duyệt";

            $list_data = HoSoBaoHiem::where('trang_thai', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_baohiem.ds_choduyet.index', compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsKhongDuyet()
    {
        try {
            $trang_thai = 2;
            $title = "Doanh nghiệp tham gia bảo hiểm không duyệt gửi lại";

            $list_data = HoSoBaoHiem::where('trang_thai', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }
            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_baohiem.ds_khongduyet.index', compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsMoiDuyet()
    {
        try {
            $trang_thai = 3;
            $title = "Doanh nghiệp tham gia bảo hiểm mới";

            $list_data = HoSoBaoHiem::where('trang_thai', $trang_thai)->skip(0)->take(100)->orderBy('ngay_duyet','desc')->paginate(100);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }

            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_baohiem.ds_moi_thamgia.index', compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }

    public function dsDaDuyet()
    {
        try {
            $trang_thai = 3;
            $title = "Doanh nghiệp tham gia bảo hiểm đã duyệt";

            $list_data = HoSoBaoHiem::where('trang_thai', $trang_thai)->paginate(20);
            foreach ($list_data as $item) {
                $item ? $item->bindingOtherInformations() : null;
            }

            $currentPage = $list_data->currentPage();
            $perPage = $list_data->perPage();
            return view('ql_baohiem.ds_moi_thamgia.index', compact('title', 'list_data', 'trang_thai', 'currentPage', 'perPage'));
        } catch (\Exception $e) {
            return response()->json(['status' => 202, 'message' => $e->errorInfo[2] ?? $e->getMessage()]);
        }
    }
}
