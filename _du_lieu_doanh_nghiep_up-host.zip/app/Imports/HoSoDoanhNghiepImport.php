<?php

namespace App\Imports;

use App\Models\HoSoDoanhNghiep;
use App\Models\ImportHoSoDoanhNghiep;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class HoSoDoanhNghiepImport implements ToModel, WithStartRow
{

    public function model(array $row)
    {
        if (!isset($row[0])) {
            return null;
        }
        $hsdn = new ImportHoSoDoanhNghiep();
        $hsdn->fill([
            'maso_dn' => $row[1],
            'ten_dn' => $row[2],
            'diachi' => $row[3],
            'quan_huyen' => $row[4],
            'xa_phuong' => $row[6],
            'von_dl' => $row[8],
            'trang_thai' => $row[9],
            'tel' => $row[11],
            'mobile' => $row[28],
            'fax' => $row[29],
            'email' => $row[30],
            'nguoi_daidien' => $row[12],
            'ngay_sinh_ndd' => Date::excelToTimestamp($row[13]),
            'cmt_hochieu' => $row[14],
            'ngaycap_cmt' => Date::excelToDateTimeObject($row[15]),
            'noi_cap' => $row[16],
            'so_huu' => $row[17],
            'kinhdoanh_chinh' => $row[18],
            'nganh_nghe' => $row[19],
            'ngay_cap' => Date::excelToDateTimeObject($row[20]),
            'ngay_thay_doi' => Date::excelToDateTimeObject($row[21]),
            'loai_hinh' => $row[22],
            'so_laodong' => $row[24],
            'ds_thanhvien' => $row[25],
            'ds_codong' => $row[26],
            'loai_dn' => $row[27],
            'trang_thai_duyet' => 0,
        ]);

        $hsdn->save();
        return $hsdn;
    }

    public function startRow():int
    {
        return 2;
    }


//    public function rules(): array
//    {
//        return [
//            '1' => Rule::in(['patrick@maatwebsite.nl']),
//
//            // Above is alias for as it always validates in batches
//            '*.1' => Rule::in(['patrick@maatwebsite.nl']),
//
//            // Can also use callback validation rules
//            '0' => function ($attribute, $value, $onFailure) {
//                if ($value !== 'Patrick Brouwers') {
//                    $onFailure('Name is not Patrick Brouwers');
//                }
//            }
//        ];
//    }
}
