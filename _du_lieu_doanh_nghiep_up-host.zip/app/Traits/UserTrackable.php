<?php

namespace App\Traits;

use Illuminate\Support\Facades\Auth;

trait UserTrackable
{
    public static function bootUserTrackable()
    {
        static::creating(function ($model) {
            $user = Auth::user();

            if ($user) {
                $model->fill([
                    'created_by' => $user->getAuthIdentifier()
                ]);
            }
        });

        static::updating(function ($model) {
            $user = Auth::user();

            if ($user) {
                $model->fill([
                    'updated_by' => $user->getAuthIdentifier()
                ]);
            }
        });
    }
}