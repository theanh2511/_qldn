<?php

namespace App\Observers;

use App\Models\HoSoBaoHiem;
use App\Models\HoSoDoanhNghiep;
use App\Models\SLogs;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HoSoBaoHiemObserver
{
    protected $department = "Bảo hiểm";
//    /**
//     * Handle the product "creating" event.
//     *
//     * @param  \App\Models\Product $product
//     * @return void
//     */
//    public function creating(HoSoBaoHiem $product)
//    {
//        $user = Auth::user();
//        $product->created_by = $user->getAuthIdentifier();
//    }

    /**
     * Handle the product "updating" event.
     *
     * @param  \App\Models\Product $product
     * @return void
     */
    public function updated(HoSoBaoHiem $hs_baohiem)
    {
        DB::beginTransaction();
        try {
            $user = Auth::user();

            $maso_dn = $hs_baohiem->maso_dn;
            $hs_doanhnghiep = HoSoDoanhNghiep::where('maso_dn', $maso_dn)->first();

            if ($hs_doanhnghiep && $hs_baohiem->trang_thai == "3") {
                $hs_baohiem->bindingOtherInformations();
                $hs_doanhnghiep->bindingOtherInformations();
                $s_logs_arrs = [];

                if ($hs_baohiem->loai_hinh != $hs_doanhnghiep->loai_hinh) {
                    $s_logs_arrs[] = [
                        "field_name" => "loai_hinh",
                        "old_value" => $hs_doanhnghiep->loai_hinh,
                        "new_value" => $hs_baohiem->loai_hinh,
                        "modify_date" => date('Y-m-d'),
                        "department" => $this->department,
                        "modify_content" => "Dữ liệu cũ: " . $hs_doanhnghiep->ten_lh . " - Dữ liệu mới: " . $hs_baohiem->ten_loai_hinh,
                        "status" => "1",
                        "created_by" => 1,
                        "created_at" => date('Y-m-d H:i:s')
                    ];
                }

                SLogs::insert($s_logs_arrs);
                DB::commit();
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['status' => 202, 'message' => 'HoSoBaoHiemObserver: function updated error']);
        }
    }
}
